import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pharma_clients_app/views/auth/login_screen.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class ErrorDialogue extends StatelessWidget {
  final String? message;

  ErrorDialogue({this.message, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CupertinoAlertDialog(
      title: const Padding(
        padding: EdgeInsets.all(20),
        child: Icon(Icons.error, color: Colors.red, size: 50),
      ),
      content: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        child: Text(
          message ?? 'An error occurred',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w500),
        ),
      ),
      actions: [
        CupertinoDialogAction(
          child: Text('OK'),
          onPressed: () {
              Navigator.pushReplacement(context,MaterialPageRoute(builder: (context) => LoginScreen(),) );
          },
        ),
      ],
    );
  }
}

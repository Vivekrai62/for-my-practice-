import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import '../resources/app_colors.dart';
import '../resources/constant_strings.dart';
import 'Responsive/ResponsiveUtils.dart';

class TextWithStyle{

  static appToCart(context, String message){
    return Text(message,
      style: TextStyle(
        fontSize: 17.sp,
        fontWeight: FontWeight.w500,
        color: AppColors.primaryColor,
      ),);
  }

  static appBarTitle(BuildContext context, String message) {
    double fontSize;
    FontWeight fontWeight;

    if (Responsive.isDesktop(context)) {
      fontSize = 22.0;
      fontWeight = FontWeight.w600; // Heavier for desktop
    } else if (Responsive.isTablet(context)) {
      fontSize = 40.0;
      fontWeight = FontWeight.w500; // Medium weight for tablet
    } else {
      fontSize = 18.0;
      fontWeight = FontWeight.w600; // Lighter for mobile
    }

    return Text(
      message,
      style: TextStyle(
        fontSize: fontSize,
        fontWeight: fontWeight,
        letterSpacing: -0.2,
        color: Colors.black,
      ),
    );
  }



  static containerTitle(context, String message){
    return Text(
        message,
      style: TextStyle(
          fontSize: 17.sp,
         color: Colors.black,
          fontWeight: FontWeight.w400
      ),
    );
  }

  static Widget  welcomeTitle(BuildContext context, String message) {
    return Text(
      message,
      style: GoogleFonts.workSans(
        color: Colors.white,
        textStyle: TextStyle(
          fontSize: Responsive.isDesktop(context)
              ? 24.0 // Font size for Desktop
              : (Responsive.isTablet(context)
              ? 50.0 // Font size for Tablet
              : 30.0), // Font size for Mobile
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  static Widget Register_As_a_Distributors(BuildContext context, String message) {
    return Text(
      message,
      style: GoogleFonts.workSans(
        color: AppColors.primaryColor,
        textStyle: TextStyle(

          fontSize: Responsive.isDesktop(context)
              ? 24.0 // Desktop
              : (Responsive.isTablet(context)
              ? 38.0 // Tablet
              : 20.0), // Mobile


          fontWeight: Responsive.isDesktop(context)
              ? FontWeight.w600 // Font weight for Desktop
              : (Responsive.isTablet(context)
              ? FontWeight.w600 // Font weight for Tablet
              : FontWeight.w600), // Font weight for Mobile
        ),
      ),
    );
  }



  static mainIconTitle(context, String message,color){
    return Text(
        message,
      textAlign: TextAlign.center,
      style: TextStyle(
        fontSize: 14.sp,
        color: color,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  static pngIconTitle(context, String message){
    return Text(
        message,
      textAlign: TextAlign.center,
      style: TextStyle(
        fontSize: 14.2.sp,
        fontWeight: FontWeight.w500
      ),
    );
  }

  static promotionalTitle (context, String message){
    return Text(
      message,
      style: TextStyle(
          fontSize: 16.sp,
          letterSpacing: 0.5,
          wordSpacing: 1,
      ),
    );
  }

  static productTitle(context, String message){
    return Text(
      message,
      maxLines: 2,
      style: TextStyle(
          fontSize: 17.sp,
      fontWeight: FontWeight.w600),
    );

  }

  static productTypeName(context, String message){
    return Text(
      message,
      style: TextStyle(
          fontSize: 13.5.sp,
        color: Colors.black54,
        fontWeight: FontWeight.w500
      ),
    );
  }

  static productDescription(context, String message){
    return Text(
      message,
      maxLines: 4,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(fontSize: 16.sp,color: Colors.black.withOpacity(0.7),),
    );
  }

  static productPrice(context, String? message){
    return Text(
      '₹$message',
      style: TextStyle(
          color: AppColors.primaryColor,
          fontSize: 17.sp,
          fontWeight: FontWeight.w500),
    );
  }

  static addToCartTitles(context, String message,color){
    return Text(message,
      maxLines: 1,
      style: TextStyle(
        fontSize: 16.sp,
        fontWeight: FontWeight.w600,
        color: color,
      ),);
  }

  static contactUsTitle(BuildContext context, String message) {
    double screenWidth = MediaQuery.of(context).size.width;

    // Define font size based on screen width
    double fontSize;
    if (screenWidth >= 1200) {
      // Desktop
      fontSize = 24.0;
    } else if (screenWidth >= 600) {
      // Tablet
      fontSize = 20.0;
    } else {
      // Mobile
      fontSize = 16.0;
    }

    return Text(
      message,
      style: TextStyle(
        color: Colors.white,
        fontSize: fontSize,
        fontWeight: FontWeight.w500,
      ),
    );
  }

  static mrProfileHeading(context, String message){
    return Text(message,
      style: TextStyle(
        fontSize: 17.sp,
        color: AppColors.mrcontaonerheading,
        fontWeight: FontWeight.w500
      ),);
  }

  static mrProfileTitles(context, String message){
    return Text(message,
      maxLines: 1,
      style: TextStyle(
          fontSize: 16.sp,
          color: Colors.black,
      ),);
  }

  static customerName(context ,String? message){
    return Text(
      message ?? 'Na',
      style: TextStyle(
          fontSize: 19.sp,
          fontWeight: FontWeight.w600),
    );
  }

  static customerDetails(context ,String? message){
    return Text(
      message ?? 'Na',
      style: TextStyle(
        color: Colors.black54,
        fontSize: 16.5.sp,
      ),
    );
  }

  static customerProductDetails(context ,String? message){
    return Text(
      message ?? 'Na',
      style: TextStyle(
        color: Colors.black,
        fontWeight: FontWeight.w500,
        fontSize: 16.5.sp,
      ),
    );
  }

  static customerTimeDetails(context ,String? message){
    return Text(
      message ?? 'Na',
      style: TextStyle(
        color: Colors.black54,
        fontSize: 15.sp,
      ),
    );
  }

  static customerStatus(context ,String? message, color){
    return Text(
      message ?? 'Na',
      style: TextStyle(
        color: color,
        fontSize: 17.sp,
        fontWeight: FontWeight.w400,
          letterSpacing: 1
      ),
    );
  }

}



class AppBarUtils {
  static Widget appBarTitle(BuildContext context, String message) {
    double fontSize;

    if (Responsive.isDesktop(context)) {
      fontSize = 25.0;
    } else if (Responsive.isTablet(context)) {
      fontSize = 39; // Adjusted for consistency
    } else {
      fontSize = 19.0;
    }

    return Text(
      message,
      style: TextStyle(
        fontSize: fontSize,
        fontWeight: FontWeight.w600,
        letterSpacing: -0.2,
        color: Colors.black,
      ),
    );
  }
}








import 'package:flutter/material.dart';
import 'package:responsive_sizer/responsive_sizer.dart'; // Ensure you import this if using for any size-related utility
import '../../resources/app_colors.dart';

class PasswordInputField extends StatelessWidget {
  final dynamic title;
  final dynamic node;
  final String? hintText;
  final String? labelText;
  final dynamic icon;
  final bool? obSecure; // Changed from dynamic to bool for clarity
  final Widget? suffixIcon; // Changed from dynamic to Widget for clarity
  final String? Function(String?)? validator; // Changed from dynamic to specific type for clarity

  PasswordInputField({
    this.title,
    this.node,
    this.hintText,
    this.labelText,
    this.icon,
    this.obSecure,
    this.suffixIcon,
    this.validator,
    Key? key
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Get the width of the screen
    double width = MediaQuery.of(context).size.width;

    // Adjust sizes based on screen width
    double iconSize = (width < 600) ? 22.0 : (width < 1200) ? 30.0 : 35.0;
    double padding = (width < 600) ? 8.0 : (width < 1200) ? 28.0 : 20.0;
    double fontSize = (width < 600) ? 19.0 : (width < 1200) ? 28.0 : 18.0;
    double contentPaddingVertical = (width < 600) ? 8.0 : (width < 1200) ? 12.0 : 16.0;

    return Container(
      margin: EdgeInsets.only(bottom: padding),
      child: TextFormField(
        style: TextStyle(fontSize: fontSize),
        controller: title,
        obscureText: obSecure ?? false, // Provide a default value
        focusNode: node,
        validator: validator,
        obscuringCharacter: "*",
        decoration: InputDecoration(
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(15)),
            borderSide: BorderSide(color: AppColors.primaryColor),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(23)),
            borderSide: BorderSide(color: AppColors.primaryColor),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(10)),
            borderSide: BorderSide(color: Colors.red.shade700),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(10)),
            borderSide: BorderSide(color: Colors.red.shade700),
          ),
          contentPadding: EdgeInsets.fromLTRB(padding, contentPaddingVertical, padding, contentPaddingVertical),
          hintText: hintText,
          labelText: labelText,
          hintStyle: TextStyle(
            fontSize: fontSize,

          ),
          labelStyle: TextStyle(
            fontSize: fontSize,

          ),
          prefixIcon: Padding(
            padding: EdgeInsets.all(padding),
            child: Icon(icon, size: iconSize),
          ),
          suffixIcon: suffixIcon,
        ),
      ),
    );
  }
}

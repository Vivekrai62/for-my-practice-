import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:pharma_clients_app/resources/app_colors.dart';
import 'package:pharma_clients_app/utils/text_style.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

// ignore: must_be_immutable
class MainIconsWithFun extends StatelessWidget {
  MainIconsWithFun({
    Key? key,
    this.image,
    this.onPress,
    @required this.title
  }) : super(key: key);

  dynamic onPress;
  dynamic image;
  dynamic title;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onPress,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.asset(
            image,
            height: 10.w,
          ),
          SizedBox(
            height: 0.5.h,
          ),
          title != null ? TextWithStyle.mainIconTitle(context, title, Colors.black) : Container()
        ],
      ),
    );
  }
}

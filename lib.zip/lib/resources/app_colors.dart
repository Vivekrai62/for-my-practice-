import 'package:flutter/material.dart';

class AppColors{

  static Color primaryColor = const Color(0xFF00125C);
  //static Color primaryColor = Color(0xFF760101);
  static Color backgroundColor = const Color(0xFFF9F9F9);
  static Color badgeColor = const Color(0xFFFF0000);
  static Color borderColor = const Color(0xFFD0D4D8);
  static Color iconColor = const Color(0xFF1590D6);
  static Color mrcontaonerheading = Colors.black;

}
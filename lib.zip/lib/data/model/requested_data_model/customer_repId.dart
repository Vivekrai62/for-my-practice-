class CustomerRepId {
  String? id;
  CustomerRepId({this.id});

  Map toJson() => {
    'repId': id,
  };
}
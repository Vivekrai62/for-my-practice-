// ignore_for_file: file_names

class AddToFavEntity {
  List<String>? id;

  AddToFavEntity({
   this.id
  });

  Map toJson() => {
    'products': id,
  };
}

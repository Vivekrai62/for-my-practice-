class UpdateCustomerResponseModel {
  bool? success;
  String? message;
  Data? data;

  UpdateCustomerResponseModel({this.success, this.message, this.data});

  UpdateCustomerResponseModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    message = json['message'];
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    data['message'] = message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  String? id;
  String? name;
  String? email;
  int? phone;
  String? city;
  String? state;
  String? address;
  String? profession;
  String? repId;
  String? franchiseeId;
  String? workingPlace;
  String? dob;
  String? weddingAnniversary;
  String? createdOn;

  Data(
      {this.id,
        this.name,
        this.email,
        this.phone,
        this.city,
        this.state,
        this.address,
        this.profession,
        this.repId,
        this.franchiseeId,
        this.workingPlace,
        this.dob,
        this.weddingAnniversary,
        this.createdOn});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    email = json['email'];
    phone = json['phone'];
    city = json['city'];
    state = json['state'];
    address = json['address'];
    profession = json['profession'];
    repId = json['rep_id'];
    franchiseeId = json['franchisee_id'];
    workingPlace = json['working_place'];
    dob = json['dob'];
    weddingAnniversary = json['wedding_anniversary'];
    createdOn = json['created_on'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['email'] = email;
    data['phone'] = phone;
    data['city'] = city;
    data['state'] = state;
    data['address'] = address;
    data['profession'] = profession;
    data['rep_id'] = repId;
    data['franchisee_id'] = franchiseeId;
    data['working_place'] = workingPlace;
    data['dob'] = dob;
    data['wedding_anniversary'] = weddingAnniversary;
    data['created_on'] = createdOn;
    return data;
  }
}
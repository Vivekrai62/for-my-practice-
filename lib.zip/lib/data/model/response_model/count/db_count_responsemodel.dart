class DashBoardCountResponseModel {
  bool? success;
  String? message;
  Count? data;

  DashBoardCountResponseModel({this.success, this.message, this.data});

  DashBoardCountResponseModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    message = json['message'];
    data = json['data'] != null ? Count.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    data['message'] = message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Count {
  int? productCount;
  int? launchesCount;
  int? visualaidsCount;
  int? favouriteProductCount;
  int? offerCount;
  int? mrCount;
  CompanyOrderCount? companyOrderCount;
  int? orderCount;
  int? upcommingCount;

  Count(
      {this.productCount,
        this.launchesCount,
        this.visualaidsCount,
        this.favouriteProductCount,
        this.offerCount,
        this.mrCount,
        this.companyOrderCount,
        this.orderCount,
        this.upcommingCount});

  Count.fromJson(Map<String, dynamic> json) {
    productCount = json['product_count'];
    launchesCount = json['launches_count'];
    visualaidsCount = json['visualaids_count'];
    favouriteProductCount = json['favourite_product_count'];
    offerCount = json['offer_count'];
    mrCount = json['mr_count'];
    companyOrderCount = json['company_order_count'] != null
        ? CompanyOrderCount.fromJson(json['company_order_count'])
        : null;
    orderCount = json['order_count'];
    upcommingCount = json['upcomming_count'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['product_count'] = productCount;
    data['launches_count'] = launchesCount;
    data['visualaids_count'] = visualaidsCount;
    data['favourite_product_count'] = favouriteProductCount;
    data['offer_count'] = offerCount;
    data['mr_count'] = mrCount;
    if (companyOrderCount != null) {
      data['company_order_count'] = companyOrderCount!.toJson();
    }
    data['order_count'] = orderCount;
    data['upcomming_count'] = upcommingCount;
    return data;
  }
}

class CompanyOrderCount {
  int? count;

  CompanyOrderCount({this.count});

  factory CompanyOrderCount.fromJson(dynamic json) {
    if (json is int) {
      return CompanyOrderCount(count: json);
    } else if (json is Map<String, dynamic>) {
      return CompanyOrderCount(count: json['count']);
    } else {
      throw Exception("Invalid JSON format for company_order_count");
    }
  }

  dynamic toJson() {
    return count;
  }
}

// class DashBoardCountResponseModel {
//   bool? success;
//   String? message;
//   Count? data;
//
//   DashBoardCountResponseModel({this.success, this.message, this.data});
//
//   DashBoardCountResponseModel.fromJson(Map<String, dynamic> json) {
//     success = json['success'];
//     message = json['message'];
//     data = json['data'] != null ? Count.fromJson(json['data']) : null;
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = <String, dynamic>{};
//     data['success'] = success;
//     data['message'] = message;
//     if (this.data != null) {
//       data['data'] = this.data!.toJson();
//     }
//     return data;
//   }
// }

// class Count {
//   int? productCount;
//   int? launchesCount;
//   int? visualaidsCount;
//   int? favouriteProductCount;
//   int? offerCount;
//   int? mrCount;
//   CompanyOrderCount? companyOrderCount;
//   int? orderCount;
//   int? upcomingCount;
//
//   Count({
//     this.productCount,
//     this.launchesCount,
//     this.visualaidsCount,
//     this.favouriteProductCount,
//     this.offerCount,
//     this.mrCount,
//     this.companyOrderCount,
//     this.orderCount,
//     this.upcomingCount,
//   });
//
//   Count.fromJson(Map<String, dynamic> json) {
//     productCount = json['product_count'];
//     launchesCount = json['launches_count'];
//     visualaidsCount = json['visualaids_count'];
//     favouriteProductCount = json['favourite_product_count'];
//     offerCount = json['offer_count'];
//     mrCount = json['mr_count'];
//     companyOrderCount = json['company_order_count'] != null
//         ? CompanyOrderCount.fromJson(json['company_order_count'])
//         : null;
//     orderCount = json['order_count'];
//     upcomingCount = json['upcoming_count'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = <String, dynamic>{};
//     data['product_count'] = productCount;
//     data['launches_count'] = launchesCount;
//     data['visualaids_count'] = visualaidsCount;
//     data['favourite_product_count'] = favouriteProductCount;
//     data['offer_count'] = offerCount;
//     data['mr_count'] = mrCount;
//     if (companyOrderCount != null) {
//       data['company_order_count'] = companyOrderCount!.toJson();
//     }
//     data['order_count'] = orderCount;
//     data['upcoming_count'] = upcomingCount;
//     return data;
//   }
// }
//


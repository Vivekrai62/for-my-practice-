import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:http_interceptor/http_interceptor.dart';
import 'package:pharma_clients_app/data/network/base_api_services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../NavigationServic.dart';
import '../../utils/Dialogue/error_dialogue.dart';
import '../app_excaptions.dart';

class NetworkApiServices extends BaseApiServices {
  Client client = Client();

  @override
  Future<dynamic> deleteApiResponse(String url) async {
    SharedPreferences sp = await SharedPreferences.getInstance();
    String? token = sp.getString('token');

    dynamic responseJson;
    try {
      final client = InterceptedClient.build(
        interceptors: [LoggerInterceptor()],
      );

      final response = await client.delete(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
          "Authorization": "Bearer ${token ?? ''}"
        },
      );
      responseJson = _returnResponse(response);
    } on SocketException {
      throw FetchDataException('No Internet connection');
    }
    if (kDebugMode) {
      log(responseJson.toString());
    }
    return responseJson;
  }

  @override
  Future<dynamic> getApiResponse(String url) async {
    SharedPreferences sp = await SharedPreferences.getInstance();
    String? token = sp.getString('token');

    dynamic responseJson;
    try {
      final response = await client.get(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
          "Authorization": "Bearer ${token ?? ''}"
        },
      );
      responseJson = _returnResponse(response);
    } on SocketException {
      throw FetchDataException('No Internet Connection');
    }
    if (kDebugMode) {
      log(responseJson.toString());
    }
    return responseJson;
  }

  @override
  Future<dynamic> postApiResponse(String url, dynamic data) async {
    dynamic responseJson;
    try {
      final sp = await SharedPreferences.getInstance();
      String? token = sp.getString('token');

      final response = await client.post(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
          "Authorization": "Bearer ${token ?? ''}"
        },
        body: data != null ? jsonEncode(data.toJson()) : '',
      );

      responseJson = _returnResponse(response);
    } on SocketException {
      throw FetchDataException('No Internet connection');
    }
    if (kDebugMode) {
      log(responseJson.toString());
    }
    return responseJson;
  }

  @override
  Future<dynamic> postEmptyParmApiResponse(String url, dynamic bodyParms) async {
    final sp = await SharedPreferences.getInstance();
    String? token = sp.getString('token');

    dynamic responseJson;
    try {
      final client = InterceptedClient.build(interceptors: [LoggerInterceptor()]);

      final response = await client.post(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
          "Authorization": "Bearer ${token ?? ''}"
        },
        body: bodyParms.isNotEmpty ? jsonEncode(bodyParms.toJson()) : '',
      );

      responseJson = _returnResponse(response);
    } on SocketException {
      throw FetchDataException('No Internet connection');
    }
    if (kDebugMode) {
      log(responseJson.toString());
    }
    return responseJson;
  }

  @override
  Future<dynamic> putApiResponse(String url, dynamic bodyParms) async {
    dynamic responseJson;
    try {
      final client = InterceptedClient.build(interceptors: [LoggerInterceptor()]);

      final response = await client.put(
        Uri.parse(url),
        headers: {'Content-Type': 'application/json', "Authorization": ""},
        body: jsonEncode(bodyParms.toJson()),
      );

      responseJson = _returnResponse(response);
    } on SocketException {
      throw FetchDataException('No Internet connection');
    }
    if (kDebugMode) {
      log(responseJson);
    }
    return responseJson;
  }

  dynamic _returnResponse(Response response) {
    switch (response.statusCode) {
      case 200:
      case 400:
      case 401:
      case 403:
      case 404:
      case 422:
      case 500:
        var responseJson = json.decode(response.body.toString());
        if (response.statusCode == 403) {
          _showForbiddenDialog();
        }
        return responseJson;

      default:
        throw FetchDataException(
            'Error occurred while Communication with Server with StatusCode : ${response.statusCode}');
    }
  }

  void _showForbiddenDialog() {
    showDialog(
      context: NavigationService.navigatorKey.currentContext!,
      builder: (BuildContext context) {
        return ErrorDialogue(
          message: 'Please log in again to continue',

        );
      },
    );
  }
}

class LoggerInterceptor implements InterceptorContract {
  @override
  Future<BaseRequest> interceptRequest({required BaseRequest request}) async {
    if (kDebugMode) {
      print("----- Request -----");
      log('Url hit: ${request.url}');
    }
    return request;
  }

  @override
  Future<BaseResponse> interceptResponse({required BaseResponse response}) async {
    if (kDebugMode) {
      print("------- Response -------");
      print(response.statusCode.toString());
    }
    return response;
  }

  Future<bool> shouldInterceptRequest() async => true;

  Future<bool> shouldInterceptResponse() async => true;
}

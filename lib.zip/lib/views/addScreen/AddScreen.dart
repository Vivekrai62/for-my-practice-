import 'package:flutter/material.dart';
import 'package:pharma_clients_app/views/presentation/addPresentationScreen.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

import '../../resources/constant_strings.dart';
import '../../utils/profile_container.dart';
import '../../utils/text_style.dart';
import '../Mr/addMr_Screen.dart';
import '../auth/login_screen.dart';
import '../customer/add_customer.dart';
import '../visits/AddVisitScreen.dart';

class AddScreen extends StatefulWidget {
  AddScreen({super.key, this.isOwner ,this.token});
  dynamic token;
  bool? isOwner;

  @override
  State<AddScreen> createState() => _AddScreenState();
}

class _AddScreenState extends State<AddScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        title: TextWithStyle.appBarTitle(context, ConstantStrings.addScreen),
        elevation: 0,
        toolbarHeight: 6.h,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 1.h,),
            ProfileContainer(
              onPress: () async {
                if (widget.token != null) {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                          const AddPresentationScreen()));
                } else {
                  await Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => LoginScreen()));
                }
              },
              title: 'Add Presentation',
              image: 'assets/images/svg/addpresentation.svg',
            ),
            ProfileContainer(
              onPress: () async {
                if (widget.token != null) {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                          const AddVisitScreen()));
                } else {
                  await Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => LoginScreen()));
                }
              },
              title: 'Add Visits',
              image: 'assets/images/svg/addvisit.svg',
            ),
            ProfileContainer(
              onPress: () async {
                if (widget.token != null) {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                          const AddCustomerScreen()));
                } else {
                  await Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => LoginScreen()));
                }
              },
              title: 'Add Customers',
              image: 'assets/images/svg/addcustomer.svg',
            ),
            widget.isOwner == true || widget.isOwner == null?
            ProfileContainer(
              onPress: () async {
                if (widget.token != null) {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                          const AddMrScreen()));
                } else {
                  await Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => LoginScreen()));
                }
              },
              title: 'Add MRs',
              image: 'assets/images/svg/addmr.svg',
            )
                :Container()

          ],
        ),
      ),
    );;
  }
}

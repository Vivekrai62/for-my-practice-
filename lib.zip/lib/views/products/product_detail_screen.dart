import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pharma_clients_app/data/model/response_model/products/product_reponse_model.dart';
import 'package:pharma_clients_app/resources/app_colors.dart';
import 'package:pharma_clients_app/resources/constant_strings.dart';
import 'package:pharma_clients_app/utils/slider/Slider.dart';
import 'package:pharma_clients_app/utils/text_style.dart';
import 'package:provider/provider.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:share_plus/share_plus.dart';
import '../../data/model/requested_data_model/cartEntity.dart';
import '../../data/response/status.dart';
import '../../utils/Dialogue/error_dialogue.dart';
import '../homescreen/visual_aids_screen.dart';
import 'product_list_widget.dart';
import '../../view_model/afterLogin_viewModel/afterLogin_viewModels.dart';

class ProductDetailScreen extends StatefulWidget {
  final String? id;
  final List<Products> value1;

  const ProductDetailScreen(this.value1, this.id, {super.key});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  late List<String> img = [];
  late List<String> vis = [];
  late List<Products> product;
  final SelectPacking packing = SelectPacking();
  final ProductViewModel model = ProductViewModel();

  @override
  void initState() {
    super.initState();

        if(widget.id == null){
          WidgetsBinding.instance.addPostFrameCallback((_) {
            final packingProvider = Provider.of<SelectPacking>(context, listen: false);
            packingProvider.selectedProducts.clear();
            if (widget.value1[0].packingVarient!.isNotEmpty) {
              packingProvider.toggleSelection(widget.value1[0].packingVarient![0]);
            }
          });
        }else{
          model.fetchProductsApi();
        }

    // Populate img and vis lists

  }

  @override
  void dispose() {
    widget.value1.clear();
    widget.id == null;
    img.clear();
    vis.clear();
    super.dispose();
  }

  String capitalizeWords(String str) {
    List<String> parts = str.split(' ');

    for (int i = 0; i < parts.length; i++) {
      List<String> subParts = parts[i].split('-');
      for (int j = 0; j < subParts.length; j++) {
        if (subParts[j].isNotEmpty) {
          if (j == 0) {
            // Capitalize the first letter of the first part and lower the rest
            subParts[j] = subParts[j][0].toUpperCase() + subParts[j].substring(1).toLowerCase();
          } else {
            // Capitalize the entire word for parts after a hyphen
            subParts[j] = subParts[j].toUpperCase();
          }
        }
      }
      parts[i] = subParts.join('-');
    }

    return parts.join(' ');
  }


  @override
  Widget build(BuildContext context) {

    final cartProvider = Provider.of<Cart>(context, listen: false);

    return widget.id != null
        ? ChangeNotifierProvider(
          create: (BuildContext context) => model,
          child: Consumer<ProductViewModel>(
            builder: (BuildContext context, ProductViewModel value, Widget? child) {
              switch (value.productlist.status!) {
                case Status.loading:
                  return Container(
                    height: MediaQuery.of(context).size.height,
                    width: MediaQuery.of(context).size.width,
                    color: AppColors.backgroundColor,
                    child: Center(
                        child: LoadingAnimationWidget.discreteCircle(
                            color: AppColors.primaryColor,
                            size: 40)
                    ),
                  );
                case Status.error:
                  return Center(
                    child: ErrorDialogue(message: value.productlist.message.toString()),);
                case Status.completed:
                  final List<Products> product = value.products.where((element) => element.id == widget.id).toList();
                  final packingProvider = Provider.of<SelectPacking>(context, listen: false);
                  packingProvider.selectedProducts.clear();
                  if (product[0].packingVarient!.isNotEmpty) {
                    packingProvider.toggleSelection(product[0].packingVarient![0]);
                  }
              return Scaffold(
                appBar: AppBar(
                  elevation: 0,
                  title: TextWithStyle.appBarTitle(context, ConstantStrings.productDetails),
                  actions: [
                    InkWell(
                      onTap: ()=> shareImageTitleAndContent(product),
                      child: Icon(CupertinoIcons.share, size: 3.h),
                    ),
                    SizedBox(width: 3.w),
                  ],
                ),
                body: Column(
                        children: [
                          Expanded(
                            child: SingleChildScrollView(
                              child: Column(
                                children: [
                                  buildImageSlider(product),
                                  buildProductDetails(product),
                                ],
                              ),
                            ),
                          ),
                          buildBottomBar(cartProvider,product),
                        ],
                      ),);
                }
              },
          ),
        )
        : Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: TextWithStyle.appBarTitle(context, ConstantStrings.productDetails),
        actions: [
          InkWell(
            onTap: ()=> shareImageTitleAndContent(widget.value1),
            child: Icon(CupertinoIcons.share, size: 3.h),
          ),
          SizedBox(width: 3.w),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  buildImageSlider(widget.value1),
                  buildProductDetails(widget.value1),
                ],
              ),
            ),
          ),
          buildBottomBar(cartProvider,widget.value1),
        ],
      ),
    );
  }

  Widget buildImageSlider(product) {
    for (var element in product[0].images ?? []) {
      if (element.type == "IMG") {
        img.add(element.url);
      } else if (element.type == "VIS") {
        vis.add(element.url);
      }
    }
    return Container(
      alignment: Alignment.center,
      color: AppColors.backgroundColor,
      margin: EdgeInsets.only(top: 1.h),
      child: img.isNotEmpty
          ? slider(
        images: img,
        aspectRatio: 1.1,
        viewPortFraction: 1.0,
      )
          : Image.asset(
        'assets/images/png/no_image.png',
        height: 50.h,
      ),
    );
  }

  Widget buildProductDetails(product) {
    return Container(
      width: MediaQuery.of(context).size.width,
      margin: EdgeInsets.all(2.h),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          buildTitleRow(product),
          buildCategoryRow(product),
          Divider(thickness: 1, height: 2.h, color: Colors.black.withOpacity(0.1)),
          Text(capitalizeWords(product[0].details ?? 'Na'), style: TextStyle(color: Colors.black, fontSize: 16.sp)),
          Divider(thickness: 1, height: 3.h, color: Colors.black.withOpacity(0.1)),
          buildPackingOptions(product),
          SizedBox(height: 1.h),
          buildVisualAids(),
        ],
      ),
    );
  }

  Widget buildTitleRow(product) {
    return Row(
      children: [
        Expanded(
          child: TextWithStyle.containerTitle(context, capitalizeWords(product[0].name ?? 'NA')),
        ),
      ],
    );
  }

  Widget buildCategoryRow(product) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextWithStyle.mainIconTitle(context, product[0].typeName!, Colors.black45),
        if (product[0].categoryName! != 'NA')
          Container(
            padding: EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.1),
              borderRadius: BorderRadius.all(Radius.circular(5)),
            ),
            child: Text(product[0].categoryName!),
          ),
      ],
    );
  }

  Widget buildPackingOptions(product) {

    if ( product[0].packingVarient?.length != 0 && product[0].packingVarient != null) {
      if(product[0].packingVarient!.length > 1){
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Select Packing:', style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w500)),
            Consumer2<SelectPacking, Cart>(
              builder: (BuildContext context, value, cart, Widget? child) {
                return SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                      children: product[0].packingVarient!.map<Widget>((order) {
                        final count = cart.items.where((element) =>
                        element.id == product[0].id! &&
                            element.packingValue == order.packingType!.value &&
                            element.packing == order.packing &&
                            element.price == order.price).map((e) => e.quantity).join();
                        return GestureDetector(
                          onTap: (){
                            value.toggleSelection(order);
                          },
                          child: Badge(
                            label: Text(count.toString()),
                            isLabelVisible: count.isEmpty ? false : true ,
                            offset: const Offset(-5, 1),
                            child: Container(
                              margin: const EdgeInsets.all(5),
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: value.isSelected(order)? AppColors.primaryColor : Colors.white,
                                borderRadius: const BorderRadius.all(Radius.circular(10)),
                                border: Border.all(color: Colors.black.withOpacity(0.1), width: 1.0), // Light blue border
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.02), // Light blue shadow
                                    spreadRadius: 1,
                                    blurRadius: 6,
                                    offset: const Offset(1, 1), // changes position of shadow
                                  ),
                                ],
                              ),
                              child: Column(
                                children: [
                                  TextWithStyle.mainIconTitle(
                                    context,
                                    order.packingType?.label.toString() ?? 'NA',
                                    value.isSelected(order)? Colors.white : Colors.black,
                                  ),
                                  const SizedBox(height: 5),
                                  TextWithStyle.mainIconTitle(
                                    context,
                                    '(${order.packing ?? 'NA'})',
                                    value.isSelected(order)? Colors.white : Colors.black,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      }).toList()
                  ),
                );
              },
            ),
          ],
        );
      }else{
        return Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Packing:', style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w500)),
            Flexible(
              child: TextWithStyle.productDescription(
                context,
                '${product[0].packingVarient?[0].packingType?.label.toString()} '
                    '(${product[0].packingVarient?[0].packing.toString()})' ?? 'NA',
              ),
            ),
          ],
        );
      }
    } else {
      return Container();
    }
  }

  Widget buildVisualAids() {

    if (vis.isEmpty) return Container();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Visual Aids:', style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.w400)),
        SizedBox(height: 1.h),
        SizedBox(
          height: MediaQuery.of(context).size.height / 8,
          width: MediaQuery.of(context).size.width,
          child: ListView.builder(
            itemCount: vis.length,
            scrollDirection: Axis.horizontal,
            itemBuilder: (context, index) {
              return Card(
                child: InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => ImagePage(images: vis[index], initialIndex: index)));
                  },
                  child: Image.network(vis[index]),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget buildBottomBar(Cart cartProvider, product) {
    return Container(
      height: 10.h,
      padding: EdgeInsets.all(2.h),
      color: Colors.white,
      child: Consumer2<SelectPacking, Cart>(
        builder: (BuildContext context, selectPacking, cart, Widget? child) {
          String itemCount = '0';
          String count = '0';
          double price = 0.0;

          if (selectPacking.selectedProducts.isNotEmpty) {
            final selectedProduct = selectPacking.selectedProducts[0];
            itemCount = cart.itemCount2(
              product[0].id!,
              selectedProduct.packingType?.value ?? '',
              selectedProduct.packing ?? '',
              selectedProduct.price?.toDouble().toString() ?? '0.0',
            ).toString();
            count = cart.items.where((element) =>
            element.id == product[0].id! &&
                element.packingValue == selectedProduct.packingType?.value &&
                element.packing == selectedProduct.packing &&
                element.price == selectedProduct.price)
                .map((e) => e.quantity)
                .join();
            price = selectedProduct.price?.toDouble() ?? 0.0;
          }

          return Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              TextWithStyle.appBarTitle(context, '₹$price'),
              if (itemCount != '0')
                buildQuantityController(cartProvider, selectPacking, count, product)
              else
                buildAddToCartButton(selectPacking, cartProvider, product),
            ],
          );
        },
      ),
    );
  }

  Widget buildQuantityController(Cart cartProvider, SelectPacking selectPacking, String count, product) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        IconButton(
          icon: const Icon(CupertinoIcons.minus_circle_fill),
          iconSize: 4.h,
          color: AppColors.primaryColor,
          onPressed: () {
            cartProvider.removeItem(
              CartEntity(
                id: product[0].id!,
                name: product[0].name!,
                price: selectPacking.selectedProducts[0].price!,
                packing: selectPacking.selectedProducts[0].packing!,
                packingType: selectPacking.selectedProducts[0].packingType!.label!,
                packingValue: selectPacking.selectedProducts[0].packingType!.value!,
              ),
            );
          },
        ),
        TextWithStyle.containerTitle(context, count),
        IconButton(
          icon: const Icon(CupertinoIcons.add_circled_solid),
          iconSize: 4.h,
          color: AppColors.primaryColor,
          onPressed: () {
            cartProvider.addItem(
              CartEntity(
                id: product[0].id!,
                name: product[0].name!,
                price: selectPacking.selectedProducts[0].price!,
                packing: selectPacking.selectedProducts[0].packing!,
                packingType: selectPacking.selectedProducts[0].packingType!.label!,
                packingValue: selectPacking.selectedProducts[0].packingType!.value!,
              ),
            );
          },
        ),
      ],
    );
  }

  Widget buildAddToCartButton(SelectPacking selectPacking, Cart cartProvider, product) {
    return ElevatedButton(
      onPressed: () {
        cartProvider.addItem(
          CartEntity(
            id: product[0].id!,
            name: product[0].name!,
            price: selectPacking.selectedProducts[0].price!,
            packing: selectPacking.selectedProducts[0].packing!,
            packingType: selectPacking.selectedProducts[0].packingType!.label!,
            packingValue: selectPacking.selectedProducts[0].packingType!.value!,
          ),
        );
      },
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.primaryColor,
        padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 1.h),
      ),
      child: TextWithStyle.contactUsTitle(context, ConstantStrings.addToCart),
    );
  }

@override
void shareImageTitleAndContent(product) async {
  print(product[0].images?[0].type);
  try {
    String? imageUrl;
    for (var element in product[0].images ?? []) {
      if (element.type == "IMG") {
        imageUrl = element.url;
        break;
      }
    }
    print(imageUrl);
    if (imageUrl == null) {
      _shareWithoutImage(product);
      return;
    }

    final response = await http.get(Uri.parse(imageUrl));

    if (response.statusCode == 200) {
      final tempDir = await getTemporaryDirectory();
      final filePath = '${tempDir.path}/image.jpg';
      final imageFile = File(filePath);
      await imageFile.writeAsBytes(response.bodyBytes);

      final title = product[0].name ?? 'No Title';
      final description = product[0].description ?? '';
      final typeName = product[0].typeName ?? '';
      final price = product[0].packingVarient?[0].price ?? 0;

      final text = '$title \nDescription: $description\nType: $typeName\nMRP: $price';

      Share.shareXFiles([XFile(filePath)], subject: title, text: text);
    } else {
      print('Failed to download image. Status code: ${response.statusCode}');
    }
  } catch (e) {
    print('Error: $e');
    _shareWithoutImage(product);
  }
}

  void _shareWithoutImage(product) {
    final title = product[0].name ?? 'No Title';
    final description = product[0].description ?? '';
    final typeName = product[0].typeName ?? '';
    final price = product[0].packingVarient?[0].price ?? 0;

    final text = 'No image found\n\n$title \nDescription: $description\nType: $typeName\nMRP: $price';

    Share.share(text, subject: title);
  }
 // void shareImageTitleAndContent(product) async {
 //    print(product[0].images?[0].type);
 //    try {
 //      var imageUrl;
 //      for (var element in product[0].images ?? []) {
 //        if (element.type == "IMG") {
 //          imageUrl = product[0].images?[0].url;
 //        }
 //      }
 //        print(imageUrl);
 //      if (imageUrl == null) {
 //        _shareWithoutImage(product);
 //        return;
 //      }
 //
 //      final response = await http.get(Uri.parse(imageUrl));
 //
 //      if (response.statusCode == 200) {
 //        final tempDir = await getTemporaryDirectory();
 //        final filePath = '${tempDir.path}/image.jpg';
 //        final imageFile = File(filePath);
 //        await imageFile.writeAsBytes(response.bodyBytes);
 //
 //        final title = product[0].name ?? 'No Title';
 //        final description = product[0].description ?? '';
 //        final typeName = product[0].typeName ?? '';
 //        final price = product[0].packingVarient?[0].price ?? 0;
 //
 //        final text = '$title \nDescription: $description\nType: $typeName\nMRP: $price';
 //
 //        Share.shareXFiles([XFile(filePath)], subject: title, text: text);
 //      } else {
 //        print('Failed to download image. Status code: ${response.statusCode}');
 //      }
 //    } catch (e) {
 //      print('Error: $e');
 //      //_shareWithoutImage(product);
 //    }
 //  }
 //  void _shareWithoutImage(product) {
 //    final title = product[0].name ?? 'No Title';
 //    final description = product[0].description ?? '';
 //    final typeName = product[0].typeName ?? '';
 //    final price = product[0].price ?? (product[0].packingVarient?[0].price ?? 0);
 //
 //    final text = 'No image found\n\n$title \nDescription: $description\nType: $typeName\nMRP: $price';
 //
 //    Share.share(text, subject: title);
 //  }
}

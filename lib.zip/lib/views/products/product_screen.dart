import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:pharma_clients_app/data/model/response_model/division_responseModel.dart';
import 'package:pharma_clients_app/resources/constant_imageString.dart';
import 'package:pharma_clients_app/utils/text_style.dart';
import 'package:pharma_clients_app/views/homescreen/home_screen.dart';
import 'package:provider/provider.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import '../../data/model/response_model/products/product_reponse_model.dart';
import '../../data/response/status.dart';
import '../../resources/app_colors.dart';
import '../../resources/constant_strings.dart';
import '../../utils/Dialogue/error_dialogue.dart';
import 'product_list_widget.dart';
import '../../view_model/afterLogin_viewModel/afterLogin_viewModels.dart';
import '../../view_model/beforeLogin_viewModels/beforeLogin_viewModel.dart';

// ignore: must_be_immutable
class ProductScreen extends StatefulWidget {
  ProductScreen({required this.token, required this.isOwner, Key? key})
      : super(key: key);
  String? token;
  bool? isOwner;

  @override
  State<ProductScreen> createState() => _ProductScreenState();
}

class _ProductScreenState extends State<ProductScreen> {
  GuestProductViewModel model = GuestProductViewModel();
  ProductViewModel products = ProductViewModel();
  DivisionsViewModel division = DivisionsViewModel();
  TextEditingController controller = TextEditingController();
  FocusNode searchFocusNode = FocusNode();
  List<Products> value1 = [];
  List<String> product = [];

  final List<CheckBoxItems> items = [];

  @override
  void initState() {
    if (widget.token != null && widget.token!.isNotEmpty) {
      products.fetchProductsApi();
    } else {
      model.fetchProducts();
    }
    division.fetchDivisions();
    value1.clear();
    product.clear();
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    value1.clear();
    product.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            TextWithStyle.appBarTitle(context, ConstantStrings.productScreen),
        automaticallyImplyLeading: true,
        actions: [
          IconButton(
              onPressed: () {
                showModalBottomSheet(
                  context: context,
                  shape: const RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(16.0)),
                  ),
                  backgroundColor: Colors.white,
                  isScrollControlled: true,
                  builder: (BuildContext context) {
                    return widget.token != null && widget.token!.isNotEmpty
                        ? ChangeNotifierProvider.value(
                            value: products,
                            child: Consumer<ProductViewModel>(
                              builder: (context, value, _) {
                                return Container(
                                  height:
                                      MediaQuery.of(context).size.height * 0.8,
                                  width: MediaQuery.of(context).size.width,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        padding: EdgeInsets.only(
                                          left: 2.h,
                                          top: 2.h,
                                        ),
                                        child: TextWithStyle.productTitle(
                                            context, 'Filters'),
                                      ),
                                      Divider(
                                        color: Colors.black.withOpacity(0.1),
                                      ),
                                      Expanded(
                                        child: Row(
                                          children: [
                                            Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width /
                                                  3,
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.only(
                                                    topLeft:
                                                        Radius.circular(2.h)),
                                              ),
                                              child: ListView(
                                                children: value
                                                    .filterOptions.keys
                                                    .map((category) {
                                                  final bool isSelected =
                                                      category ==
                                                          value
                                                              .selectedCategory;
                                                  final selectedCount =
                                                      value.getSelectedCount(
                                                          category);
                                                  return GestureDetector(
                                                    onTap: () {
                                                      value.selectCategory(
                                                          category);
                                                    },
                                                    child: Container(
                                                      color: isSelected
                                                          ? AppColors
                                                              .primaryColor
                                                          : Colors.transparent,
                                                      child: ListTile(
                                                        title: Text(
                                                          '${category} ${selectedCount == 0 ? '' : '(${selectedCount})'}',
                                                          style: TextStyle(
                                                            color: isSelected
                                                                ? Colors.white
                                                                : Colors.black,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  );
                                                }).toList(),
                                              ),
                                            ),
                                            VerticalDivider(
                                              color:
                                                  Colors.black.withOpacity(0.1),
                                              width: 1,
                                            ),
                                            Expanded(
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            left: 8.0,
                                                            right: 8.0,
                                                            bottom: 8.0),
                                                    child: TextField(
                                                      decoration:
                                                          InputDecoration(
                                                              filled: true,
                                                              fillColor: AppColors
                                                                  .primaryColor
                                                                  .withOpacity(
                                                                      0.05),
                                                              enabledBorder: OutlineInputBorder(
                                                                  borderRadius: const BorderRadius.all(
                                                                      Radius.circular(
                                                                          15)),
                                                                  borderSide: BorderSide(
                                                                      color: AppColors
                                                                          .backgroundColor)),
                                                              focusedBorder: OutlineInputBorder(
                                                                  borderRadius: const BorderRadius.all(
                                                                      Radius.circular(
                                                                          15)),
                                                                  borderSide:
                                                                      BorderSide(
                                                                          color: AppColors.backgroundColor)),
                                                              contentPadding: EdgeInsets.all(2.h),
                                                              prefixIcon: Padding(
                                                                padding: EdgeInsets
                                                                    .only(
                                                                        left: 1.4
                                                                            .h,
                                                                        right: 1.4
                                                                            .h),
                                                                child: Image.asset(
                                                                    "assets/images/png/search.png",
                                                                    width: 1.h),
                                                              ),
                                                              border: InputBorder.none,
                                                              hintText: "Search",
                                                              hintStyle: const TextStyle(color: Colors.black38)),
                                                      onChanged: value
                                                          .updateSearchText,
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: ListView(
                                                      padding: EdgeInsets.only(
                                                          left: 10),
                                                      children: value
                                                          .getFilteredOptions()
                                                          .map((option) {
                                                        final isSelected = value
                                                                .selectedFilters[
                                                                    value
                                                                        .selectedCategory]
                                                                ?.contains(
                                                                    option) ==
                                                            true;
                                                        return Column(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            FilterChip(
                                                              label:
                                                                  Text(option),
                                                              backgroundColor:
                                                                  Colors.white,
                                                              selectedColor: AppColors
                                                                  .primaryColor
                                                                  .withOpacity(
                                                                      0.05),
                                                              selected:
                                                                  isSelected,
                                                              onSelected: (_) =>
                                                                  value.toggleFilterOption(
                                                                      value
                                                                          .selectedCategory,
                                                                      option),
                                                            ),
                                                          ],
                                                        );
                                                      }).toList(),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Divider(
                                        color: Colors.black.withOpacity(0.1),
                                      ),
                                      Container(
                                        padding: EdgeInsets.only(
                                            bottom: 3.h,
                                            right: 2.h,
                                            left: 2.h,
                                            top: 0.5.h),
                                        color: Colors.white,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            OutlinedButton(
                                                onPressed: value.clearFilters,
                                                style: OutlinedButton.styleFrom(
                                                    backgroundColor:
                                                        Colors.white,
                                                    shape: RoundedRectangleBorder(
                                                        borderRadius:
                                                            BorderRadius.all(
                                                                Radius.circular(
                                                                    4.h)))),
                                                child: Container(
                                                  padding:
                                                      const EdgeInsets.all(15),
                                                  child: Text('Clear',
                                                      style: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 17.sp,
                                                          fontWeight:
                                                              FontWeight.w400)),
                                                )),
                                            ElevatedButton(
                                              onPressed: () {
                                                products.applyFilters();
                                                print(
                                                    'Selected Filters: ${value.selectedFilters}');
                                                Navigator.of(context).pop();
                                              },
                                              style: ElevatedButton.styleFrom(
                                                  backgroundColor:
                                                      AppColors.primaryColor,
                                                  shape: RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(
                                                                  4.h)))),
                                              child: Container(
                                                padding:
                                                    const EdgeInsets.all(15),
                                                child: Text('Apply',
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 17.sp,
                                                        fontWeight:
                                                            FontWeight.w400)),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          )
                        : ChangeNotifierProvider.value(
                            value: model,
                            child: Consumer<GuestProductViewModel>(
                              builder: (context, value, _) {
                                return Container(
                                  height:
                                      MediaQuery.of(context).size.height * 0.8,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        padding: EdgeInsets.only(
                                          left: 2.h,
                                          top: 2.h,
                                        ),
                                        child: TextWithStyle.productTitle(
                                            context, 'Filters'),
                                      ),
                                      Divider(
                                        color: Colors.black.withOpacity(0.1),
                                      ),
                                      Expanded(
                                        child: Row(
                                          children: [
                                            Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width /
                                                  3,
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.only(
                                                    topLeft:
                                                        Radius.circular(2.h)),
                                              ),
                                              child: ListView(
                                                children: value
                                                    .filterOptions.keys
                                                    .map((category) {
                                                  final bool isSelected =
                                                      category ==
                                                          value
                                                              .selectedCategory;
                                                  final selectedCount =
                                                      value.getSelectedCount(
                                                          category);
                                                  return GestureDetector(
                                                    onTap: () {
                                                      value.selectCategory(
                                                          category);
                                                    },
                                                    child: Container(
                                                      color: isSelected
                                                          ? AppColors
                                                              .primaryColor
                                                          : Colors.transparent,
                                                      child: ListTile(
                                                        title: Text(
                                                          '${category} ${selectedCount == 0 ? '' : '(${selectedCount})'}',
                                                          style: TextStyle(
                                                            color: isSelected
                                                                ? Colors.white
                                                                : Colors.black,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  );
                                                }).toList(),
                                              ),
                                            ),
                                            VerticalDivider(
                                              color:
                                                  Colors.black.withOpacity(0.1),
                                              width: 1,
                                            ),
                                            Expanded(
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            left: 8.0,
                                                            right: 8.0,
                                                            bottom: 8.0),
                                                    child: TextField(
                                                      decoration:
                                                          InputDecoration(
                                                              filled: true,
                                                              fillColor: AppColors
                                                                  .primaryColor
                                                                  .withOpacity(
                                                                      0.05),
                                                              enabledBorder: OutlineInputBorder(
                                                                  borderRadius: const BorderRadius.all(
                                                                      Radius.circular(
                                                                          15)),
                                                                  borderSide: BorderSide(
                                                                      color: AppColors
                                                                          .backgroundColor)),
                                                              focusedBorder: OutlineInputBorder(
                                                                  borderRadius: const BorderRadius.all(
                                                                      Radius.circular(
                                                                          15)),
                                                                  borderSide:
                                                                      BorderSide(
                                                                          color: AppColors.backgroundColor)),
                                                              contentPadding: EdgeInsets.all(2.h),
                                                              prefixIcon: Padding(
                                                                padding: EdgeInsets
                                                                    .only(
                                                                        left: 1.4
                                                                            .h,
                                                                        right: 1.4
                                                                            .h),
                                                                child: Image.asset(
                                                                    "assets/images/png/search.png",
                                                                    width: 1.h),
                                                              ),
                                                              border: InputBorder.none,
                                                              hintText: "Search",
                                                              hintStyle: const TextStyle(color: Colors.black38)),
                                                      onChanged: value
                                                          .updateSearchText,
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: ListView(
                                                      padding: EdgeInsets.only(
                                                          left: 10),
                                                      children: value
                                                          .getFilteredOptions()
                                                          .map((option) {
                                                        final isSelected = value
                                                                .selectedFilters[
                                                                    value
                                                                        .selectedCategory]
                                                                ?.contains(
                                                                    option) ==
                                                            true;
                                                        return Column(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            FilterChip(
                                                              label:
                                                                  Text(option),
                                                              backgroundColor:
                                                                  Colors.white,
                                                              selectedColor: AppColors
                                                                  .primaryColor
                                                                  .withOpacity(
                                                                      0.05),
                                                              selected:
                                                                  isSelected,
                                                              onSelected: (_) =>
                                                                  value.toggleFilterOption(
                                                                      value
                                                                          .selectedCategory,
                                                                      option),
                                                            ),
                                                          ],
                                                        );
                                                      }).toList(),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Divider(
                                        color: Colors.black.withOpacity(0.1),
                                      ),
                                      Container(
                                        padding: EdgeInsets.only(
                                            bottom: 3.h,
                                            right: 2.h,
                                            left: 2.h,
                                            top: 0.5.h),
                                        color: Colors.white,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            OutlinedButton(
                                                onPressed: value.clearFilters,
                                                style: OutlinedButton.styleFrom(
                                                    backgroundColor:
                                                        Colors.white,
                                                    minimumSize: Size(
                                                        MediaQuery.of(context).size.width /
                                                            3,
                                                        MediaQuery.of(context)
                                                                .size
                                                                .height /
                                                            17),
                                                    shape: RoundedRectangleBorder(
                                                        borderRadius:
                                                            BorderRadius.all(
                                                                Radius.circular(
                                                                    4.h)))),
                                                child: Text('Clear',
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontSize: 17.sp,
                                                        fontWeight: FontWeight.w400))),
                                            ElevatedButton(
                                              onPressed: () {
                                                value.applyFilters();
                                                print(
                                                    'Selected Filters: ${value.selectedFilters}');
                                                Navigator.of(context).pop();
                                              },
                                              style: ElevatedButton.styleFrom(
                                                  backgroundColor:
                                                      AppColors.primaryColor,
                                                  minimumSize: Size(
                                                      MediaQuery.of(context)
                                                              .size
                                                              .width /
                                                          3,
                                                      MediaQuery.of(context)
                                                              .size
                                                              .height /
                                                          17),
                                                  shape: RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(
                                                                  4.h)))),
                                              child: Text('Apply',
                                                  style: TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 17.sp,
                                                      fontWeight:
                                                          FontWeight.w400)),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          );
                  },
                );
              },
              icon: const Icon(CupertinoIcons.slider_horizontal_3)),
          SizedBox(
            width: 2.w,
          )
        ],
      ),
      body: widget.token != null && widget.token!.isNotEmpty
          ? ChangeNotifierProvider<ProductViewModel>(
              create: (BuildContext context) => products,
              child: Consumer<ProductViewModel>(builder: (context, value, _) {
                switch (value.productlist.status!) {
                  case Status.loading:
                    return Container(
                      height: MediaQuery.of(context).size.height,
                      width: MediaQuery.of(context).size.width,
                      color: AppColors.backgroundColor,
                      child: Center(
                          child: LoadingAnimationWidget.discreteCircle(
                              color: AppColors.primaryColor, size: 40)),
                    );
                  case Status.error:
                    return Center(
                      child: ErrorDialogue(
                          message: value.productlist.message.toString()),
                    );
                  case Status.completed:
                    return Column(
                      children: [
                        Container(
                          margin: EdgeInsets.only(
                              left: 3.w, right: 3.w, bottom: 2.w),
                          child: TextFormField(
                            style: TextStyle(fontSize: 16.sp),
                            controller: controller,
                            onChanged: (value) {
                              products.updateSearchText(value.toLowerCase());
                            },
                            decoration: InputDecoration(
                                filled: true,
                                fillColor:
                                    AppColors.primaryColor.withOpacity(0.05),
                                enabledBorder: OutlineInputBorder(
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(15)),
                                    borderSide: BorderSide(
                                        color: AppColors.backgroundColor)),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(15)),
                                    borderSide: BorderSide(
                                        color: AppColors.backgroundColor)),
                                contentPadding: EdgeInsets.all(2.h),
                                prefixIcon: Padding(
                                  padding: EdgeInsets.only(
                                      left: 1.4.h, right: 1.4.h),
                                  child: Image.asset(
                                      "assets/images/png/search.png",
                                      width: 1.h),
                                ),
                                border: InputBorder.none,
                                hintText: "Search",
                                hintStyle:
                                    const TextStyle(color: Colors.black38)),
                          ),
                        ),
                        Expanded(
                            child: ProductList(
                          product: value.products,
                          token: widget.token,
                        )),
                        Container(
                          padding: EdgeInsets.only(
                              left: 5.w, bottom: 3.w, top: 2.w, right: 5.w),
                          color: Colors.white,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Consumer<Cart>(
                                builder: (BuildContext context, value,
                                    Widget? child) {
                                  return TextWithStyle.appToCart(
                                      context, '${value.items.length} Items');
                                },
                              ),
                              ElevatedButton(
                                onPressed: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => HomeScreen(
                                                token: widget.token,
                                                isOwner: widget.isOwner,
                                                initialTabIndex: 2,
                                              )));
                                },
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: AppColors.primaryColor,
                                    minimumSize: Size(
                                        MediaQuery.of(context).size.width / 4,
                                        MediaQuery.of(context).size.height /
                                            18),
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(4.h)))),
                                child: Text('Next',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 17.sp,
                                        fontWeight: FontWeight.w400)),
                              )
                            ],
                          ),
                        )
                      ],
                    );
                }
              }),
            )
          : ChangeNotifierProvider<GuestProductViewModel>(
              create: (BuildContext context) => model,
              child: Consumer<GuestProductViewModel>(
                builder: (context, value, _) {
                  switch (value.productlist.status!) {
                    case Status.loading:
                      return Container(
                        height: MediaQuery.of(context).size.height,
                        width: MediaQuery.of(context).size.width,
                        color: AppColors.backgroundColor,
                        child: Center(
                            child: LoadingAnimationWidget.discreteCircle(
                                color: AppColors.primaryColor, size: 40)),
                      );
                    case Status.error:
                      return Center(
                        child: Text(value.productlist.message.toString()),
                      );
                    case Status.completed:
                      return Column(
                        children: [
                          Row(
                            children: [
                              Expanded(
                                  child: Container(
                                margin: EdgeInsets.only(
                                    left: 3.w, right: 3.w, bottom: 2.w),
                                child: TextFormField(
                                  style: TextStyle(fontSize: 16.sp),
                                  controller: controller,
                                  onChanged: (value) {
                                    model.updateSearchText(value.toLowerCase());
                                  },
                                  decoration: InputDecoration(
                                    filled: true,
                                    fillColor: AppColors.primaryColor
                                        .withOpacity(0.05),
                                    enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(15)),
                                        borderSide: BorderSide(
                                            color: AppColors.backgroundColor)),
                                    focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(15)),
                                        borderSide: BorderSide(
                                            color: AppColors.backgroundColor)),
                                    contentPadding: EdgeInsets.all(2.h),
                                    prefixIcon: Padding(
                                      padding: EdgeInsets.only(
                                          left: 1.4.h, right: 1.4.h),
                                      child: Image.asset(ConstantImage.search,
                                          width: 1.h),
                                    ),
                                    border: InputBorder.none,
                                    hintText: "Search",
                                    hintStyle: TextStyle(color: Colors.black38),
                                  ),
                                ),
                              )),
                            ],
                          ),
                          Expanded(
                              child: ProductList(
                            product: value.products,
                            token: widget.token,
                          ))
                        ],
                      );
                  }
                },
              ),
            ),
    );
  }
}

class CheckBoxItems {
  bool selected;
  String name;

  CheckBoxItems({
    this.selected = false,
    required this.name,
  });
}

class ProductByDivision extends ChangeNotifier {
  final List<Data> _selectedDivisions = [];

  List<Data> get selectedDivisions => _selectedDivisions;

  void addDivision(Data division) {
    _selectedDivisions.add(division);
    notifyListeners();
  }

  void removeDivision(Data division) {
    _selectedDivisions.remove(division);
    notifyListeners();
  }

  bool isSelected(Data division) {
    return _selectedDivisions.contains(division);
  }
}

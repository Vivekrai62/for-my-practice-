// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:pharma_clients_app/view_model/afterLogin_viewModel/afterLogin_viewModels.dart';
// import 'package:pharma_clients_app/views/SplashScreen/splash_screen.dart';
// import 'package:pharma_clients_app/views/homescreen/home_screen.dart';
// import 'package:provider/provider.dart';
// import 'package:responsive_sizer/responsive_sizer.dart';
// import '../../resources/app_colors.dart';
// import '../../resources/constant_strings.dart';
// import '../../utils/Responsive/ResponsiveUtils.dart';
// import '../../utils/text_style.dart';
//
// class NotificationScreen extends StatelessWidget {
//   const NotificationScreen({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     final provider = Provider.of<NotificationList>(context,listen: false);
//     return FutureBuilder(
//         future: provider.loadNotifications(),
//         builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
//                   return Scaffold(
//                     appBar: AppBar(
//                       centerTitle: false,
//                       elevation: 0,
//                       automaticallyImplyLeading: false, // Disable automatic leading to customize it
//                       leading: IconButton(
//                         icon: Icon(
//                           Icons.arrow_back, // Replace with your desired icon
//                           size: Responsive.isDesktop(context)
//                               ? 40.0 // Bigger size for Desktop
//                               : Responsive.isTablet(context)
//                               ? 35.0 // Medium size for Tablet
//                               : 28.0, // Smaller size for Mobile
//                         ),
//                         onPressed: () {
//                           Navigator.of(context).pop(); // Add desired functionality here
//                         },
//                       ),
//                       title: TextWithStyle.appBarTitle(
//                         context,
//                         ConstantStrings.notificationHeading,
//                       ),
//                     ),
//
//                     body: Consumer<NotificationList>(
//                       builder: (BuildContext context, value, Widget? child) {
//                         return value.notifications.isNotEmpty
//                             ? ListView.builder(
//                             itemCount: value.notifications.length,
//                             itemBuilder: (BuildContext context, int index) {
//                               final val = value.notifications[index];
//                               return Container(
//                                 margin: EdgeInsets.only(left: 1.h, right: 1.h, top: 1.h),
//                                 padding: EdgeInsets.only(left: 2.h,bottom: 0.5.h),
//                                 decoration: BoxDecoration(
//                                   color: Colors.white,
//                                   borderRadius: BorderRadius.all(Radius.circular(1.h)),
//                                   boxShadow: [
//                                     BoxShadow(
//                                       color:
//                                       AppColors.primaryColor.withOpacity(0.1),
//                                       spreadRadius: 1,
//                                       blurRadius: 4,
//                                       offset: const Offset(0, 0),
//                                     )
//                                   ],
//                                 ),
//                                 child: ListTile(
//                                   title: TextWithStyle.containerTitle(context, val.title),
//                                   subtitle: TextWithStyle.productDescription(context, val.message),
//                                   trailing: IconButton(onPressed: (){
//                                     provider.removeNotification(index);
//                                   }, icon: const Icon(Icons.delete)),
//
//                                 ),
//                               );
//                             })
//                             : const Center(
//                           child: Text('No Notifications found.'),
//                         );
//                       },
//                     ),
//                   );
//         },
//       );
//   }
// }
//


import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pharma_clients_app/view_model/afterLogin_viewModel/afterLogin_viewModels.dart';
import 'package:pharma_clients_app/views/SplashScreen/splash_screen.dart';
import 'package:pharma_clients_app/views/homescreen/home_screen.dart';
import 'package:provider/provider.dart';
import '../../resources/app_colors.dart';
import '../../resources/constant_strings.dart';
import '../../utils/Responsive/ResponsiveUtils.dart';
import '../../utils/text_style.dart';

class NotificationScreen extends StatelessWidget {
  const NotificationScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<NotificationList>(context, listen: false);
    return FutureBuilder(
      future: provider.loadNotifications(),
      builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
        return Scaffold(
          appBar: AppBar(
            centerTitle: false,
            elevation: 0,
            automaticallyImplyLeading: false, // Disable automatic leading to customize it
            leading: IconButton(
              icon: Icon(
                Icons.arrow_back, // Replace with your desired icon
                size: MediaQuery.of(context).size.width > 1200
                    ? 40.0 // Bigger size for Desktop
                    : MediaQuery.of(context).size.width > 768
                    ? 35.0 // Medium size for Tablet
                    : 28.0, // Smaller size for Mobile
              ),
              onPressed: () {
                Navigator.of(context).pop(); // Add desired functionality here
              },
            ),
            title: TextWithStyle.appBarTitle(
              context,
              ConstantStrings.notificationHeading,
            ),
          ),
          body: Consumer<NotificationList>(
            builder: (BuildContext context, value, Widget? child) {
              return value.notifications.isNotEmpty
                  ? ListView.builder(
                itemCount: value.notifications.length,
                itemBuilder: (BuildContext context, int index) {
                  final val = value.notifications[index];

                  // Responsive margin and padding based on screen size
                  double marginHorizontal = MediaQuery.of(context).size.width > 1200
                      ? 30.0 // Desktop
                      : MediaQuery.of(context).size.width > 768
                      ? 20.0 // Tablet
                      : 10.0; // Mobile

                  double paddingVertical = MediaQuery.of(context).size.width > 1200
                      ? 15.0 // Desktop
                      : MediaQuery.of(context).size.width > 768
                      ? 10.0 // Tablet
                      : 5.0; // Mobile

                  return Container(
                    margin: EdgeInsets.symmetric(
                        horizontal: marginHorizontal,
                        vertical: paddingVertical),
                    padding: EdgeInsets.symmetric(
                        horizontal: marginHorizontal,
                        vertical: paddingVertical),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(12.0)),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.primaryColor.withOpacity(0.1),
                          spreadRadius: 1,
                          blurRadius: 4,
                          offset: const Offset(0, 0),
                        )
                      ],
                    ),
                    child: ListTile(
                      title: TextWithStyle.containerTitle(context, val.title),
                      subtitle: TextWithStyle.productDescription(context, val.message),
                      trailing: IconButton(
                        onPressed: () {
                          provider.removeNotification(index);
                        },
                        icon: const Icon(Icons.delete),
                      ),
                    ),
                  );
                },
              )
                  :  Center(
                  child:
                  Text('No Notifications found.',style: TextStyle(
                    color: Colors.black,

                    fontSize: Responsive.isMobile(context)
                        ? 15.0 // Width for Desktop
                        : (Responsive.isTablet(context)
                        ? 30.32 // Width for Tablet
                        : 14.0

                    ), // Wi

                  )
                  ));
            },
          ),
        );
      },
    );
  }
}


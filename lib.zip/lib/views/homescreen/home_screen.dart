import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:pharma_clients_app/utils/Responsive/ResponsiveUtils.dart';
import 'package:pharma_clients_app/utils/utils.dart';
import 'package:pharma_clients_app/view_model/services/notification_services.dart';
import 'package:pharma_clients_app/views/homescreen/NotificationScreen.dart';
import 'package:pharma_clients_app/views/Screens/calculator.dart';
import 'package:pharma_clients_app/views/addScreen/AddScreen.dart';
import 'package:pharma_clients_app/views/customer/customers_screen.dart';
import 'package:pharma_clients_app/views/homescreen/selfAnalysisScreen.dart';
import 'package:pharma_clients_app/views/presentation/presentaionListScreen.dart';
import 'package:pharma_clients_app/views/products/favouriteScreen.dart';
import 'package:pharma_clients_app/views/visits/visits_screen.dart';
import 'package:provider/provider.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../data/model/response_model/about_company/about_company_response_model.dart';
import '../../data/response/status.dart';
import '../../resources/app_colors.dart';
import '../../resources/constant_strings.dart';
import '../../utils/IconWithFun/png_with_fun.dart';
import '../../utils/IconWithFun/mainIcons_with_fun.dart';
import '../../utils/Dialogue/error_dialogue.dart';
import '../../utils/scroll_state/scroll_state.dart';
import '../../utils/slider/Slider.dart';
import '../../utils/text_style.dart';
import '../../view_model/afterLogin_viewModel/afterLogin_viewModels.dart';
import '../../view_model/beforeLogin_viewModels/beforeLogin_viewModel.dart';
import '../../view_model/login_viewmodel.dart';
import '../Mr/MrsScreen.dart';
import 'cart_screen.dart';
import '../customer/customersOrderScreen.dart';
import 'myOrderScreen.dart';
import '../products/product_screen.dart';
import 'divisons_screen.dart';
import 'enquiry_screen.dart';
import '../products/new_launched.dart';
import 'offer_screen.dart';
import '../Screens/profile_screen.dart';
import 'promotional.dart';
import '../products/upcoming_products.dart';
import 'visual_aids_screen.dart';
import '../auth/login_screen.dart';


class HomeScreen extends StatefulWidget {
  final String? token;
  final bool? isOwner;
  final int? initialTabIndex;

  HomeScreen({required this.token, this.isOwner, Key? key, this.initialTabIndex}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  AboutCompanyViewModel model = AboutCompanyViewModel();
  LoginViewModel loginModel = LoginViewModel();
  GuestDbCountViewModel dbCount = GuestDbCountViewModel();
  NotificationServices notificationServices = NotificationServices();
  DbCountViewModel count = DbCountViewModel();
  List<AboutCompany> about = [];
  int _selectedIndex = 0;

  final List<String> _labels = [
    'Home',
    'Customers',
    'Cart',
    'Profile',
  ];

  @override
  void initState() {
    super.initState();
    _selectedIndex = widget.initialTabIndex ?? 0;
    notificationServices.requestNotificationPermission(widget.isOwner, widget.token);
    notificationServices.foregroundMessage();
    notificationServices.firebaseInit(context, widget.isOwner, widget.token);
    notificationServices.setupInteractMessage(context, widget.isOwner, widget.token);
    notificationServices.isTokenRefresh();
    getCount();
    getData();
  }

  Future<void> getCount() async {
    if (widget.token != null && widget.token!.isNotEmpty) {
      await count.fetchCountApi(context);
      getData();
    } else {
      await dbCount.fetchDbCountApi();
    }
  }

  Future<void> getData() async {
    await model.fetchAboutCompany();
  }

  Future<bool?> _onWillPop() async {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Are you sure?'),
        content: const Text('Do you want to exit the App?'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('No'),
          ),
          TextButton(
            onPressed: () => exit(0),
            child: const Text('Yes'),
          ),
        ],
      ),
    );
  }

  Widget _buildIcon(int index) {
    final cart = Provider.of<Cart>(context, listen: false);

    double iconSize;
    if (Responsive.isDesktop(context)) {
      iconSize = 48; // Size for desktop
    } else if (Responsive.isTablet(context)) {
      iconSize = 65; // Size for tablet
    } else {
      iconSize = 32; // Size for mobile
    }

    switch (index) {
      case 0:
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/home.png'
              : 'assets/images/png/home_outlined.png',
          width: iconSize,
        );
      case 1:
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/customers.png'
              : 'assets/images/png/customers_outlined.png',
          width: iconSize,
        );
      case 2:
        return FutureBuilder(
          future: cart.loadCart(),
          builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
            return Consumer<Cart>(
              builder: (BuildContext context, value, Widget? child) {
                return Badge(
                  label: Text(
                    value.items.length.toString(),
                    style: TextStyle(fontSize: 12),
                  ),
                  isLabelVisible: true,
                  backgroundColor: AppColors.badgeColor,
                  alignment: Alignment.topRight,
                  child: Image.asset(
                    _selectedIndex == index
                        ? 'assets/images/png/cart_filled.png'
                        : 'assets/images/png/cart_outlined.png',
                    width: iconSize,
                  ),
                );
              },
            );
          },
        );
      case 3:
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/profile.png'
              : 'assets/images/png/profile_outlined.png',
          width: iconSize,
        );
      default:
        return const SizedBox();
    }
  }


  Widget _buildScreen(int index) {
    switch (index) {
      case 0:
        return DashboardScreen(isOwner: widget.isOwner, token: widget.token, aboutCompany: about);
      case 1:
        return widget.token != null && widget.token!.isNotEmpty ? const CustomersScreen() : LoginScreen();
      case 2:
        return widget.token != null && widget.token!.isNotEmpty ? CartScreen(owner: widget.token, isOwner: widget.isOwner) : LoginScreen();
      case 3:
        return widget.token != null && widget.token!.isNotEmpty ? ProfileScreen(value: about, isOwner: widget.isOwner) : LoginScreen();
      default:
        return Container();
    }
  }
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        bool? result = await _onWillPop();
        result ??= false;
        return result;
      },
      child: ChangeNotifierProvider<AboutCompanyViewModel>(
        create: (BuildContext context) => model,
        child: Consumer<AboutCompanyViewModel>(builder: (context, value, _) {
          switch (value.aboutCompany.status!) {
            case Status.loading:
              return Container(
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                color: AppColors.backgroundColor,
                child: Center(
                  child: LoadingAnimationWidget.discreteCircle(
                    color: AppColors.primaryColor,
                    size: 40,
                  ),
                ),
              );
            case Status.error:
              return ErrorDialogue(
                message: value.aboutCompany.message,
              );
            case Status.completed:
              about.add(value.aboutCompany.data!.data!);

              return Scaffold(
                key: _scaffoldKey,
                body: Row(


                  children: [
                    if (isTablet(context))
                      NavigationRail(
                        backgroundColor: AppColors.backgroundColor,
                        selectedIndex: _selectedIndex == 3 ? 0 : _selectedIndex, // Set to a valid index if Profile is selected
                        onDestinationSelected: (int index) {
                          setState(() {
                            _selectedIndex = index;
                          });
                        },
                        labelType: NavigationRailLabelType.all,
                        selectedLabelTextStyle: TextStyle(
                          color: AppColors.primaryColor,
                          fontSize: 14.5,
                          fontWeight: FontWeight.w700,
                        ),
                        unselectedLabelTextStyle: TextStyle(
                          color: Colors.black.withOpacity(0.6),
                          fontSize: 14.5,
                          fontWeight: FontWeight.w500,
                        ),
                        destinations: [
                          NavigationRailDestination(
                            icon: Padding(
                              padding: const EdgeInsets.only(bottom: 20.0), // Add space below 'Home'
                              child: _buildIcon(0),
                            ),
                            label: Padding(
                              padding: const EdgeInsets.only(bottom: 20.0), // Add space below the label
                              child: Text(_labels[0]),
                            ),
                          ),
                          NavigationRailDestination(
                            icon: Padding(
                              padding: const EdgeInsets.only(bottom: 20.0), // Add space below 'Customers'
                              child: _buildIcon(1),
                            ),
                            label: Padding(
                              padding: const EdgeInsets.only(bottom: 20.0), // Add space below the label
                              child: Text(_labels[1]),
                            ),
                          ),
                          NavigationRailDestination(
                            icon: Padding(
                              padding: const EdgeInsets.only(bottom: 20.0), // Add space below 'Cart'
                              child: _buildIcon(2),
                            ),
                            label: Padding(
                              padding: const EdgeInsets.only(bottom: 20.0), // Add space below the label
                              child: Text(_labels[2]),
                            ),
                          ),
                        ],
                        trailing: Expanded(
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: Padding(
                              padding: EdgeInsets.only(bottom: 20),
                              child: InkWell(
                                onTap: () {
                                  setState(() {
                                    _selectedIndex = 3;
                                  });
                                },
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    _buildIcon(3),
                                    SizedBox(height: 4),
                                    Text(
                                      _labels[3],
                                      style: TextStyle(
                                        color: _selectedIndex == 3 ? AppColors.primaryColor : Colors.black.withOpacity(0.6),
                                        fontSize: 14.5,
                                        fontWeight: _selectedIndex == 3 ? FontWeight.w700 : FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),


                    if (isTablet(context))
                      const VerticalDivider(thickness: 1, width: 1),
                    Expanded(
                      child: Column(
                        children: [
                          const SizedBox(height: 20),
                          Expanded(
                            child: Center(child: _buildScreen(_selectedIndex)),
                          ),
                          const SizedBox(height: 20),
                        ],
                      ),
                    ),
                  ],
                ),
                bottomNavigationBar: !isTablet(context) && widget.token != null && widget.token!.isNotEmpty
                    ? BottomNavigationBar(
                  backgroundColor: Colors.white,
                  type: BottomNavigationBarType.fixed,
                  selectedLabelStyle: TextStyle(fontSize: 14),
                  selectedItemColor: AppColors.primaryColor,
                  unselectedItemColor: Colors.grey,
                  currentIndex: _selectedIndex,
                  onTap: (index) {
                    setState(() {
                      _selectedIndex = index;
                    });
                  },
                  items: [
                    for (int index = 0; index < 4; index++)
                      BottomNavigationBarItem(
                        icon: _buildIcon(index),
                        label: _labels[index],
                      ),
                  ],
                )
                    : null,
              );
          }
        }),
      ),
    );
  }

  bool isTablet(BuildContext context) {
    final data = MediaQuery.of(context);
    return data.size.shortestSide >= 600;
  }
}


class DashboardScreen extends StatefulWidget {
  final String? token;
  final bool? isOwner;
  final List<AboutCompany> aboutCompany;

  const DashboardScreen({Key? key, this.token, this.isOwner, required this.aboutCompany})
      : super(key: key);

  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}


class _DashboardScreenState extends State<DashboardScreen> {
  AboutCompanyViewModel model = AboutCompanyViewModel();
  GuestDbCountViewModel dbcount = GuestDbCountViewModel();
  DbCountViewModel count = DbCountViewModel();
  String? userName;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    getCount();
    getUserInfo();
  }

  Future<void> getCount() async {
    if (widget.token != null && widget.token!.isNotEmpty) {
      await count.fetchCountApi(context);
      getData();
    } else {
      await dbcount.fetchDbCountApi();
    }
  }

  Future<void> getData() async {
    await model.fetchAboutCompany();
  }

  Future<void> getUserInfo() async {
    final SharedPreferences sp = await SharedPreferences.getInstance();
    userName = sp.getString('name');
  }

  @override
  Widget build(BuildContext context) {
    return widget.token != null && widget.token!.isNotEmpty
        ? ChangeNotifierProvider<DbCountViewModel>(
      create: (BuildContext context) => count,
      child: Consumer<DbCountViewModel>(
        builder: (context, val, _) {
          return val.loading == false
              ? buildDashboard(val)
              : buildLoadingScreen(context);
        },
      ),
    )
        : ChangeNotifierProvider<GuestDbCountViewModel>(
      create: (BuildContext context) => dbcount,
      child: Consumer<GuestDbCountViewModel>(
        builder: (context, val, _) {
          return val.loading == false
              ? buildDashboard(val)
              : buildLoadingScreen(context);
        },
      ),
    );
  }

  Widget buildDashboard(val) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: buildAppBar(),
      body: RefreshIndicator(
        onRefresh: getCount,
        child: Responsive(
          mobile: buildMobileLayout(val),
          tablet: buildTabletLayout(val),
          desktop: buildDesktopLayout(val),
        ),
      ),
      floatingActionButton: buildFloatingActionButton(),
    );
  }

  AppBar buildAppBar() {
    return AppBar(
      // toolbarHeight: Responsive.isTablet(context) ? 64 : 56,
      toolbarHeight: Responsive.isMobile(context) ? 36 : 56,
      automaticallyImplyLeading: false,
      elevation: 0,
      title: Column(
        children: [
          widget.token == null
              ? AppBarUtils.appBarTitle(context, ConstantStrings.dashboardScreen)
              : Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                'Hi,',
                style: TextStyle(
                  color: Colors.black54,
                  fontSize: Responsive.isDesktop(context)
                      ? 60.0 // Width for Desktop
                      : (Responsive.isTablet(context)
                      ? 30.32 // Width for Tablet
                      : 20.0), // Width for Mobile

                ),
              ),
              const SizedBox(width: 8),
              Text(
                "${userName}",
                style: TextStyle(
                    color: Colors.black,

                  fontSize: Responsive.isMobile(context)
                      ? 20.0 // Width for Desktop
                      : (Responsive.isTablet(context)
                      ? 30.32 // Width for Tablet
                      : 16.0

                  ), // Wi
                  fontWeight: FontWeight.w600,
                )
              ),
            ],
          ),
        ],
      ),
      actions: [
        IconButton(
          onPressed: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const NotificationScreen()));
          },
          icon: Image.asset(
            'assets/images/png/notification.png',
            // Adjust the width based on the device type
            width: Responsive.isDesktop(context)
                ? 60.0 // Width for Desktop
                : (Responsive.isTablet(context)
                ? 45.0 // Width for Tablet
                : 25.0), // Width for Mobile
          ),

        ),   SizedBox(
          width: Responsive.isTablet(context) ? 30 : (Responsive.isDesktop(context) ? 30 : 10),
        ),

        widget.token == null
            ? IconButton(
          onPressed: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => LoginScreen()));
          },

          icon: Image.asset(
            'assets/images/png/profile.png',
            // Adjust the width based on the device type
            width: Responsive.isDesktop(context)
                ? 60.0 // Width for Desktop
                : (Responsive.isTablet(context)
                ? 45.0 // Width for Tablet
                : 25.0), // Width for Mobile
          ),
        )
            : Container(),
       SizedBox(
          width: Responsive.isDesktop(context)
              ? 30
              : (Responsive.isTablet(context)
              ? 30
              : 10),
        )

      ],
    );
  }

  Widget buildMobileLayout(val) {
    return SingleChildScrollView(
      child: Column(
        children: [
          buildSlider(),
          buildCategories(val),
          buildGridItems(val),


        ],
      ),
    );
  }

  Widget buildSlider() {
    return LayoutBuilder(
      builder: (context, constraints) {

        final maxHeight = constraints.maxHeight * 0.3;

        return Container(
          margin: EdgeInsets.symmetric(vertical: 13),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: maxHeight,
            ),
            child: slider(
              images: widget.aboutCompany[0].aboutImgs!,
              aspectRatio: 2 / 1,
              viewPortFraction: 0.97,
            ),
          ),
        );
      },
    );
  }


  Widget buildTabletLayout(val) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          buildSlider(),
          buildCategories(val),
          buildGridItems(val),
        ],
      ),
    );
  }





  Widget buildDesktopLayout(val) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(flex: 1, child: buildCategories(val)),
        Expanded(flex: 2, child: buildGridItems(val)),
      ],
    );
  }

  Widget buildCategories(val) {
    return
      Container(
        margin: EdgeInsets.only(
            left: MediaQuery.of(context).size.width * 0.03,
            right: MediaQuery.of(context).size.width * 0.03,
            top: MediaQuery.of(context).size.width * 0.02,
            bottom: 0.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextWithStyle.containerTitle(context, 'Categories'),
            SizedBox(height: MediaQuery.of(context).size.height * 0.01),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Container(
                    padding: EdgeInsets.only(
                        top: MediaQuery.of(context).size.height / 60,
                        bottom: MediaQuery.of(context).size.height / 140),
                    child: Column(
                      children: [
                        MainIconsWithFun(
                          title: ConstantStrings.productScreen,
                          image: 'assets/images/png/products.png',
                          onPress: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ProductScreen(
                                token: widget.token,
                                isOwner: widget.isOwner,
                              ),
                            ),
                          ),
                        ),
                        Text(
                          val.data?.productCount.toString() ?? '0',
                          style: TextStyle(
                            fontSize: Responsive.isDesktop(context)
                                ? 60.0 // Width for Desktop
                                : (Responsive.isTablet(context)
                                ? 22.0 // Width for Tablet
                                : 12.0), // Width for
                            color: Colors.black54,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Container(
                    padding: EdgeInsets.only(
                        top: MediaQuery.of(context).size.height / 60,
                        bottom: MediaQuery.of(context).size.height / 140),
                    child: Column(
                      children: [
                        MainIconsWithFun(
                          title: ConstantStrings.visualAidsScreen,
                          image: 'assets/images/png/visualaids.png',
                          onPress: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => VisualAidsScreen(
                                token: widget.token,
                              ),
                            ),
                          ),
                        ),
                        Text(
                          "",
                          style: TextStyle(
                            fontSize: MediaQuery.of(context).size.width * 0.035,
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                widget.isOwner == true || widget.isOwner == null
                    ? Expanded(
                  child: Container(
                    padding: EdgeInsets.only(
                        top: MediaQuery.of(context).size.height / 60,
                        bottom: MediaQuery.of(context).size.height / 140),
                    child: Column(
                      children: [
                        MainIconsWithFun(
                          title: ConstantStrings.mrs,
                          image: 'assets/images/png/mrs.png',
                          onPress: () async {
                            if (widget.token != null) {
                              await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                      const MrsScreen()));
                            } else {
                              await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          LoginScreen()));
                            }
                          },
                        ),
                        Text(
                          '',
                          style: TextStyle(
                            fontSize:
                            MediaQuery.of(context).size.width * 0.04,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                )
                    : Container(),
                const SizedBox(width: 10),
                Expanded(
                  child: Container(
                    padding: EdgeInsets.only(
                        top: MediaQuery.of(context).size.height / 60,
                        bottom: MediaQuery.of(context).size.height / 140),
                    child: Column(
                      children: [
                        MainIconsWithFun(
                            title: ConstantStrings.myOrders,
                            image: 'assets/images/png/orders.png',
                            onPress: () {
                              widget.token != null &&
                                  widget.token!.isNotEmpty
                                  ? widget.isOwner == true
                                  ? Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                    const MyOrderScreen()),
                              )
                                  : Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                    const CustomersOrderScreen()),
                              )
                                  : Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => LoginScreen()),
                              );
                            }),
                        Text(
                          widget.token != null && widget.token!.isNotEmpty
                              ? widget.isOwner == true
                              ? val.dataa?.companyOrderCount.count
                              .toString()
                              .length ==
                              1
                              ? '0${val.dataa?.companyOrderCount.count.toString()}'
                              : val.dataa?.companyOrderCount.count
                              .toString() ??
                              '0'
                              : val.data?.orderCount.toString() ?? '0'
                              : '0',
                          style: TextStyle(
                            fontSize:
                            Responsive.isDesktop(context)
                                ? 60.0 // Width for Desktop
                                : (Responsive.isTablet(context)
                                ? 22.0 // Width for Tablet
                                : 12.0), // Width for
                            color: Colors.black54,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const Divider(
              color: Colors.black12,
              height: 10,
            ),
          ],
        ),
      );

  }

  Widget buildGridItems(val) {
    return
      GridView.count(
      physics: const NeverScrollableScrollPhysics(),
      primary: false,
      shrinkWrap: true,
      padding: EdgeInsets.all(MediaQuery.of(context).size.height /100),
      crossAxisCount: Responsive.isTablet(context) ? 4 :4,
      children: [
        buildGridItem(
          ConstantStrings.upcomingScreen,
          'assets/images/png/upcoming_products.png',
              () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => UpcomingProductScreen(token: widget.token),
            ),
          ),
        ),
        buildGridItem(
          ConstantStrings.divisions,
          'assets/images/png/divisons.png',
              () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  DivisionScreen(token: widget.token, value: widget.aboutCompany),
            ),
          ),
        ),
        buildGridItem(
          ConstantStrings.presentation,
          'assets/images/png/slides.png',
              () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>  PresentationListScreen(),
            ),
          ),
        ),
        buildGridItem(
          ConstantStrings.visits,
          'assets/images/png/visits.png',
              () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const VisitsScreen(),
            ),
          ),
        ),
        buildGridItem(
          ConstantStrings.selfAnalysis,
          'assets/images/png/self_analysis.png',
              () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const SelfAnalysisScreen(),
            ),
          ),
        ),
        buildGridItem(
          ConstantStrings.newLaunches,
          'assets/images/png/new_launches.png',
              () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => NewLaunchedProductScreen(token: widget.token),
            ),
          ),
        ),
        buildGridItem(
          ConstantStrings.ptrpts,
          'assets/images/png/ptrpts.png',
              () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const Calculator(),
            ),
          ),
        ),
        buildGridItem(
          ConstantStrings.enquiry,
          'assets/images/png/connectwithus.png',
              () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => EnquiryScreen(value: widget.aboutCompany),
            ),
          ),
        ),
        buildGridItem(
          ConstantStrings.customersOrders,
          'assets/images/png/customersorders.png',
              () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const CustomersOrderScreen(),
            ),
          ),
        ),
        buildGridItem(
          ConstantStrings.promotional,
          'assets/images/png/promotional_items.png',
              () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const PromotionalScreen(),
            ),
          ),
        ),
        buildGridItem(
          ConstantStrings.favouriteScreenHeading,
          'assets/images/png/favorite.png',
              () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  FavouriteScreen(token: widget.token),
            ),
          ),
        ),
        buildGridItem(
          'Offers',
          'assets/images/png/offers.png',
              () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const OfferScreen(),
            ),
          ),
        ),
        Builder(
          builder: (BuildContext context) {
            return InkWell(
              onTap: () {
                // Check if either link is available
                if (widget.aboutCompany[0].iosAppLiveLink != null || widget.aboutCompany[0].appLiveLink != null) {
                  // Construct the message based on available links
                  String message = '';
                  if (widget.aboutCompany[0].iosAppLiveLink != null) {
                    message += 'iOS App Link: ${widget.aboutCompany[0].iosAppLiveLink}\n';
                  }
                  if (widget.aboutCompany[0].appLiveLink != null) {
                    message += 'Android App Link: ${widget.aboutCompany[0].appLiveLink}';
                  }
                  // Call the share function
                  _onShare(context, message.trim(), ConstantStrings.appName);
                } else {
                  Utils.flushBarErrorMessage("Link not found!!", context);
                }
              },
              child:
              Container(
                margin: EdgeInsets.only(
                  left: 0, // Remove or adjust the margins to ensure full width
                  right: 0,
                ),
                width: MediaQuery.of(context).size.width, // Set full width of the screen
                child: AspectRatio(
                  aspectRatio: 16 / 9,  // Adjust to match your image's original aspect ratio
                  child: Image.asset(
                    "assets/images/png/share-image.png",
                    fit: BoxFit.cover, // Ensures the image covers the entire container width while maintaining the aspect ratio
                  ),
                ),
              ),


            );
          },
        ),

      ],
    );
  }

  Widget buildCategoryItem(String title, String count, VoidCallback onPress) {
    return Expanded(
      child: InkWell(
        onTap: onPress,
        child: Column(
          children: [
            MainIconsWithFun(
              title: title,
              image: 'assets/images/png/products.png',
              onPress: onPress,
            ),
            Text(
              count,
              style: TextStyle(fontSize: 13.5),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildGridItem(String title, String image, VoidCallback onPress) {
    return PngIconsWithFun(
      title: title,
      image: image,
      onPress: onPress,
    );
  }

  Widget buildLoadingScreen(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      color: AppColors.backgroundColor,
      child: Center(
        child: LoadingAnimationWidget.discreteCircle(
          color: AppColors.primaryColor,
          size: 40,
        ),
      ),
    );
  }

  Widget buildFloatingActionButton() {
    return Consumer<ScrollState>(
      builder: (context, scrollState, _) {
        return scrollState.isScrolling
            ? ClipRRect(
          borderRadius: BorderRadius.circular(30.0),
          child: FloatingActionButton.extended(
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => AddScreen(
                        isOwner: widget.isOwner,
                        token: widget.token,
                      )));
            },
            backgroundColor: AppColors.primaryColor,
            label:
            TextWithStyle.contactUsTitle(
                context, ConstantStrings.addScreen),
          ),
        )
            : ClipRRect(
          borderRadius: BorderRadius.circular(100.0),
          child: FloatingActionButton(
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => AddScreen(
                        isOwner: widget.isOwner,
                        token: widget.token,
                      )));
            },
            backgroundColor: AppColors.primaryColor,
            child: const Icon(
              Icons.add,
              color: Colors.white,
            ),
          ),
        );
      },
    );
  }
}



_onShare(BuildContext context,text,subject) {
  final box = context.findRenderObject() as RenderBox?;
  return Share.share(
    text,
    subject: subject,
    sharePositionOrigin: box!.localToGlobal(Offset.zero) & box.size,
  );
}






import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:pharma_clients_app/utils/utils.dart';
import 'package:pharma_clients_app/view_model/services/notification_services.dart';
import 'package:pharma_clients_app/views/homescreen/NotificationScreen.dart';
import 'package:pharma_clients_app/views/Screens/calculator.dart';
import 'package:pharma_clients_app/views/addScreen/AddScreen.dart';
import 'package:pharma_clients_app/views/customer/customers_screen.dart';
import 'package:pharma_clients_app/views/homescreen/selfAnalysisScreen.dart';
import 'package:pharma_clients_app/views/presentation/presentaionListScreen.dart';
import 'package:pharma_clients_app/views/products/favouriteScreen.dart';
import 'package:pharma_clients_app/views/visits/visits_screen.dart';
import 'package:provider/provider.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../data/model/response_model/about_company/about_company_response_model.dart';
import '../../data/response/status.dart';
import '../../resources/app_colors.dart';
import '../../resources/constant_strings.dart';
import '../../utils/IconWithFun/png_with_fun.dart';
import '../../utils/IconWithFun/mainIcons_with_fun.dart';
import '../../utils/Dialogue/error_dialogue.dart';
import '../../utils/scroll_state/scroll_state.dart';
import '../../utils/slider/Slider.dart';
import '../../utils/text_style.dart';
import '../../view_model/afterLogin_viewModel/afterLogin_viewModels.dart';
import '../../view_model/beforeLogin_viewModels/beforeLogin_viewModel.dart';
import '../../view_model/login_viewmodel.dart';
import '../Mr/MrsScreen.dart';
import 'cart_screen.dart';
import '../customer/customersOrderScreen.dart';
import 'myOrderScreen.dart';
import '../products/product_screen.dart';
import 'divisons_screen.dart';
import 'enquiry_screen.dart';
import '../products/new_launched.dart';
import 'offer_screen.dart';
import '../Screens/profile_screen.dart';
import 'promotional.dart';
import '../products/upcoming_products.dart';
import 'visual_aids_screen.dart';
import '../auth/login_screen.dart';
class HomeScreen extends StatefulWidget {
  final String? token;
  final bool? isOwner;
  final int? initialTabIndex;

  HomeScreen({required this.token, this.isOwner, Key? key, this.initialTabIndex}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  AboutCompanyViewModel model = AboutCompanyViewModel();
  LoginViewModel loginModel = LoginViewModel();
  GuestDbCountViewModel dbCount = GuestDbCountViewModel();
  NotificationServices notificationServices = NotificationServices();
  DbCountViewModel count = DbCountViewModel();
  List<AboutCompany> about = [];
  int _selectedIndex = 0;

  final List<String> _labels = [
    'Home',
    'Customers',
    'Cart',
    'Profile',
  ];

  @override
  void initState() {
    super.initState();
    _selectedIndex = widget.initialTabIndex ?? 0;
    notificationServices.requestNotificationPermission(widget.isOwner, widget.token);
    notificationServices.foregroundMessage();
    notificationServices.firebaseInit(context, widget.isOwner, widget.token);
    notificationServices.setupInteractMessage(context, widget.isOwner, widget.token);
    notificationServices.isTokenRefresh();
    getCount();
    getData();
  }

  Future<void> getCount() async {
    if (widget.token != null && widget.token!.isNotEmpty) {
      await count.fetchCountApi(context);
      getData();
    } else {
      await dbCount.fetchDbCountApi();
    }
  }

  Future<void> getData() async {
    await model.fetchAboutCompany();
  }

  Future<bool?> _onWillPop() async {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Are you sure?'),
        content: const Text('Do you want to exit an App?'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('No'),
          ),
          TextButton(
            onPressed: () => exit(0),
            child: const Text('Yes'),
          ),
        ],
      ),
    );
  }

  Widget _buildIcon(int index) {
    final cart = Provider.of<Cart>(context, listen: false);
    switch (index) {
      case 0:
        return Image.asset(
          _selectedIndex == index ? 'assets/images/png/home.png' : 'assets/images/png/home_outlined.png',
          width: 5.w,
        );
      case 1:
        return Image.asset(
          _selectedIndex == index ? 'assets/images/png/customers.png' : 'assets/images/png/customers_outlined.png',
          width: 6.w,
        );
      case 2:
        return FutureBuilder(
          future: cart.loadCart(),
          builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
            return Consumer<Cart>(builder: (BuildContext context, value, Widget? child) {
              return Badge(
                label: Text(
                  value.items.length.toString(),
                  style: TextStyle(fontSize: 12.sp),
                ),
                isLabelVisible: true,
                backgroundColor: AppColors.badgeColor,
                alignment: Alignment.topRight,
                child: Image.asset(
                  _selectedIndex == index ? 'assets/images/png/cart_filled.png' : 'assets/images/png/cart_outlined.png',
                  width: 6.w,
                ),
              );
            });
          },
        );
      case 3:
        return Image.asset(
          _selectedIndex == index ? 'assets/images/png/profile.png' : 'assets/images/png/profile_outlined.png',
          width: 6.w,
        );
      default:
        return const SizedBox();
    }
  }

  Widget _buildScreen(int index) {
    switch (index) {
      case 0:
        return DashboardScreen(isOwner: widget.isOwner, token: widget.token, aboutCompany: about);
      case 1:
        return widget.token != null && widget.token!.isNotEmpty ? const CustomersScreen() : LoginScreen();
      case 2:
        return widget.token != null && widget.token!.isNotEmpty ? CartScreen(owner: widget.token, isOwner: widget.isOwner) : LoginScreen();
      case 3:
        return widget.token != null && widget.token!.isNotEmpty ? ProfileScreen(value: about, isOwner: widget.isOwner) : LoginScreen();
      default:
        return Container();
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        bool? result = await _onWillPop();
        result ??= false;
        return result;
      },
      child: ChangeNotifierProvider<AboutCompanyViewModel>(
        create: (BuildContext context) => model,
        child: Consumer<AboutCompanyViewModel>(builder: (context, value, _) {
          switch (value.aboutCompany.status!) {
            case Status.loading:
              return Container(
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                color: AppColors.backgroundColor,
                child: Center(
                  child: LoadingAnimationWidget.discreteCircle(
                    color: AppColors.primaryColor,
                    size: 40,
                  ),
                ),
              );
            case Status.error:
              return ErrorDialogue(
                message: value.aboutCompany.message,
              );
            case Status.completed:
              about.add(value.aboutCompany.data!.data!);

              return Scaffold(
                body: Row(
                  children: [
                    if (isTablet(context))
                      NavigationRail(
                        backgroundColor: AppColors.backgroundColor,
                        selectedIndex: _selectedIndex.clamp(0, _labels.length - 1), // Ensure index is within bounds
                        onDestinationSelected: (int index) {
                          setState(() {
                            _selectedIndex = index;
                          });
                        },
                        labelType: NavigationRailLabelType.all,
                        selectedLabelTextStyle: TextStyle(
                          color: AppColors.primaryColor,
                          fontSize: 14.5.sp,
                          fontWeight: FontWeight.w700,
                        ),
                        unselectedLabelTextStyle: TextStyle(
                          color: Colors.black.withOpacity(0.6),
                          fontSize: 14.5.sp,
                          fontWeight: FontWeight.w500,
                        ),
                        destinations: [
                          for (int index = 0; index < _labels.length; index++)
                            NavigationRailDestination(
                              icon: _buildIcon(index),
                              label: Text(_labels[index]),
                            ),
                        ],
                        trailing: Expanded(
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: Padding(
                              padding: EdgeInsets.only(bottom: 20),
                              child: InkWell(
                                onTap: () {
                                  setState(() {
                                    _selectedIndex = 3;
                                  });
                                },
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    _buildIcon(3),
                                    SizedBox(height: 4),
                                    Text(
                                      _labels[3],
                                      style: TextStyle(
                                        color: _selectedIndex == 3 ? AppColors.primaryColor : Colors.black.withOpacity(0.6),
                                        fontSize: 14.5.sp,
                                        fontWeight: _selectedIndex == 3 ? FontWeight.w700 : FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    if (isTablet(context))
                      const VerticalDivider(thickness: 1, width: 1),
                    Expanded(
                      child: Column(
                        children: [
                          const SizedBox(height: 20),
                          Expanded(
                            child: Center(child: _buildScreen(_selectedIndex)),
                          ),
                          const SizedBox(height: 20),
                        ],
                      ),
                    ),
                  ],
                ),
                bottomNavigationBar: !isTablet(context) && widget.token != null && widget.token!.isNotEmpty
                    ? BottomNavigationBar(
                  backgroundColor: Colors.white,
                  type: BottomNavigationBarType.fixed,
                  selectedLabelStyle: TextStyle(fontSize: 14.sp),
                  selectedItemColor: AppColors.primaryColor,
                  unselectedItemColor: Colors.grey,
                  currentIndex: _selectedIndex,
                  onTap: (index) {
                    setState(() {
                      _selectedIndex = index;
                    });
                  },
                  items: [
                    for (int index = 0; index < 4; index++)
                      BottomNavigationBarItem(
                        icon: _buildIcon(index),
                        label: _labels[index],
                      ),
                  ],
                )
                    : null,
              );
          }
        }),
      ),
    );
  }

  bool isTablet(BuildContext context) {
    final data = MediaQuery.of(context);
    return data.size.shortestSide >= 600;
  }
}




class DashboardScreen extends StatefulWidget {
  String? token;
  bool? isOwner;
  List<AboutCompany> aboutCompany;

  DashboardScreen({required this.token, this.isOwner, required this.aboutCompany, super.key,});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {

  AboutCompanyViewModel model = AboutCompanyViewModel();
  GuestDbCountViewModel dbcount = GuestDbCountViewModel();
  DbCountViewModel count = DbCountViewModel();
  List<AboutCompany> about = [];
  List img = [];
  String? token;
  String? userName;

  @override
  void initState() {
    getCount();
    getUserInfo();
    // TODO: implement initState
    super.initState();
  }

  Future<void> getCount() async {
    if (widget.token != null && widget.token.toString().isNotEmpty) {
      await count.fetchCountApi(context);
      getData();
    } else {
      await dbcount.fetchDbCountApi();
    }
  }

  getData() async {
    await model.fetchAboutCompany();
    //getCount();
  }

  Future<void> getUserInfo() async {
    final SharedPreferences sp = await SharedPreferences.getInstance();
    userName = sp.getString('name');
    return;
  }

  @override
  Widget build(BuildContext context) {

    final scroll = Provider.of<ScrollState>(context, listen: false);

    Widget itemWidget(value, val) {
      return Scaffold(
        appBar: AppBar(
          toolbarHeight: 5.h,
          centerTitle: false,
          automaticallyImplyLeading: false,
          elevation: 0,
          title: Column(
            children: [
              widget.token == null
                  ? TextWithStyle.appBarTitle(
                  context, ConstantStrings.dashboardScreen)
                  : Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    'Hi,',
                    style: TextStyle(
                      color: Colors.black54,
                      fontSize: 18.sp,
                    ),
                  ),
                  const SizedBox(width: 3,),
                  Text(
                    "${userName}",
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w600
                    ),
                  ),
                  //TextWithStyle.appBarTitle(context, widget.token!),
                ],
              )
            ],
          ),
          actions: [
            IconButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => const NotificationScreen()));
                },
                icon: Image.asset('assets/images/png/notification.png',width: 3.5.h,)
            ),
            widget.token == null
                ? IconButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => LoginScreen()));
                },
                icon: Image.asset('assets/images/png/profile.png',width: 3.5.h,)
            )
                : Container(),
            SizedBox(
              width: 2.w,
            ),
          ],
        ),
        body: NotificationListener<ScrollNotification>(
            onNotification: (scrollInfo) {
              if (scrollInfo is ScrollStartNotification) {
                scroll.updateScrolling(true);
              } else if (scrollInfo is ScrollEndNotification) {
                scroll.updateScrolling(false);
              }
              return true;
            },
            child: RefreshIndicator(
              onRefresh: () {
                return getCount();
              },
              child: SingleChildScrollView(
                  child: Column(
                    children: [
                      NotificationListener<ScrollNotification>(
                        onNotification: (scrollInfo) {
                          if (scrollInfo is ScrollStartNotification) {
                            scroll.updateScrolling(false);
                          } else if (scrollInfo is ScrollEndNotification) {
                            scroll.updateScrolling(false);
                          }
                          return true;
                        },
                        child: Container(
                          margin: EdgeInsets.only(top: 3.w),
                          child: slider(
                            images: widget.aboutCompany[0].aboutImgs!,
                            aspectRatio: 2/1,
                            viewPortFraction: 0.95,
                          ),
                        ),
                      ),
                      Container(
                          margin: EdgeInsets.only(left: 3.w, right: 3.w, bottom: 0.w, top: 2.w),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              TextWithStyle.containerTitle(context, 'Categories'),
                              SizedBox(height: 1.h),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Container(
                                      padding: EdgeInsets.only(
                                          top: MediaQuery.of(context).size.height / 60,
                                          bottom: MediaQuery.of(context).size.height / 140
                                      ),
                                      child: Column(
                                        children: [
                                          MainIconsWithFun(
                                            title: ConstantStrings.productScreen,
                                            image: 'assets/images/png/products.png',
                                            onPress: () =>
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) => ProductScreen(
                                                      token: widget.token,
                                                      isOwner: widget.isOwner,

                                                    ),
                                                  ),
                                                ),
                                          ),
                                          Text(
                                            val.data?.productCount.toString() ?? '0',
                                            style: TextStyle(
                                              fontSize: 13.5.sp,
                                              color: Colors.black54,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Container(
                                      padding: EdgeInsets.only(
                                          top: MediaQuery.of(context).size.height / 60,
                                          bottom: MediaQuery.of(context).size.height / 140),
                                      child: Column(
                                        children: [
                                          MainIconsWithFun(
                                            title: ConstantStrings.visualAidsScreen,
                                            image: 'assets/images/png/visualaids.png',
                                            onPress: () => Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) => VisualAidsScreen(
                                                  token: widget.token,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Text(
                                            "",
                                            style: TextStyle(
                                              fontSize: 13.sp,
                                              fontWeight: FontWeight.w300,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  widget.isOwner == true || widget.isOwner == null?
                                  Expanded(
                                    child: Container(
                                      padding: EdgeInsets.only(
                                          top: MediaQuery.of(context).size.height / 60,
                                          bottom: MediaQuery.of(context).size.height / 140),
                                      child: Column(
                                        children: [
                                          MainIconsWithFun(
                                            title: ConstantStrings.mrs,
                                            image: 'assets/images/png/mrs.png',
                                            onPress: () async {
                                              if (widget.token != null) {
                                                await Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                        builder: (context) => const MrsScreen()));
                                              } else {
                                                await Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                        builder: (context) => LoginScreen()));
                                              }
                                            },
                                          ),
                                          Text(
                                            '',
                                            style: TextStyle(
                                              fontSize: 13.5.sp,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ): Container(),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Container(
                                      padding: EdgeInsets.only(
                                          top: MediaQuery.of(context).size.height / 60,
                                          bottom: MediaQuery.of(context).size.height / 140),
                                      child: Column(
                                        children: [
                                          MainIconsWithFun(
                                              title: ConstantStrings.myOrders,
                                              image: 'assets/images/png/orders.png',
                                              onPress: (){
                                                widget.token != null && widget.token!.isNotEmpty
                                                    ? widget.isOwner == true
                                                    ? Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                      builder: (context) =>
                                                      const MyOrderScreen()),
                                                )
                                                    : Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                      builder: (context) =>
                                                      const CustomersOrderScreen()),)
                                                    : Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                      builder: (context) => LoginScreen()),
                                                );
                                              }
                                          ),
                                          Text(
                                            widget.token != null && widget.token!.isNotEmpty
                                                ? widget.isOwner == true
                                                ? val.dataa?.companyOrderCount.count.toString().length == 1
                                                ? '0${val.dataa?.companyOrderCount.count.toString()}'
                                                : val.dataa?.companyOrderCount.count.toString() ?? '0'
                                                : val.data?.orderCount.toString() ?? '0'
                                                : '0',
                                            style: TextStyle(
                                              fontSize: 13.5.sp,
                                              color: Colors.black54,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const Divider(
                                color: Colors.black12,
                                height: 10,
                              ),
                            ],
                          )
                      ),
                      GridView.count(
                        physics: const NeverScrollableScrollPhysics(),
                        primary: false,
                        shrinkWrap: true,
                        padding: EdgeInsets.all(MediaQuery.of(context).size.height/100),
                        crossAxisCount: 4,
                        children: [
                          Container(
                            margin: val.data?.upcommingCount.toString() != '0' ? EdgeInsets.only(left: 2.h) : EdgeInsets.only(),
                            child: Badge(
                              label: Text(val.data?.upcommingCount.toString() ?? '0'),
                              backgroundColor: AppColors.badgeColor,
                              offset: const Offset(11, -3),
                              isLabelVisible: val.data?.upcommingCount.toString() == '0' ? false : true,
                              alignment: Alignment.topCenter,
                              child: PngIconsWithFun(
                                title: ConstantStrings.upcomingScreen,
                                image: 'assets/images/png/upcoming_products.png',
                                onPress: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => UpcomingProductScreen(
                                        token: widget.token,
                                      )),
                                ),
                              ),
                            ),
                          ),
                          PngIconsWithFun(
                            title: ConstantStrings.divisions,
                            image: 'assets/images/png/divisons.png',
                            onPress: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => DivisionScreen(
                                      token: widget.token, value: widget.aboutCompany)),
                            ),
                          ),
                          PngIconsWithFun(
                            title: ConstantStrings.presentation,
                            image: 'assets/images/png/slides.png',
                            onPress: () async {
                              if (widget.token != null) {
                                Navigator.push(context,
                                    MaterialPageRoute(builder: (context) => PresentationListScreen()));
                              } else {
                                await Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => LoginScreen()));
                              }
                            },
                          ),
                          PngIconsWithFun(
                            title: ConstantStrings.visits,
                            image: 'assets/images/png/visits.png',
                            onPress: () async {
                              if (widget.token != null) {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                        const VisitsScreen()));
                              } else {
                                await Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => LoginScreen()));
                              }
                            },
                          ),
                          PngIconsWithFun(
                            title: ConstantStrings.selfAnalysis,
                            image: 'assets/images/png/self_analysis.png',
                            onPress: () async {
                              if (widget.token != null) {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                        const SelfAnalysisScreen()));
                              } else {
                                await Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => LoginScreen()));
                              }
                            },
                          ),
                          Container(
                              margin: val.data?.launchesCount.toString() != '0' ? EdgeInsets.only(left: 2.h) : EdgeInsets.only(),
                              child: Badge(
                                label: Text(val.data?.launchesCount.toString()??'0'),
                                alignment: Alignment.topCenter,
                                offset: const Offset(10, -3),
                                backgroundColor: AppColors.badgeColor,
                                isLabelVisible: val.data?.launchesCount.toString() == '0' ? false : true,
                                child: PngIconsWithFun(
                                  title: ConstantStrings.newLaunches,
                                  image: 'assets/images/png/new_launches.png',
                                  onPress: () => Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => NewLaunchedProductScreen(
                                          token: widget.token,
                                        )),
                                  ),
                                ),)),
                          PngIconsWithFun(
                            title: ConstantStrings.ptrpts,
                            image: 'assets/images/png/ptrpts.png',
                            onPress: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => const Calculator())
                            ),
                          ),
                          PngIconsWithFun(
                            title: ConstantStrings.enquiry,
                            image: 'assets/images/png/connectwithus.png',
                            onPress: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => EnquiryScreen(value: widget.aboutCompany))
                            ),
                          ),
                          if (widget.isOwner == true || widget.isOwner == null) ...[
                            PngIconsWithFun(
                              title: ConstantStrings.customersOrders,
                              image: 'assets/images/png/customersorders.png',
                              onPress: () async {
                                if (widget.token != null) {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                          const CustomersOrderScreen()));
                                } else {
                                  await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => LoginScreen()));
                                }
                              },
                            ),
                            PngIconsWithFun(
                              title: ConstantStrings.promotional,
                              image: 'assets/images/png/promotional_items.png',
                              onPress: () async {
                                if (widget.token != null) {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                          const PromotionalScreen()));
                                } else {
                                  await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => LoginScreen()));
                                }
                              },
                            ),
                            PngIconsWithFun(
                              title: 'Offers',
                              image: 'assets/images/png/offers.png',
                              onPress: () async {
                                if (widget.token != null) {
                                  await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                          const OfferScreen()));
                                } else {
                                  await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => LoginScreen()));
                                }
                              },
                            ),
                            PngIconsWithFun(
                              title: ConstantStrings.favouriteScreenHeading,
                              image: 'assets/images/png/favorite.png',
                              onPress: () async {
                                if (widget.token != null) {
                                  await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => FavouriteScreen(token: widget.token)));
                                } else {
                                  await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => LoginScreen()));
                                }
                              },
                            ),
                          ]
                        ],
                      ),
                      Builder(
                        builder: (BuildContext context) {
                          return InkWell(
                            onTap: () {
                              // Check if either link is available
                              if (widget.aboutCompany[0].iosAppLiveLink != null || widget.aboutCompany[0].appLiveLink != null) {
                                // Construct the message based on available links
                                String message = '';
                                if (widget.aboutCompany[0].iosAppLiveLink != null) {
                                  message += 'iOS App Link: ${widget.aboutCompany[0].iosAppLiveLink}\n';
                                }
                                if (widget.aboutCompany[0].appLiveLink != null) {
                                  message += 'Android App Link: ${widget.aboutCompany[0].appLiveLink}';
                                }
                                // Call the share function
                                _onShare(context, message.trim(), ConstantStrings.appName);
                              } else {
                                Utils.flushBarErrorMessage("Link not found!!", context);
                              }
                            },
                            child: Container(
                                margin: EdgeInsets.only(left: 3.w, right: 3.w),
                                child: Image.asset("assets/images/png/share-image.png")),
                          );
                        },
                      ),
                    ],
                  )),
            )),
        floatingActionButton: Consumer<ScrollState>(
          builder: (context, scrollState, _) {
            return scrollState.isScrolling
                ? ClipRRect(
              borderRadius: BorderRadius.circular(30.0), // Adjust the border radius as needed
              child: FloatingActionButton.extended(
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              AddScreen( isOwner: widget.isOwner,token: widget.token,)));
                },
                backgroundColor: AppColors.primaryColor, // Adjust the background color as needed
                label: TextWithStyle.contactUsTitle(
                    context, ConstantStrings.addScreen),
              ),
            )
                : ClipRRect(
              borderRadius: BorderRadius.circular(100.0),
              child: FloatingActionButton(
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              AddScreen( isOwner: widget.isOwner,token: widget.token,)));
                },
                backgroundColor: AppColors.primaryColor,
                child: Icon(
                  CupertinoIcons.add,
                  color: Colors.white,
                ),
              ),
            );
          },
        ),
      );
    }

    return widget.token != null && widget.token.toString().isNotEmpty
        ? ChangeNotifierProvider<DbCountViewModel>(
        create: (BuildContext context) => count,
        child: Consumer<DbCountViewModel>(
            builder: (context, val, _) {
              return val.loading == false
                  ? RefreshIndicator(onRefresh: () {
                return getCount();
              },
                  child: itemWidget(widget.aboutCompany, val))
                  : Container(
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                color: AppColors.backgroundColor,
                child: Center(
                    child: LoadingAnimationWidget.discreteCircle(
                        color: AppColors.primaryColor,
                        size: 40)
                ),
              );
            }))
        : ChangeNotifierProvider<GuestDbCountViewModel>(
        create: (BuildContext context) => dbcount,
        child: Consumer<GuestDbCountViewModel>(
            builder: (context, val, _) {
              return val.loading == false
                  ? itemWidget(widget.aboutCompany, val)
                  : Container(
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                color: AppColors.backgroundColor,
                child: Center(
                    child: LoadingAnimationWidget.discreteCircle(
                        color: AppColors.primaryColor,
                        size: 40)
                ),
              );
            }));
  }
}

_onShare(BuildContext context,text,subject) {
  final box = context.findRenderObject() as RenderBox?;
  return Share.share(
    text,
    subject: subject,
    sharePositionOrigin: box!.localToGlobal(Offset.zero) & box.size,
  );
}


class ConstantImage{

  static const String empty = 'assets/images/png/data-not-found.png';
  static const String packingVarient = 'assets/images/png/packingVarient.png';
  static const String search = 'assets/images/png/search.png';

}
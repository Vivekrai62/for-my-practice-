import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:pharma_clients_app/data/model/response_model/faqsResponseModel.dart';
import 'package:pharma_clients_app/data/model/response_model/products/product_reponse_model.dart';
import 'package:pharma_clients_app/data/model/response_model/registraion/registrationfields_response_model.dart';
import 'package:pharma_clients_app/resources/constant_strings.dart';
import 'package:pharma_clients_app/utils/utils.dart';
import 'package:pharma_clients_app/views/forgotPassword/ResetPasswordScreen.dart';
import 'package:pharma_clients_app/views/forgotPassword/verifyOtpScreen.dart';
import 'package:pharma_clients_app/views/auth/login_screen.dart';
import '../../data/model/response_model/about_company/about_company_response_model.dart';
import '../../data/model/response_model/about_company/about_promotional_screen.dart';
import '../../data/model/response_model/count/guestDbcount_responseModel.dart';
import '../../data/model/response_model/products/packing_type_response_model.dart';
import '../../data/model/response_model/visual_aids_response_model.dart';
import '../../data/repository/Beforelogin/beforeLogin_repository.dart';
import '../../data/response/api_response.dart';

class GuestProductViewModel with ChangeNotifier{

  List<Products> product = [];
  List<Products> _selectedProducts = [];
  List<Products> _filteredProducts = [];
  List<Products> _favProducts = [];
  List<Products> _newLaunched = [];
  List<Products> _upcoming = [];

  List<Products> get selectedProducts => _selectedProducts;
  List<Products> get products => _filteredProducts;
  List<Products> get favProducts => _favProducts;
  List<Products> get newLaunched => _newLaunched;
  List<Products> get upcoming => _upcoming;
  String get selectedCategory => _selectedCategory;

  bool get isSelectionMode => _selectedProducts.isNotEmpty;

  final _myRepo = BeforeLoginRepository();

  Map<String, List<String>> selectedFilters = {
    'Category': [],
    'Division': [],
    'Form': [],
    'Speciality':[],
    'Concern':[]
  };

  Map<String, List<String>> filterOptions = {
    'Category': [],
    'Division': [],
    'Form': [],
    'Speciality':[],
    'Concern':[]
  };

  String _selectedCategory = 'Category';
  String _searchText = '';


  void selectCategory(String category) {
    _selectedCategory = category;
    notifyListeners();
  }

  ApiResponse<ProductResponseModel> productlist = ApiResponse.loading();

  setProductList(ApiResponse<ProductResponseModel> response){
    productlist = response;
    notifyListeners();
  }

  Future<void> fetchProducts() async {
    setProductList(ApiResponse.loading());

    _myRepo.fetchProductList().then((value) {
      for (var element in value.data!) {
        if (element.active == true) {
          product.add(element);
          if (element.favourite == true) {
            _favProducts.add(element);
          }
          if (element.newLaunched == true) {
            _newLaunched.add(element);
          }
          if (element.upcoming == true) {
            _upcoming.add(element);
          }
        }
      }
      _filteredProducts = product;

      // Extract unique filter options from products
      filterOptions['Category'] = _capitalizeFirstLetter(
          product.map((p) => p.categoryName ?? 'NA').toSet().toList());
      filterOptions['Division'] = _capitalizeFirstLetter(
          product.map((p) => p.description ?? 'NA').toSet().toList());
      filterOptions['Form'] = _capitalizeFirstLetter(
          product.map((p) => p.typeName ?? 'NA').toSet().toList());

      // Extract speciality names from the specialityId list
      filterOptions['Speciality'] = _capitalizeFirstLetter(
          product
              .where((p) => p.specialityId != null)          // Filter out products where specialityId is null
              .expand((p) => p.specialityId!)                // Flatten the list of specialityId for all products
              .where((s) => s.name != null)                  // Filter out speciality items where the name is null
              .map((s) => s.name!)                           // Extract the name of each speciality, which is now non-null
              .toSet()                                       // Remove duplicates by converting to a Set
              .toList()                                      // Convert back to a List
      );



      filterOptions['Concern'] = _capitalizeFirstLetter(
          product.map((p) => p.concernName ?? 'NA').toSet().toList());

      notifyListeners();
      setProductList(ApiResponse.completed(value));
    }).onError((error, stackTrace) {
      setProductList(ApiResponse.error(error.toString()));

      if (kDebugMode) {
        print(error.toString());
      }
    });
  }

  void updateSearchText(String text) {
    _searchText = text;
    applyFilters();
  }

  int getSelectedCount(String category) {
    return selectedFilters[category]?.length ?? 0;
  }

  void toggleFilterOption(String category, String option) {
    if (selectedFilters[category]?.contains(option) == true) {
      selectedFilters[category]?.remove(option);
    } else {
      selectedFilters[category]?.add(option);
    }
    applyFilters();
  }

  void applyFilters() {
    _filteredProducts = product.where((element) {
      final matchesName = element.name?.toLowerCase().contains(_searchText.toLowerCase()) ?? false;
      final matchesDes = element.description?.toLowerCase().contains(_searchText.toLowerCase()) ?? false;
      final matchesCategory = selectedFilters['Category']!.isEmpty || selectedFilters['Category']!.contains(element.categoryName ?? 'NA');
      final matchesDivision = selectedFilters['Division']!.isEmpty || selectedFilters['Division']!.contains(element.divisionId?.first.name ?? 'NA');
      final matchesProductType = selectedFilters['Form']!.isEmpty || selectedFilters['Form']!.contains(element.typeName ?? 'NA');

      // Handle filtering by speciality names
      final matchesSpeciality = selectedFilters['Speciality']!.isEmpty ||
          element.specialityId!.any((s) => selectedFilters['Speciality']!.contains(s.name ?? 'NA'));

      final matchesConcern = selectedFilters['Concern']!.isEmpty || selectedFilters['Concern']!.contains(element.concernName ?? 'NA');

      return (matchesName || matchesDes)
          && matchesCategory
          && matchesDivision
          && matchesProductType
          && matchesSpeciality
          && matchesConcern;
    }).toList();
    notifyListeners();
  }

  void clearFilters() {
    selectedFilters.forEach((key, value) => value.clear());
    applyFilters();
  }

  void toggleSelection(Products product) {
    if (_selectedProducts.contains(product)) {
      _selectedProducts.remove(product);
    } else {
      _selectedProducts.add(product);
    }
    notifyListeners();
  }

  List<String> getFilteredOptions() {
    List<String> options = filterOptions[selectedCategory] ?? [];
    if (_searchText.isNotEmpty) {
      options = options.where((option) => option.toLowerCase().contains(_searchText.toLowerCase())).toList();
    }
    return options;
  }

  bool isSelected(Products product) {
    return _selectedProducts.contains(product);
  }

  void clearSelection() {
    _selectedProducts.clear();
    notifyListeners();
  }

  List<String> _capitalizeFirstLetter(List<String> items) {
    return items.map((item) {
      if (item.isEmpty) return item;
      return item[0].toUpperCase() + item.substring(1).toLowerCase();
    }).toList();
  }
}


class GuestVisualAidsViewModel with ChangeNotifier {
  List<VisualAids> visualAid = [];
  List<VisualAids> _filteredVisualAids = [];
  List<VisualAids> _selectedVisualAids = [];

  List<VisualAids> get visualAids => _filteredVisualAids;
  List<VisualAids> get selectedVisualAids => _selectedVisualAids;
  bool get isSelectionMode => _selectedVisualAids.isNotEmpty;
  String get selectedCategory => _selectedCategory;

  final _myRepo = BeforeLoginRepository();

  ApiResponse<VisualAidsResponseModel> visualaidsList = ApiResponse.loading();

  // Dynamic filter options
  Map<String, List<String>> filterOptions = {
    'Category': [],
    'Division': [],
    'Form': [],
    'Speciality':[],
    'Concern':[]
  };


  String _selectedCategory = 'Category';
  String _searchText = '';

  Map<String, List<String>> selectedFilters = {
    'Category': [],
    'Division': [],
    'Form': [],
    'Speciality':[],
    'Concern':[]
  };

  setAboutCompanyList(ApiResponse<VisualAidsResponseModel> response) {
    visualaidsList = response;
    notifyListeners();
  }

  Future<void> fetchVisualAids() async {
    setAboutCompanyList(ApiResponse.loading());

    _myRepo.fetchVisualAids().then((value) {
      visualAid = value.data!.where((element) => element.url != null).toList();
      _filteredVisualAids = visualAid;

      // Extract unique filter options from products
      filterOptions['Category'] = _capitalizeFirstLetter(
          visualAid.map((p) => p.category ?? 'NA').toSet().toList());

      filterOptions['Division'] = _capitalizeFirstLetter(
          visualAid.expand((p) => p.division ?? []).toSet().map((e) => e.toString()).toList()
      );

      filterOptions['Form'] = _capitalizeFirstLetter(
          visualAid.map((p) => p.productType ?? 'NA').toSet().map((e) => e.toString()).toList()
      );

      filterOptions['Speciality'] = _capitalizeFirstLetter(
          visualAid.expand((p) => p.speciallity ?? []).toSet().map((e) => e.toString()).toList()
      );


      filterOptions['Concern'] = _capitalizeFirstLetter(
          visualAid.map((p) => p.concern ?? 'NA').toSet().toList());

      notifyListeners();
      setAboutCompanyList(ApiResponse.completed(value));

    }).onError((error, stackTrace) {
      setAboutCompanyList(ApiResponse.error(error.toString()));
      if (kDebugMode) {
        print(error.toString());
      }
    });
  }
  List<String> _capitalizeFirstLetter(List<String> items) {
    return items.map((item) {
      if (item.isEmpty) return item;
      return item[0].toUpperCase() + item.substring(1).toLowerCase();
    }).toList();
  }




  void selectCategory(String category) {
    _selectedCategory = category;
    notifyListeners();
  }

  int getSelectedCount(String category) {
    return selectedFilters[category]?.length ?? 0;
  }

  void updateSearchText(String text) {
    _searchText = text;
    applyFilters();
  }

  void toggleFilterOption(String category, String option) {
    if (selectedFilters[category]?.contains(option) == true) {
      selectedFilters[category]?.remove(option);
    } else {
      selectedFilters[category]?.add(option);
    }
    applyFilters();
  }

  void applyFilters() {
    filteredVisuals(_searchText,
      selectedFilters['Category'] ?? [],
      selectedFilters['Division'] ?? [],
      selectedFilters['Form'] ?? [],
      selectedFilters['Speciality'] ?? [],
      selectedFilters['Concern'] ?? [],
    );
  }

  void clearFilters() {
    selectedFilters.forEach((key, value) => value.clear());
    applyFilters();
  }

  void toggleSelection(VisualAids product) {
    if (_selectedVisualAids.contains(product)) {
      _selectedVisualAids.remove(product);
    } else {
      _selectedVisualAids.add(product);
    }
    notifyListeners();
  }

  bool isSelected(VisualAids product) {
    return _selectedVisualAids.contains(product);
  }

  void clearSelection() {
    _selectedVisualAids.clear();
    notifyListeners();
  }

  List<String> getFilteredOptions() {
    List<String> options = filterOptions[selectedCategory] ?? [];
    if (_searchText.isNotEmpty) {
      options = options.where((option) => option.toLowerCase().contains(_searchText.toLowerCase())).toList();
    }
    return options;
  }

  Future<void> filteredVisuals(
      String searchQuery,
      List<String> categories,
      List<String> divisions,
      List<String> productTypes,
      List<String> Speciality,
      List<String> Concern,
      ) async {
    _filteredVisualAids = visualAid.where((element) {
      final matchesQuery = element.name?.toLowerCase().contains(searchQuery.toLowerCase()) ?? false;
      final matchesCategory = categories.isEmpty || categories.contains(element.category ?? 'NA');
      final matchesDivision = divisions.isEmpty || divisions.contains(element.division ?? 'NA');
      final matchesProductType = productTypes.isEmpty || productTypes.contains(element.productType ?? 'NA');
      final matchesSpeciality = Speciality.isEmpty || Speciality.contains(element.speciallity ?? 'NA');
      final matchesConcern = Concern.isEmpty || Concern.contains(element.concern ?? 'NA');

      return matchesQuery && matchesCategory && matchesDivision && matchesProductType && matchesSpeciality && matchesConcern;
    }).toList();
    notifyListeners();
  }
}

class RegisterViewModel with ChangeNotifier{

  final _myRepo = BeforeLoginRepository();

  bool _loading = false ;
  bool get loading => _loading ;

  setLoading(bool value){
    _loading = value;
    notifyListeners();
  }

  Future<void> register(
      dynamic data,
      BuildContext context,
      TextEditingController name,
      TextEditingController email,
      TextEditingController phone,
      TextEditingController address,
      TextEditingController dob,
      TextEditingController operationArea,
      TextEditingController password,
      TextEditingController confirmPassword,
      TextEditingController firmName,
      TextEditingController gstNumber,
      TextEditingController drugLicense,
      TextEditingController aadharNumber,
      TextEditingController firmPhone,
      TextEditingController firmEmail,
      TextEditingController firmAddress,
      TextEditingController bankName,
      TextEditingController ifscCode,
      TextEditingController accountNumber,
      TextEditingController payeeName,

      ) async {

    setLoading(true);

    _myRepo.register(data).then((value){

      setLoading(false);

      if(value.success == true){

        name.clear();
        email.clear();
        phone.clear();
        address.clear();
        dob.clear();
        operationArea.clear();
        password.clear();
        confirmPassword.clear();
        firmName.clear();
        gstNumber.clear();
        drugLicense.clear();
        aadharNumber.clear();
        firmPhone.clear();
        firmAddress.clear();
        firmEmail.clear();
        bankName.clear();
        ifscCode.clear();
        accountNumber.clear();
        payeeName.clear();

        Utils.successAlertDialogue("Contact tour administrator to activate", (){
          Navigator.push(context,
              MaterialPageRoute(builder: (context)=> LoginScreen()));
          },context);

      }else{
        Utils.errorAlertDialogue(value.message.toString(), context);
      }

    }).onError((error, stackTrace){

      setLoading(false);
      if (kDebugMode) {
        print(error.toString());
      }
    });
  }
}

class RegistrationFieldsViewModel with ChangeNotifier{

  final _myRepo = BeforeLoginRepository();

  ApiResponse<RegistrationFieldResponseModel> registerFields = ApiResponse.loading();

  setList(ApiResponse<RegistrationFieldResponseModel> response){
    registerFields = response;
    notifyListeners();
  }

  Future<void> registerField() async {
    setList(ApiResponse.loading());
    _myRepo.registerFields().then((value){

      setList(ApiResponse.completed(value));

    }).onError((error, stackTrace){
      setList(ApiResponse.error(error.toString()));

    });
  }

}

class GuestDbCountViewModel with ChangeNotifier{

  final _myRepo = BeforeLoginRepository();

  DbCount? data;
  DbCount? get dataa => data;

  bool _loading = false ;
  bool get loading => _loading ;

  setLoading(bool value){
    _loading = value;
    notifyListeners();
  }

  Future<void>fetchDbCountApi() async {
    setLoading(true);
    _myRepo.fetchDbCount().then((value){
      data = value.data;
      notifyListeners();
      setLoading(false);
    }).onError((error, stackTrace){
      setLoading(false);
      if (kDebugMode) {
        print(error.toString());
      }
    });
  }
}

class PackingViewModel with ChangeNotifier{

  final _myRepo = BeforeLoginRepository();

  ApiResponse<PackingTypeResponseModel> packingtypelist = ApiResponse.loading();

  setPackingList(ApiResponse<PackingTypeResponseModel> response){
    packingtypelist = response;
    notifyListeners();
  }

  Future<void> fetchPackingTypeApi() async {

    setPackingList(ApiResponse.loading());

    _myRepo.fetchPackingType().then((value){

      setPackingList(ApiResponse.completed(value));

    }).onError((error, stackTrace){

      setPackingList(ApiResponse.error(error.toString()));
      if (kDebugMode) {
        print(error.toString());
      }

    });
  }
}

class AboutCompanyViewModel with ChangeNotifier{

  final _myRepo = BeforeLoginRepository();

  ApiResponse<AboutCompanyResponseModel> aboutCompany = ApiResponse.loading();

  setAboutCompanyList(ApiResponse<AboutCompanyResponseModel> response){
    aboutCompany = response;
    notifyListeners();
  }

  Future<void> fetchAboutCompany() async {
    setAboutCompanyList(ApiResponse.loading());
    _myRepo.fetchAboutCompany().then((value){

        setAboutCompanyList(ApiResponse.completed(value));

    }).onError((error, stackTrace){
      setAboutCompanyList(ApiResponse.error(error.toString()));
    });
  }
}

class AboutPromotionalViewModel with ChangeNotifier{

  final _myRepo = BeforeLoginRepository();

  ApiResponse<PromotionalResponseModel> promotional = ApiResponse.loading();

  setAboutCompanyList(ApiResponse<PromotionalResponseModel> response){
    promotional = response;
    notifyListeners();
  }

  Future<void> fetchPromotional() async {

    setAboutCompanyList(ApiResponse.loading());

    _myRepo.fetchPromotional().then((value){

      setAboutCompanyList(ApiResponse.completed(value));

    }).onError((error, stackTrace){

      setAboutCompanyList(ApiResponse.error(error.toString()));
      if (kDebugMode) {
        print(error.toString());
      }

    });
  }

}

class ProfileSearchViewModel with ChangeNotifier{

  bool _loading = false ;
  bool get loading => _loading;

  bool _success = false ;
  bool get success => _success;

  final _myRepo = BeforeLoginRepository();

  setLoading(bool value){
    _loading = value;
    notifyListeners();
  }

  Future<void> getProfile(data, BuildContext context) async {

    setLoading(true);
    _myRepo.getprofile(data).then((value){
      setLoading(false);
      if(value.success == true){
        Utils.flushBarSuccessMessage(ConstantStrings.otpSent, context);
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => OtpScreen(
                    id: value.data!.id!,
                    email: value.data!.email!
                )));
      }else{
        Utils.errorAlertDialogue(value.message, context);
      }

    }).onError((error, stackTrace){
      
      setLoading(false);
      
      if (kDebugMode) {
        print(error.toString());
      }

    });
  }

  Future<void> resendOtp(data, BuildContext context) async {

    setLoading(true);
    _myRepo.getprofile(data).then((value){
      setLoading(false);
      if(value.success == true){
        Utils.flushBarSuccessMessage(ConstantStrings.otpSent, context);
      }else{
        Utils.errorAlertDialogue(value.message, context);
      }
    }).onError((error, stackTrace){
      setLoading(false);
      if (kDebugMode) {
        print(error.toString());
      }
    });
  }

}

class OtpVerifyViewModel with ChangeNotifier{

  bool _loading = false ;
  bool get loading => _loading;

  final _myRepo = BeforeLoginRepository();

  setLoading(bool value){
    _loading = value;
    notifyListeners();
  }

  Future<void> verifyOtp(data, BuildContext context) async {

    setLoading(true);

    _myRepo.verifyOtp(data).then((value){
      setLoading(false);
      if(value.success == true){

        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ResetPasswordScreen(
                    id: value.data!.id!,
                )));

      }else{
        Utils.errorAlertDialogue(value.message, context);
      }

    }).onError((error, stackTrace){

      setLoading(false);

      if (kDebugMode) {
        print(error.toString());
      }

    });
  }

}

class ResetPasswordViewModel with ChangeNotifier{

  bool _loading = false ;
  bool get loading => _loading;

  final _myRepo = BeforeLoginRepository();

  setLoading(bool value){
    _loading = value;
    notifyListeners();
  }

  Future<void> resetPassword(data, BuildContext context ,

      TextEditingController newPassword,
      TextEditingController confirmPassword,

      ) async {

    setLoading(true);

    _myRepo.resetPassword(data).then((value){
      setLoading(false);
      if(value.success == true){

        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => LoginScreen()));

        newPassword.clear();
        confirmPassword.clear();

      }else{
        Utils.errorAlertDialogue(value.message, context);
      }

    }).onError((error, stackTrace){

      setLoading(false);

      if (kDebugMode) {
        print(error.toString());
      }

    });
  }

}

class FAQsViewModel with ChangeNotifier{

  final _myRepo = BeforeLoginRepository();

  ApiResponse<FAQsResponseModel> faqs = ApiResponse.loading();

  setFAQsList(ApiResponse<FAQsResponseModel> response){
    faqs = response;
    notifyListeners();
  }

  Future<void> fetchFAQs() async {
    setFAQsList(ApiResponse.loading());
    _myRepo.getFAQs().then((value){

      setFAQsList(ApiResponse.completed(value));

    }).onError((error, stackTrace){
      setFAQsList(ApiResponse.error(error.toString()));

    });
  }

}
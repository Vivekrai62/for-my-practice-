import 'package:flutter/material.dart';

// class Responsive extends StatelessWidget {
//   final Widget mobile;
//   final Widget tablet;
//   final Widget desktop;
//
//   // Add responsive toolbar heights
//   final double mobileToolbarHeight;
//   final double tabletToolbarHeight;
//   final double desktopToolbarHeight;
//
//   const Responsive({
//     Key? key,
//     required this.mobile,
//     required this.tablet,
//     required this.desktop,
//     this.mobileToolbarHeight = 56.0,
//     this.tabletToolbarHeight = 64.0,
//     this.desktopToolbarHeight = 80.0,
//   }) : super(key: key);
//
//   static bool isMobile(BuildContext context) => MediaQuery.of(context).size.width < 600;
//   static bool isTablet(BuildContext context) => MediaQuery.of(context).size.width >= 600 && MediaQuery.of(context).size.width < 1200;
//   static bool isDesktop(BuildContext context) => MediaQuery.of(context).size.width >= 1200;
//
//   @override
//   Widget build(BuildContext context) {
//     final isMobileDevice = isMobile(context);
//     final isTabletDevice = isTablet(context);
//
//     // Determine toolbar height based on device type
//     double toolbarHeight = isMobileDevice
//         ? mobileToolbarHeight
//         : (isTabletDevice ? tabletToolbarHeight : desktopToolbarHeight);
//
//     return Scaffold(
//       appBar: AppBar(
//         toolbarHeight: toolbarHeight,
//         title: Text('Responsive App'),
//       ),
//       body: isDesktop(context)
//           ? desktop
//           : (isTablet(context) ? tablet : Column(
//         children: [
//           Expanded(child: mobile),
//           Expanded(child: tablet), // Display both screens in a column
//         ],
//       )),
//     );
//   }
// }


// import 'package:flutter/material.dart';
//
// class Responsive extends StatelessWidget {
//   final Widget mobile;
//   final Widget tablet;
//   final Widget desktop;
//
//   final double mobileToolbarHeight;
//   final double tabletToolbarHeight;
//   final double desktopToolbarHeight;
//
//   const Responsive({
//     Key? key,
//     required this.mobile,
//     required this.tablet,
//     required this.desktop,
//     this.mobileToolbarHeight = 56.0,
//     this.tabletToolbarHeight = 64.0,
//     this.desktopToolbarHeight = 80.0,
//   }) : super(key: key);
//
//   static bool isMobile(BuildContext context) => MediaQuery.of(context).size.width < 600;
//   static bool isTablet(BuildContext context) => MediaQuery.of(context).size.width >= 600 && MediaQuery.of(context).size.width < 1200;
//   static bool isDesktop(BuildContext context) => MediaQuery.of(context).size.width >= 1200;
//
//   @override
//   Widget build(BuildContext context) {
//     final isMobileDevice = isMobile(context);
//     final isTabletDevice = isTablet(context);
//
//     double toolbarHeight = isMobileDevice
//         ? mobileToolbarHeight
//         : (isTabletDevice ? tabletToolbarHeight : desktopToolbarHeight);
//
//     return Scaffold(
//       appBar: AppBar(
//         toolbarHeight: toolbarHeight,
//         title: Text('Responsive App'),
//       ),
//       body: isDesktop(context)
//           ? desktop
//           : (isTablet(context) ? tablet : mobile),
//     );
//   }
// }

import 'package:flutter/material.dart';

class Responsive extends StatelessWidget {
  final Widget mobile;
  final Widget tablet;
  final Widget desktop;

  final double mobileToolbarHeight;
  final double tabletToolbarHeight;
  final double desktopToolbarHeight;

  final PreferredSizeWidget? mobileAppBar;
  final PreferredSizeWidget? tabletAppBar;
  final PreferredSizeWidget? desktopAppBar;

  final EdgeInsets? desktopPadding;

  const Responsive({
    Key? key,
    required this.mobile,
    required this.tablet,
    required this.desktop,
    this.mobileToolbarHeight = 56.0,
    this.tabletToolbarHeight = 64.0,
    this.desktopToolbarHeight = 80.0,
    this.mobileAppBar,
    this.tabletAppBar,
    this.desktopAppBar,
    this.desktopPadding,
  }) : super(key: key);

  static bool isMobile(BuildContext context) => MediaQuery.of(context).size.width < 600;
  static bool isTablet(BuildContext context) => MediaQuery.of(context).size.width >= 600 && MediaQuery.of(context).size.width < 1200;
  static bool isDesktop(BuildContext context) => MediaQuery.of(context).size.width >= 1200;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final bool isMobileDevice = isMobile(context);
        final bool isTabletDevice = isTablet(context);
        final bool isDesktopDevice = isDesktop(context);

        double getResponsiveWidth(BuildContext context) {
          double screenWidth = MediaQuery.of(context).size.width;

          if (screenWidth < 600) {
            // Mobile devices
            return screenWidth * 0.3;  // 30% of screen width for mobile
          } else if (screenWidth < 1200) {
            // Tablets
            return screenWidth * 0.15;  // 15% of screen width for tablets
          } else {
            // Desktops or large screens
            return screenWidth * 0.09;  // 9% of screen width for desktops
          }
        }
        double toolbarHeight = isMobileDevice
            ? mobileToolbarHeight
            : (isTabletDevice ? tabletToolbarHeight : desktopToolbarHeight);

        PreferredSizeWidget? appBar = isMobileDevice
            ? mobileAppBar
            : (isTabletDevice ? tabletAppBar : desktopAppBar);

        EdgeInsets? padding = isDesktopDevice ? desktopPadding : EdgeInsets.zero;

        return Scaffold(
          appBar: appBar,
          body: Padding(
            padding: padding ?? EdgeInsets.zero,
            child: isDesktopDevice
                ? desktop
                : (isTabletDevice
                ? tablet
                : mobile
            ),
          ),
        );
      },
    );
  }
}

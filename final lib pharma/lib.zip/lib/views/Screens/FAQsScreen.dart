import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pharma_clients_app/view_model/beforeLogin_viewModels/beforeLogin_viewModel.dart';
import 'package:provider/provider.dart';
import '../../data/response/status.dart';
import '../../resources/app_colors.dart';
import '../../resources/constant_imageString.dart';
import '../../resources/constant_strings.dart';
import '../../utils/Dialogue/error_dialogue.dart';
import '../../utils/text_style.dart';

class FAQsScreen extends StatefulWidget {
  const FAQsScreen({Key? key}) : super(key: key);

  @override
  State<FAQsScreen> createState() => _FAQsScreenState();
}

class _FAQsScreenState extends State<FAQsScreen> {
  late FAQsViewModel model;

  @override
  void initState() {
    super.initState();
    model = FAQsViewModel();
    model.fetchFAQs();
  }

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width >= 600;
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    // Adjusted scaling factors for reduced height in tablet
    final double marginFactor = isTablet ? 0.015 : 0.01;  // Smaller margin for tablet
    final double paddingFactor = isTablet ? 0.015 : 0.03; // Smaller padding for tablet
    final double fontSizeTitleFactor = isTablet ? 0.022 : 0.045;
    final double fontSizeContentFactor = isTablet ? 0.018 : 0.04;
    final double boxHeightFactor = isTablet ? 0.08 : 0.18; // Reduced box height for tablet
    final double imageWidthFactor = isTablet ? 0.4 : 0.7;

    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: Row(
          children: [
            TextWithStyle.appBarTitle(
              context,
              ConstantStrings.faqsScreen,
            ),
          ],
        ),
      ),
      body: ChangeNotifierProvider<FAQsViewModel>(
        create: (BuildContext context) => model,
        child: Consumer<FAQsViewModel>(builder: (context, value, _) {
          switch (value.faqs.status!) {
            case Status.loading:
              return SingleChildScrollView(
                child: Container(
                  height: screenHeight,
                  width: screenWidth,
                  color: AppColors.backgroundColor,
                  child: Center(
                    child: Image.asset(
                      'assets/images/png/loading-gif.gif',
                      height: screenHeight * 0.1,
                    ),
                  ),
                ),
              );
            case Status.error:
              return ErrorDialogue(
                message: value.faqs.message.toString(),
              );
            case Status.completed:
              return value.faqs.data!.faqs != null && value.faqs.data!.faqs!.isNotEmpty
                  ? ListView.builder(
                itemCount: value.faqs.data!.faqs!.length,
                itemBuilder: (context, index) {
                  final item = value.faqs.data!.faqs![index];
                  final question = item.question ?? 'No question available';
                  final answer = item.answer ?? 'No answer available';

                  return Container(
                    margin: EdgeInsets.symmetric(
                      vertical: screenHeight * marginFactor,
                      horizontal: screenWidth * marginFactor,
                    ),
                    padding: EdgeInsets.symmetric(
                      vertical: screenHeight * paddingFactor,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(screenWidth * 0.02)),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.primaryColor.withOpacity(0.1),
                          spreadRadius: 1,
                          blurRadius: 4,
                          offset: const Offset(0, 0),
                        ),
                      ],
                    ),
                    child:
                    ExpansionTile(
                      title: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          question,
                          style: TextStyle(
                            fontSize: screenWidth * fontSizeTitleFactor,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      childrenPadding: EdgeInsets.symmetric(
                        vertical: isTablet ? screenHeight * 0.001 : screenHeight * 0.01, // Adjust padding for tablet and mobile
                        horizontal: isTablet ? screenWidth * 0.02 : screenWidth * 0.04,  // Adjust horizontal padding for tablet and mobile
                      ),

                      children: [
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                            padding: EdgeInsets.only(top: screenHeight * 0.01),
                            child: Text(
                              answer,
                              style: TextStyle(
                                fontSize: screenWidth * fontSizeContentFactor,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: screenHeight * 0.01,
                        ),
                      ],
                    ),
                  );
                },
              )
                  : Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      ConstantImage.empty,
                      width: screenWidth * imageWidthFactor,
                      fit: BoxFit.fill,
                    ),
                    SizedBox(height: screenHeight * 0.02),
                    TextWithStyle.appBarTitle(
                      context,
                      ConstantStrings.emptyScreen,
                    ),
                  ],
                ),
              );
          }
        }),
      ),
    );
  }
}

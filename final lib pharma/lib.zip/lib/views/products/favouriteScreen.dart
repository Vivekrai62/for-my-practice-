import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:provider/provider.dart';
import '../../data/model/response_model/products/product_reponse_model.dart';
import '../../data/response/status.dart';
import '../../resources/app_colors.dart';
import '../../resources/constant_strings.dart';
import '../../utils/Dialogue/error_dialogue.dart';
import 'product_list_widget.dart';
import '../../utils/text_style.dart';
import '../../view_model/afterLogin_viewModel/afterLogin_viewModels.dart';

// ignore: must_be_immutable
class FavouriteScreen extends StatefulWidget {
  FavouriteScreen({Key? key, required this.token}) : super(key: key);

  String? token;

  @override
  State<FavouriteScreen> createState() => _FavouriteScreenState();
}

class _FavouriteScreenState extends State<FavouriteScreen> {
  ProductViewModel model1 = ProductViewModel();
  List<Products> value1 = [];
  List<Products> product = [];
  List<String> remove = [];

  @override
  void initState() {
    super.initState();
    model1.fetchProductsApi();
  }

  @override
  void dispose() {
    value1.clear();
    product.clear();
    super.dispose();
  }

  Future<void> Product() async {
    model1.favProducts.clear();
    model1.fetchProductsApi();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        elevation: 0,
        centerTitle: false,
        title: TextWithStyle.appBarTitle(context, ConstantStrings.favouriteScreenHeading),
      ),
      body: ChangeNotifierProvider(
        create: (BuildContext context) => model1,
        child: Consumer<ProductViewModel>(
          builder: (context, value, _) {
            switch (value.productlist.status!) {
              case Status.loading:
                return Container(
                  height: MediaQuery.of(context).size.height,
                  width: MediaQuery.of(context).size.width,
                  color: AppColors.backgroundColor,
                  child: Center(
                    child: LoadingAnimationWidget.discreteCircle(
                      color: AppColors.primaryColor,
                      size: 40,
                    ),
                  ),
                );
              case Status.error:
                return Center(
                  child: ErrorDialogue(message: value.productlist.message.toString()),
                );
              case Status.completed:
                List<Products> product = value.products.where((element) => element.favourite == true).toList();
                return ProductList(
                  product: product,
                  token: widget.token,
                );
            }
          },
        ),
      ),
    );
  }
}

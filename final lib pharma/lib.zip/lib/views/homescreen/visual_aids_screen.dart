import 'dart:async';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:pharma_clients_app/resources/app_colors.dart';
import 'package:pharma_clients_app/resources/constant_strings.dart';
import 'package:pharma_clients_app/utils/text_style.dart';
import 'package:pharma_clients_app/views/presentation/addPresentationScreen.dart';
import 'package:pharma_clients_app/views/presentation/presentaionListScreen.dart';
import 'package:photo_view/photo_view.dart';
import 'package:provider/provider.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import '../../data/model/response_model/visual_aids_response_model.dart';
import '../../data/response/status.dart';
import '../../resources/constant_imageString.dart';
import '../../utils/Dialogue/error_dialogue.dart';
import '../../view_model/afterLogin_viewModel/afterLogin_viewModels.dart';
import '../../view_model/beforeLogin_viewModels/beforeLogin_viewModel.dart';

// ignore: must_be_immutable
class VisualAidsScreen extends StatefulWidget {
  VisualAidsScreen({
    required this.token,
    Key? key}) : super(key: key);


  String? token;
  @override
  State<VisualAidsScreen> createState() => _VisualAidsScreenState();
}

class _VisualAidsScreenState extends State<VisualAidsScreen> {

  TextEditingController controller = TextEditingController();

  GuestVisualAidsViewModel model = GuestVisualAidsViewModel();
  VisualAidsViewModel model1 = VisualAidsViewModel();

  @override
  void initState() {

    // TODO: implement initState
    if(widget.token != null && widget.token!.isNotEmpty){
      model1.fetchVisualAids();
    }else{
      model.fetchVisualAids();
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    return widget.token != null && widget.token!.isNotEmpty
        ? ChangeNotifierProvider<VisualAidsViewModel>(
      create: (BuildContext context) => model1,
      child: Consumer<VisualAidsViewModel>(
        builder: (context, value, _) {
          switch (value.visualaidsList.status!) {
            case Status.loading:
              return Container(
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                color: AppColors.backgroundColor,
                child: Center(
                    child: LoadingAnimationWidget.discreteCircle(
                        color: AppColors.primaryColor,
                        size: 40)
                ),
              );
            case Status.error:
              return ErrorDialogue(message: value.visualaidsList.message);
            case Status.completed:
              return Scaffold(
                backgroundColor: AppColors.backgroundColor,


                appBar: AppBar(
                  elevation: 0,

                   // automaticallyImplyLeading: false,
                  // toolbarHeight: 7.h,

                  centerTitle: false,

                  title: TextWithStyle.appBarTitle(context, ConstantStrings.visualAidsscreenHeading),
                  actions: [
                    IconButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => PresentationListScreen()));
                      },
                      icon: Icon(CupertinoIcons.play_rectangle,
                        size:
                        MediaQuery.of(context).size.width >= 1024
                            ? MediaQuery.of(context).size.width * 0.05 // Desktop (5% of width)
                            : MediaQuery.of(context).size.width >= 600
                            ? MediaQuery.of(context).size.width * 0.03 // Tablet (6% of width)
                            : MediaQuery.of(context).size.width * 0.07, // Mobile (7% of width)

                      ),
                    ),
                    SizedBox(width: 1.w), // Reduced width for better spacing

                    IconButton(
                      onPressed: () {
                        showModalBottomSheet(
                          context: context,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(top: Radius.circular(16.0)),
                          ),
                          backgroundColor: Colors.white,
                          isScrollControlled: true,
                          builder: (BuildContext context) {
                            final width = MediaQuery.of(context).size.width;
                            return Container(
                              width: width, // Ensure full width
                              child: ChangeNotifierProvider.value(
                                value: model1,
                                child: Consumer<VisualAidsViewModel>(
                                  builder: (context, value, _) {
                                    return Container(
                                      height: MediaQuery.of(context).size.height * 0.8,
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            padding: EdgeInsets.only(left: 2.h, top: 2.h),
                                            child: TextWithStyle.productTitle(context, 'Filters'),
                                          ),
                                          Divider(color: Colors.black.withOpacity(0.1)),
                                          Expanded(
                                            child: Row(
                                              children: [
                                                Expanded( // Changed Flexible to Expanded
                                                  flex: 1,
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      borderRadius: BorderRadius.only(topLeft: Radius.circular(2.h)),
                                                    ),
                                                    child: ListView(
                                                      shrinkWrap: true, // Use shrinkWrap to avoid overflow
                                                      children: value.filterOptions.keys.map((category) {
                                                        final bool isSelected = category == value.selectedCategory;
                                                        final selectedCount = value.getSelectedCount(category);
                                                        return GestureDetector(
                                                          onTap: () {
                                                            value.selectCategory(category);
                                                          },
                                                          child: Container(
                                                            color: isSelected ? AppColors.primaryColor : Colors.transparent,
                                                            child: ListTile(
                                                              title: Text(
                                                                '${category} ${selectedCount == 0 ? '' : '(${selectedCount})'}',
                                                                style: TextStyle(
                                                                  color: isSelected ? Colors.white : Colors.black,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        );
                                                      }).toList(),
                                                    ),
                                                  ),
                                                ),
                                                VerticalDivider(
                                                  color: Colors.black.withOpacity(0.1),
                                                  width: 1,
                                                ),
                                                Expanded( // Changed Flexible to Expanded
                                                  flex: 2,
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Padding(
                                                        padding: EdgeInsets.symmetric(horizontal: 8.0, vertical: 8.0),
                                                        child: TextField(
                                                          decoration: InputDecoration(
                                                            filled: true,
                                                            fillColor: AppColors.primaryColor.withOpacity(0.05),
                                                            enabledBorder: OutlineInputBorder(
                                                              borderRadius: BorderRadius.all(Radius.circular(15)),
                                                              borderSide: BorderSide(color: AppColors.backgroundColor),
                                                            ),
                                                            focusedBorder: OutlineInputBorder(
                                                              borderRadius: BorderRadius.all(Radius.circular(15)),
                                                              borderSide: BorderSide(color: AppColors.backgroundColor),
                                                            ),
                                                            contentPadding: EdgeInsets.all(2.h),
                                                            prefixIcon: Padding(
                                                              padding: EdgeInsets.symmetric(horizontal: 1.4.h),
                                                              child: Image.asset("assets/images/png/search.png", width: 1.h),
                                                            ),
                                                            border: InputBorder.none,
                                                            hintText: "Search",
                                                            hintStyle: TextStyle(color: Colors.black38),
                                                          ),
                                                          onChanged: value.updateSearchText,
                                                        ),
                                                      ),
                                                      Expanded(
                                                        child: ListView(
                                                          padding: EdgeInsets.only(left: 10),
                                                          shrinkWrap: true, // Use shrinkWrap to avoid overflow
                                                          children: value.getFilteredOptions().map((option) {
                                                            final isSelected = value.selectedFilters[value.selectedCategory]?.contains(option) == true;
                                                            return Column(
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              children: [
                                                                FilterChip(
                                                                  label: Text(option),
                                                                  backgroundColor: Colors.white,
                                                                  selectedColor: AppColors.primaryColor.withOpacity(0.05),
                                                                  selected: isSelected,
                                                                  onSelected: (_) => value.toggleFilterOption(value.selectedCategory, option),
                                                                ),
                                                              ],
                                                            );
                                                          }).toList(),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Divider(color: Colors.black.withOpacity(0.1)),
                                          Container(
                                            padding: EdgeInsets.only(bottom: 3.h, right: 2.h, left: 2.h, top: 0.5.h),
                                            color: Colors.white,
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                OutlinedButton(
                                                  onPressed: value.clearFilters,
                                                  style: OutlinedButton.styleFrom(
                                                    backgroundColor: Colors.white,
                                                    minimumSize: Size(width / 3, MediaQuery.of(context).size.height / 17),
                                                    shape: RoundedRectangleBorder(
                                                      borderRadius: BorderRadius.all(Radius.circular(4.h)),
                                                    ),
                                                  ),
                                                  child: Text('Clear', style: TextStyle(color: Colors.black, fontSize: 17.sp, fontWeight: FontWeight.w400)),
                                                ),
                                                ElevatedButton(
                                                  onPressed: () {
                                                    value.applyFilters();
                                                    print('Selected Filters: ${value.selectedFilters}');
                                                    Navigator.of(context).pop();
                                                  },
                                                  style: ElevatedButton.styleFrom(
                                                    backgroundColor: AppColors.primaryColor,
                                                    minimumSize: Size(width / 3, MediaQuery.of(context).size.height / 17),
                                                    shape: RoundedRectangleBorder(
                                                      borderRadius: BorderRadius.all(Radius.circular(4.h)),
                                                    ),
                                                  ),
                                                  child: Text('Apply', style: TextStyle(color: Colors.white, fontSize: 17.sp, fontWeight: FontWeight.w400)),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                              ),
                            );
                          },
                        );
                      },
                      icon: Icon(CupertinoIcons.slider_horizontal_3,

                        size:
                        MediaQuery.of(context).size.width >= 1024
                            ? MediaQuery.of(context).size.width * 0.05 // Desktop (5% of width)
                            : MediaQuery.of(context).size.width >= 600
                            ? MediaQuery.of(context).size.width * 0.03 // Tablet (6% of width)
                            : MediaQuery.of(context).size.width * 0.07, // Mobile (7% of width)



                      ),
                    ),
                    SizedBox(width: 1.w), // Reduced width for better spacing
                  ],
                ),

                body:
                Column(
                  children: [
                    Container(
                      margin: EdgeInsets.symmetric(
                        horizontal: MediaQuery.of(context).size.width >= 600 ? 17.0 : 12.0,  // Larger margin for tablets
                      ),
                      child: TextFormField(
                        style: TextStyle(
                          fontSize: MediaQuery.of(context).size.width >= 600 ? 18.0 : 16.0,  // Larger text size for tablets
                        ),
                        controller: controller,
                        onChanged: (value) {
                          model1.filteredVisuals(value.toLowerCase(), [], [], [], [], []);
                        },
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: AppColors.primaryColor.withOpacity(0.05),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: const BorderRadius.all(Radius.circular(15)),
                            borderSide: BorderSide(color: AppColors.backgroundColor),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: const BorderRadius.all(Radius.circular(15)),
                            borderSide: BorderSide(color: AppColors.backgroundColor),
                          ),
                          contentPadding: EdgeInsets.all(
                            MediaQuery.of(context).size.width >= 600 ? 24.0 : 16.0,  // Adjust padding based on screen size
                          ),
                          prefixIcon: Padding(
                            padding: EdgeInsets.symmetric(
                              horizontal: MediaQuery.of(context).size.width >= 600 ? 16.0 : 10.0,  // Larger padding for tablets
                            ),
                            child: Image.asset(
                              ConstantImage.search,
                              width: MediaQuery.of(context).size.width >= 600 ? 28.0 : 24.0,  // Larger icon size for tablets
                            ),
                          ),
                          border: InputBorder.none,
                          hintText: "Search",
                          hintStyle: TextStyle(
                            color: Colors.black38,
                            fontSize: MediaQuery.of(context).size.width >= 600 ? 18.0 : 16.0,  // Larger hint text size for tablets
                          ),
                        ),
                      ),
                    ),

                    Expanded(
                      child: value.visualAids.isNotEmpty
                          ? Container(
                          margin: EdgeInsets.only(left: 1.h, right: 1.h, top: 1.h),
                          child:
                          GridView.builder(
                            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: MediaQuery.of(context).size.width >= 600 ? 3 : 2, // 3 items per row on tablets, 2 items per row on mobile
                              crossAxisSpacing: 8.0, // Adjust spacing between items as needed
                              mainAxisSpacing: 8.0, // Adjust spacing between items as needed
                            ),
                            itemCount: value.visualAids.length,
                            itemBuilder: (context, index) {
                              return InkWell(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => ImagePage(
                                        images: value.visualAids,
                                        initialIndex: index,
                                      ),
                                    ),
                                  );
                                },
                                child: Card(
                                  margin: EdgeInsets.only(left: 8.0, right: 8.0, top: 16.0), // Adjust margins as needed
                                  elevation: 4.0, // Adjust elevation as needed
                                  shadowColor: Colors.black54,
                                  surfaceTintColor: Colors.white,
                                  color: Colors.white,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(8.0)), // Adjust border radius as needed
                                  ),
                                  child: FadeInImage.assetNetwork(
                                    placeholder: 'assets/images/png/loading.gif',
                                    image: '${value.visualAids[index].url}',
                                    fit: BoxFit.cover, // Ensure image covers the card
                                  ),
                                ),
                              );
                            },
                          )

                      )
                          : Center(
                        child: SingleChildScrollView(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Image.asset(
                                ConstantImage.empty,
                                width: 70.w,
                                fit: BoxFit.fill,
                              ),
                              SizedBox(height: 2.h),
                              TextWithStyle.appBarTitle(context, ConstantStrings.emptyScreen)
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                floatingActionButton: ClipRRect(
                  borderRadius: BorderRadius.circular(100.0),
                  child: Container(
                    width: MediaQuery.of(context).size.width >= 600 ? 170.0 : 110.0,  // Larger size for tablets
                    height: MediaQuery.of(context).size.width >= 600 ? 70.0 : 56.0, // Larger size for tablets
                    child:
                    FloatingActionButton.extended(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const AddPresentationScreen(),
                          ),
                        );
                      },
                      backgroundColor: AppColors.primaryColor,
                      label: TextWithStyle.customerStatus(context, 'Slides', Colors.white),
                      icon: Icon(
                        CupertinoIcons.add,
                        color: Colors.white,
                        size: MediaQuery.of(context).size.width >= 600 ? 23.0 : 24.0,  // Larger icon size for tablets
                      ),
                    ),
                  ),
                ),

              );
          }
        },
      ),
    )
        : ChangeNotifierProvider<GuestVisualAidsViewModel>(
      create: (BuildContext context) => model,
      child: Consumer<GuestVisualAidsViewModel>(
        builder: (context,value,_){
          switch(value.visualaidsList.status!){
            case Status.loading:
              return Container(
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                color: AppColors.backgroundColor,
                child: Center(
                    child: LoadingAnimationWidget.discreteCircle(
                        color: AppColors.primaryColor,
                        size: 40)
                ),
              );
            case Status.error:
              if (kDebugMode) {
                print('run error');
              }
              return Center(
                child: Text(value.visualaidsList.message.toString()),
              );
            case Status.completed:
              return Scaffold(
                backgroundColor: AppColors.backgroundColor,
                appBar: AppBar(
                  elevation: 0,
                  centerTitle: false,
                  toolbarHeight: 7.h,
                  title: TextWithStyle.appBarTitle(context, ConstantStrings.visualAidsscreenHeading),
                  actions: [
                    IconButton(
                      onPressed: () {
                        showModalBottomSheet(
                          context: context,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(top: Radius.circular(16.0)),
                          ),
                          backgroundColor: Colors.white,
                          isScrollControlled: true,
                          builder: (BuildContext context) {
                            return ChangeNotifierProvider.value(
                              value: model,
                              child: Consumer<GuestVisualAidsViewModel>(
                                builder: (context, value, _) {
                                  return Container(
                                    height: MediaQuery.of(context).size.height * 0.8,
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          padding: EdgeInsets.only(left: 2.h,top: 2.h,),
                                          child: TextWithStyle.productTitle(context, 'Filters'),
                                        ),
                                        Divider(
                                          color: Colors.black.withOpacity(0.1),
                                        ),
                                        Expanded(
                                          child: Row(
                                            children: [
                                              Container(
                                                width: MediaQuery.of(context).size.width / 3,
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.only(topLeft: Radius.circular(2.h)),
                                                ),
                                                child: ListView(
                                                  children: value.filterOptions.keys.map((category) {
                                                    final bool isSelected = category == value.selectedCategory;
                                                    final selectedCount = value.getSelectedCount(category);
                                                    return GestureDetector(
                                                      onTap: () {
                                                        value.selectCategory(category);
                                                      },
                                                      child: Container(
                                                        color: isSelected ? AppColors.primaryColor : Colors.transparent,
                                                        child: ListTile(
                                                          title: Text(
                                                            '${category} ${selectedCount == 0 ? '' : '(${selectedCount})'}',
                                                            style: TextStyle(
                                                              color: isSelected ? Colors.white : Colors.black,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    );
                                                  }).toList(),
                                                ),
                                              ),
                                              VerticalDivider(
                                                color: Colors.black.withOpacity(0.1),
                                                width: 1,
                                              ),
                                              Expanded(
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Padding(
                                                      padding: const EdgeInsets.only(left: 8.0,right: 8.0,bottom: 8.0),
                                                      child: TextField(
                                                        decoration: InputDecoration(
                                                            filled: true,
                                                            fillColor: AppColors.primaryColor
                                                                .withOpacity(0.05),
                                                            enabledBorder: OutlineInputBorder(
                                                                borderRadius:
                                                                const BorderRadius.all(
                                                                    Radius.circular(15)),
                                                                borderSide: BorderSide(
                                                                    color: AppColors
                                                                        .backgroundColor)),
                                                            focusedBorder: OutlineInputBorder(
                                                                borderRadius: const BorderRadius
                                                                    .all(Radius.circular(15)),
                                                                borderSide: BorderSide(
                                                                    color: AppColors
                                                                        .backgroundColor)),
                                                            contentPadding: EdgeInsets.all(2.h),
                                                            prefixIcon: Padding(
                                                              padding: EdgeInsets.only(
                                                                  left: 1.4.h, right: 1.4.h),
                                                              child: Image.asset(
                                                                  "assets/images/png/search.png",
                                                                  width: 1.h),
                                                            ),
                                                            border: InputBorder.none,
                                                            hintText: "Search",
                                                            hintStyle: const TextStyle(
                                                                color: Colors.black38)
                                                        ),
                                                        onChanged: value.updateSearchText,
                                                      ),
                                                    ),
                                                    Expanded(
                                                      child: ListView(
                                                        padding: const EdgeInsets.only(left: 10),
                                                        children: value.getFilteredOptions().map((option) {
                                                          final isSelected = value.selectedFilters[value.selectedCategory]?.contains(option) == true;
                                                          return Column(
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              FilterChip(
                                                                label: Text(option),
                                                                backgroundColor: Colors.white,
                                                                selectedColor: AppColors.primaryColor.withOpacity(0.05),
                                                                selected: isSelected,
                                                                onSelected: (_) => value.toggleFilterOption(value.selectedCategory, option),
                                                              ),
                                                            ],
                                                          );
                                                        }).toList(),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Divider(
                                          color: Colors.black.withOpacity(0.1),
                                        ),
                                        Container(
                                          padding: EdgeInsets.only(bottom: 3.h,right: 2.h,left: 2.h,top: 0.5.h),
                                          color: Colors.white,
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              OutlinedButton(
                                                  onPressed: value.clearFilters,
                                                  style: OutlinedButton.styleFrom(
                                                      backgroundColor: Colors.white,
                                                      minimumSize: Size(MediaQuery
                                                          .of(context)
                                                          .size
                                                          .width / 3,
                                                          MediaQuery
                                                              .of(context)
                                                              .size
                                                              .height / 17),
                                                      shape: RoundedRectangleBorder(
                                                          borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(4.h)))
                                                  ),
                                                  child: Text('Clear',
                                                      style: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 17.sp,
                                                          fontWeight: FontWeight.w400))
                                              ),
                                              ElevatedButton(
                                                onPressed: () {
                                                  value.applyFilters();
                                                  print('Selected Filters: ${value.selectedFilters}');
                                                  Navigator.of(context).pop();
                                                },
                                                style: ElevatedButton.styleFrom(
                                                    backgroundColor: AppColors.primaryColor,
                                                    minimumSize: Size(MediaQuery
                                                        .of(context)
                                                        .size
                                                        .width / 3,
                                                        MediaQuery
                                                            .of(context)
                                                            .size
                                                            .height / 17),
                                                    shape: RoundedRectangleBorder(
                                                        borderRadius:
                                                        BorderRadius.all(
                                                            Radius.circular(4.h)))
                                                ),
                                                child: Text('Apply',
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 17.sp,
                                                        fontWeight: FontWeight.w400)),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                        );
                      },
                      icon: Icon(CupertinoIcons.slider_horizontal_3, size: 5.w),
                    ),
                    SizedBox(width: 4.w)
                  ],
                ),
                body: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.all(3.w),
                      child: TextFormField(
                        style: TextStyle(fontSize: 16.sp),
                        controller: controller,
                        onChanged: (value) {
                          model.filteredVisuals(value.toLowerCase(),[],[],[],[],[]);
                        },
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: AppColors.primaryColor.withOpacity(0.05),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: const BorderRadius.all(Radius.circular(15)),
                            borderSide: BorderSide(color: AppColors.backgroundColor),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: const BorderRadius.all(Radius.circular(15)),
                            borderSide: BorderSide(color: AppColors.backgroundColor),
                          ),
                          contentPadding: EdgeInsets.all(2.h),
                          prefixIcon:
                          Padding(
                            padding: EdgeInsets.only(
                              left: MediaQuery.of(context).size.width >= 600 ? 16.0 : 10.0,  // Larger padding for tablets
                              right: MediaQuery.of(context).size.width >= 600 ? 16.0 : 10.0, // Larger padding for tablets
                            ),
                            child: Image.asset(
                              ConstantImage.search,
                              width: MediaQuery.of(context).size.height * (MediaQuery.of(context).size.width >= 600 ? 0.036 : 0.025), // Larger icon size for tablets
                            ),
                          ),
                          border: InputBorder.none,
                          hintText: "Search by Name, Type & Category",
                          hintStyle: const TextStyle(color: Colors.black38),
                        ),
                      ),
                    ),
                    Expanded(
                      child: value.visualAids.isNotEmpty
                          ? Container(
                          margin: EdgeInsets.only(left: 1.h, right: 1.h, top: 1.h),
                          child:
                          GridView.builder(
                            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: MediaQuery.of(context).size.width > 600 ? 3 : 2, // 3 items per row on tablet and 2 on mobile
                              childAspectRatio: 1, // Adjust this ratio if needed
                            ),
                            itemCount: value.visualAids.length,
                            itemBuilder: (context, index) {
                              return InkWell(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => ImagePage(
                                        images: value.visualAids,
                                        initialIndex: index,
                                      ),
                                    ),
                                  );
                                },
                                child: Card(
                                  margin: EdgeInsets.only(left: 8.0, right: 8.0, top: 16.0), // Adjust margin as needed
                                  elevation: 2.0,
                                  shadowColor: Colors.black54,
                                  surfaceTintColor: Colors.white,
                                  color: Colors.white,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(8.0)), // Adjust radius as needed
                                  ),
                                  child: FadeInImage.assetNetwork(
                                    placeholder: 'assets/images/png/loading.gif',
                                    image: '${value.visualAids[index].url}',
                                  ),
                                ),
                              );
                            },
                          )

                      )
                          : Center(
                        child: SingleChildScrollView(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Image.asset(
                                ConstantImage.empty,
                                width: 70.w,
                                fit: BoxFit.fill,
                              ),
                              SizedBox(height: 2.h),
                              TextWithStyle.appBarTitle(context, ConstantStrings.emptyScreen)
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
          }
        },
      ),
    );
  }

  double getResponsiveWidth(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;

    if (screenWidth < 600) {
      // Mobile devices
      return screenWidth * 0.0001;  // 30% of screen width for mobile
    } else if (screenWidth < 1200) {
      // Tablets
      return screenWidth * 0.03;  // 15% of screen width for tablets
    } else {
      // Desktops or large screens
      return screenWidth * 0.09;  // 9% of screen width for desktops
    }
  }

}

class ImagePage extends StatelessWidget {
  final dynamic images;
  final int initialIndex;

  ImagePage({
    required this.images,
    required this.initialIndex,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Previews'),
      ),
      body: images is String
          ? Center(
        child: PhotoView(
            imageProvider: NetworkImage(images),
            backgroundDecoration: const BoxDecoration(color: Colors.white),
            enableRotation: true
        ),
      )
          : images is List<VisualAids>
          ? PageView.builder(
        itemCount: images.length,
        controller: PageController(initialPage: initialIndex),
        itemBuilder: (context, index) {
          return FutureBuilder(
            future: _getImageDimensions(images[index].url!),
            builder: (context, AsyncSnapshot<Size> snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return const Center(child: Text('Error loading image'));
              } else if (snapshot.hasData) {
                final size = snapshot.data!;
                final isPortrait = size.height < size.width; // Check for portrait mode
                return Container(
                  height: MediaQuery.of(context).size.height,
                  color: Colors.white,
                  child: Center(
                    child: Transform.rotate(
                      angle: isPortrait ? 3.14 / 2 : 0, // Rotate -90 degrees if portrait
                      child: PhotoView(
                        initialScale: PhotoViewComputedScale.covered * (MediaQuery.of(context).size.width / snapshot.data!.width)/1.9,
                        minScale: PhotoViewComputedScale.covered * (MediaQuery.of(context).size.width / snapshot.data!.width),
                        maxScale: PhotoViewComputedScale.covered * 2.0,
                        imageProvider: NetworkImage(
                          images[index].url!,
                        ),
                        backgroundDecoration: const BoxDecoration(color: Colors.white),
                        enableRotation: true,
                      ),
                    ),
                  ),
                );
              } else {
                return const Center(child: Text('No image found'));
              }
            },
          );
        },
      )
          : Center(
        child: Image.asset(
          'assets/images/png/no_image.png',
        ),
      ),
    );
  }

  Future<Size> _getImageDimensions(String url) async {
    final Completer<Size> completer = Completer();
    final Image image = Image.network(url);
    image.image.resolve(const ImageConfiguration()).addListener(
      ImageStreamListener((ImageInfo info, bool _) {
        final myImage = info.image;
        final size = Size(myImage.width.toDouble(), myImage.height.toDouble());
        completer.complete(size);
      }),
    );
    return completer.future;
  }
}




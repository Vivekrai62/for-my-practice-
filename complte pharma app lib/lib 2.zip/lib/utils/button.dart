import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:pharma_clients_app/resources/app_colors.dart';

class Button extends StatelessWidget {
  final VoidCallback? onPress;
  final String title;
  final bool loading;

  Button({
    this.onPress,
    required this.title,
    required this.loading,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isTablet = size.width >= 600;

    // Determine dimensions based on device type
    final double buttonWidth = isTablet
        ? size.width * 0.20  //  tablets
        : size.width * 0.34;  //  mobile

    final double buttonHeight = isTablet
        ? size.height * 0.06  //  tablets
        : size.height * 0.08; //  mobile

    final double borderRadius = isTablet ? 35.0 : 30.0; // Border radius
    final double fontSize = isTablet ? 19.0 : 17.5; // Font size

    return ElevatedButton(
      onPressed: onPress,
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.primaryColor,
        minimumSize: Size(buttonWidth, buttonHeight),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(borderRadius),
        ),
        padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
      ),
      child: loading
          ? const CircularProgressIndicator(color: Colors.white)
          : Text(
        title,
        style: GoogleFonts.roboto(
          color: Colors.white,
          fontSize: fontSize,
          fontWeight: FontWeight.w400,
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import '../resources/app_colors.dart';
import '../resources/constant_strings.dart';
import 'Responsive/ResponsiveUtils.dart';

class TextWithStyle {
  static appToCart(context, String message) {
    return Text(
      message,
      style: TextStyle(
        fontSize: 15.sp,
        fontWeight: FontWeight.w500,
        color: AppColors.primaryColor,
      ),
    );
  }

  static appBarTitle(BuildContext context, String message) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize;
    FontWeight fontWeight;

    if (screenWidth >= 1024) {
      // Desktop
      fontSize = screenWidth * 0.022; // Scales font size based on screen width
      fontWeight = FontWeight.w600; // Heavier font weight for desktop
    } else if (screenWidth >= 600) {
      // Tablet
      fontSize = screenWidth * 0.023; // Scales font size based on screen width
      fontWeight = FontWeight.w500; // Medium weight for tablet
    } else {
      // Mobile
      fontSize = screenWidth * 0.045; // Scales font size based on screen width
      fontWeight = FontWeight.w600; // Lighter weight for mobile
    }

    return Text(
      message,
      style: TextStyle(
        fontSize: fontSize,
        fontWeight: fontWeight,
        letterSpacing: -0.2,
        color: Colors.black,
      ),
    );
  }

  static Widget OrderIdTitle(BuildContext context, String message) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize;
    FontWeight fontWeight;

    // Determine font size and weight based on screen width
    if (screenWidth >= 1024) {
      // Desktop
      fontSize = screenWidth * 0.022; // Scales font size based on screen width
      fontWeight = FontWeight.w600; // Heavier font weight for desktop
    } else if (screenWidth >= 600) {
      // Tablet
      fontSize = screenWidth * 0.024; // Scales font size based on screen width
      fontWeight = FontWeight.w500; // Medium weight for tablet
    } else {
      // Mobile
      fontSize = screenWidth * 0.045; // Scales font size based on screen width
      fontWeight = FontWeight.w600; // Lighter weight for mobile
    }

    return Text(
      message,
      style: TextStyle(
        fontSize: fontSize,
        fontWeight: fontWeight,
        letterSpacing: -0.2,
        color: Colors.black,
      ),
    );
  }

  static app_bar_Icon(context, String message) {
    return Text(
      message,
      style: TextStyle(
        fontSize: 17.sp,
        fontWeight: FontWeight.w500,
        color: AppColors.primaryColor,
      ),
    );
  }

  Widget app_bar_SizedBox(context, String message) {
    return Row(
      children: [
        SizedBox(
          width: MediaQuery.of(context).size.width < 600
              ? MediaQuery.of(context).size.width *
                  0.3 // 30% width for mobile devices
              : MediaQuery.of(context).size.width * 0.05,
          // 15% width for tablets
        ),
      ],
    );
  }

  // static UsernameDashboard(BuildContext){
  //   return
  //
  // }

  static double navigationRailIconSize(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    return screenWidth * 0.025;
  }

  static NavigationRailDashboard(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    return screenWidth * 0.017;
  }


  static TextStyle ProductMyorderquant(BuildContext context) {
    return TextStyle(
      fontSize: MediaQuery.of(context).size.width * 0.020,
      color: Colors.black54,
      fontWeight: FontWeight.w300, // Font weight
    );
  }
  static double SizedBoxAppbarWidth(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    return screenWidth <= 600 ? screenWidth * 0.05 :
    screenWidth <= 1024 ? screenWidth * 0.04 : 30;
  }

  static Widget containerTitle(BuildContext context, String message) {
    double screenWidth = MediaQuery.of(context).size.width;
    double responsiveFontSize = screenWidth >= 1200 ? 22 : screenWidth >= 600 ? 16 : 16;
    return Text(
      message,
      style: TextStyle(
        fontSize: responsiveFontSize,
        color: Colors.black,
        fontWeight: FontWeight.w400,
      ),
    );
  }

  static Widget welcomeTitle(BuildContext context, String message) {
    return Text(
      message,
      style: GoogleFonts.workSans(
        color: Colors.white,
        textStyle: TextStyle(
          fontSize: Responsive.isDesktop(context)
              ? 24.0 // Font size for Desktop2
              : (Responsive.isTablet(context)
                  ? MediaQuery.of(context).size.width * 0.037
                  : 30.0), // Font size for Mobile
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  static Widget Register_As_a_Distributors(
      BuildContext context, String message) {
    return Text(
      message,
      style: GoogleFonts.workSans(
        color: AppColors.primaryColor,
        textStyle: TextStyle(
          fontSize: Responsive.isDesktop(context)
              ? 24.0 // Desktop
              : (Responsive.isTablet(context)
                  ? 20.0 // Tablet
                  : 20.0), // Mobile

          fontWeight: Responsive.isDesktop(context)
              ? FontWeight.w600 // Font weight for Desktop
              : (Responsive.isTablet(context)
                  ? FontWeight.w600 // Font weight for Tablet
                  : FontWeight.w600), // Font weight for Mobile
        ),
      ),
    );
  }

  static Widget mainIconTitle(
      BuildContext context, String message, Color color) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize =
        screenWidth * 0.016;
    return Text(
      message,
      textAlign: TextAlign.center,
      style: TextStyle(
        fontSize: fontSize,
        color: color,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  static Widget pngIconTitle(BuildContext context, String message) {
    // Get the screen width
    double screenWidth = MediaQuery.of(context).size.width;

    // Set a base font size and adjust according to screen width
    double baseFontSize = 14.2; // base size for small devices
    double responsiveFontSize = screenWidth < 600 // typical tablet width
        ? baseFontSize
        : baseFontSize * 0.9; // increase for larger screens

    return Text(
      message,
      textAlign: TextAlign.center,
      style: TextStyle(
        fontSize: responsiveFontSize,
        fontWeight: FontWeight.w500,
      ),
    );
  }

  static promotionalTitle(context, String message) {
    return Text(
      message,
      style: TextStyle(
        fontSize: 16.sp,
        letterSpacing: 0.5,
        wordSpacing: 1,
      ),
    );
  }

  static productTitle(context, String message) {
    return Text(
      message,
      maxLines: 2,
      style: TextStyle(
        fontWeight: FontWeight.w600,
        fontSize: Responsive.isMobile(context)
            ? 17.sp // Font size for Desktop
            : (Responsive.isTablet(context)
                ? 15.0 // Font size for Tablet

                : 30.0), // Font size for Mobile
      ),
    );
  }

  static productTypeName(context, String message) {
    return Text(
      message,
      style: TextStyle(
          fontSize: 13.5.sp,
          color: Colors.black54,
          fontWeight: FontWeight.w500),
    );
  }

  //
  // static productDescription(context, String message){
  //   return Text(
  //     message,
  //     maxLines: 4,
  //     overflow: TextOverflow.ellipsis,
  //     style: TextStyle(fontSize: 12.sp,color: Colors.black.withOpacity(0.7),),
  //   );
  // }

  static Widget productDescription(context, String message) {
    return Text(
      message,
      maxLines: 4,
      overflow: TextOverflow.ellipsis,
      style: GoogleFonts.workSans(
        color: Colors.black.withOpacity(0.7),
        textStyle: TextStyle(
          fontSize: Responsive.isMobile(context)
              ? 12 // Font size for Desktop
              : (Responsive.isTablet(context)
                  ? 15.0 // Font size for Tablet

                  : 30.0), // Font size for Mobile
        ),
      ),
    );
  }

  static productTextStyle(context, String) {
    // Check screen width to determine if it's a tablet or mobile
    bool isTablet = MediaQuery.of(context).size.width > 600;

    // Return titleMedium for tablets, titleLarge for mobile
    return isTablet
        ? Theme.of(context).textTheme.titleMedium!
        : Theme.of(context).textTheme.titleLarge!;
  }

  static iconfavcor(context, String) {
    MediaQuery.of(context).size.width >= 600
        ? 27.0
        : 24.0; // Bigger icon size for tablets
  }

  static productPriceStyle(context, String) {
    // Check screen width to determine if it's a tablet or mobile
    bool isTablet = MediaQuery.of(context).size.width > 600;

    // Return titleMedium for tablets, titleLarge for mobile
    return isTablet
        ? Theme.of(context).textTheme.titleSmall!
        : Theme.of(context).textTheme.titleLarge!;
  }

  static Widget productPrice(BuildContext context, String? message) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize;

    if (screenWidth >= 1024) {
      // Desktop
      fontSize = MediaQuery.of(context).size.width * 0.017;
    } else if (screenWidth >= 600) {
      // Tablet
      fontSize = MediaQuery.of(context).size.width * 0.022;
    } else {
      // Mobile
      fontSize = MediaQuery.of(context).size.width * 0.034;
    }

    return Text(
      '₹${message ?? ''}',
      style: TextStyle(
        color: AppColors.primaryColor,
        fontSize: fontSize,
        fontWeight: FontWeight.w500,
      ),
    );
  }

  static addToCartTitles(context, String message, color) {
    double screenWidth = MediaQuery.of(context).size.width;

    // Define font size based on screen width
    double fontSize;
    if (screenWidth >= 1200) {
      // Desktop
      fontSize = 24.0;
    } else if (screenWidth >= 600) {
      // Tablet
      fontSize = 16.0;
    } else {
      // Mobile
      fontSize = 15.0;
    }

    return Text(
      message,
      maxLines: 1,
      style: TextStyle(
        fontSize: fontSize,
        fontWeight: FontWeight.w600,
        color: color,
      ),
    );
  }

  static contactUsTitle(BuildContext context, String message) {
    double screenWidth = MediaQuery.of(context).size.width;

    // Define font size based on screen width
    double fontSize;
    if (screenWidth >= 1200) {
      // Desktop
      fontSize = 24.0;
    } else if (screenWidth >= 600) {
      // Tablet
      fontSize = 20.0;
    } else {
      // Mobile
      fontSize = 16.0;
    }

    return Text(
      message,
      style: TextStyle(
        color: Colors.white,
        fontSize: fontSize,
        fontWeight: FontWeight.w500,
      ),
    );
  }

  static mrProfileHeading(context, String message) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize;
    if (screenWidth >= 1200) {
      // Desktop
      fontSize = 24.0;
    } else if (screenWidth >= 600) {
      // Tablet
      fontSize = 17.0;
    } else {
      // Mobile
      fontSize = 17.0;
    }

    return Text(
      message,
      style: TextStyle(
          fontSize: fontSize,
          color: AppColors.mrcontaonerheading,
          fontWeight: FontWeight.w500),
    );
  }

  static mrProfileTitles(context, String message) {
    return Text(
      message,
      maxLines: 1,
      style: TextStyle(
        fontSize: 16.sp,
        color: Colors.black,
      ),
    );
  }

  static customerName(BuildContext context, String? message) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize;
    // Set the font size based on screen width

    if (screenWidth >= 1200) {
      // Desktop
      fontSize = 24.0;
    } else if (screenWidth >= 600) {
      // Tablet
      fontSize = 17.0;
    } else {
      // Mobile
      fontSize = 20.5.sp;
    }

    return Text(
      message ?? 'Na',
      style: TextStyle(
        fontSize: fontSize, // Use responsive font size
        fontWeight: FontWeight.w600,
      ),
    );
  }

  static customerDetails(context, String? message) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize;
    if (screenWidth >= 1200) {
      // Desktop
      fontSize = 24.0;
    } else if (screenWidth >= 600) {
      // Tablet
      fontSize = 17.0;
    } else {
      // Mobile
      fontSize = 16.5.sp;
    }

    return Text(
      message ?? 'Na',
      style: TextStyle(
        color: Colors.black54,
        fontSize: fontSize,
      ),
    );
  }

  static Widget customerProductDetails(BuildContext context, String? message) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize;

    if (screenWidth >= 1024) {
      // Desktop
      fontSize = MediaQuery.of(context).size.width * 0.02; // 2% of screen width
    } else if (screenWidth >= 600) {
      // Tablet
      fontSize =
          MediaQuery.of(context).size.width * 0.023; // 2.3% of screen width
    } else {
      // Mobile
      fontSize = MediaQuery.of(context).size.width * 0.04; // 4% of screen width
    }

    return Text(
      message ?? 'Na',
      style: TextStyle(
        color: Colors.black,
        fontWeight: FontWeight.w500,
        fontSize: fontSize,
      ),
    );
  }

  static customerTimeDetails(BuildContext context, String? message) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize;
    if (screenWidth >= 1200) {
      // Desktop
      fontSize = 24.0;
    } else if (screenWidth >= 600) {
      // Tablet
      fontSize = 17.0;
    } else {
      // Mobile
      fontSize = 16.5.sp;
    }

    return Text(
      message ?? 'Na',
      style: TextStyle(
        color: Colors.black54,
        fontSize: fontSize,
      ),
    );
  }

  static customerStatus(BuildContext context, String? message, Color color) {
    // Get the device width
    double width = MediaQuery.of(context).size.width;

    // Determine font size based on screen width
    double fontSize;
    if (width >= 1200) {
      // Desktop
      fontSize = 22; // Larger font size for desktop
    } else if (width >= 600) {
      // Tablet
      fontSize = 19; // Medium font size for tablets
    } else {
      // Mobile
      fontSize = 16; // Smaller font size for mobile
    }

    return Text(
      message ?? 'Na',
      style: TextStyle(
        color: color,
        fontSize: fontSize,
        fontWeight: FontWeight.w400,
        letterSpacing: 1,
      ),
    );
  }
}

class AppBarUtils {
  static Widget appBarTitle(BuildContext context, String message) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize = screenWidth *
        (screenWidth >= 550
            ? 0.016
            : 0.05); // Adjusted multiplier for better scaling
    return Text(
      message,
      style: TextStyle(
        fontSize: fontSize,
        fontWeight: FontWeight.w600,
        letterSpacing: -0.2,
        color: Colors.black,
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:pharma_clients_app/utils/button.dart';
import 'package:pharma_clients_app/utils/profile_container.dart';
import 'package:pharma_clients_app/utils/utils.dart';
import 'package:pharma_clients_app/view_model/afterLogin_viewModel/afterLogin_viewModels.dart';
import 'package:pharma_clients_app/views/Screens/FAQsScreen.dart';
import 'package:pharma_clients_app/views/homescreen/about_company.dart';
import 'package:pharma_clients_app/views/Screens/bank_details.dart';
import 'package:pharma_clients_app/views/Screens/change_password.dart';
import 'package:pharma_clients_app/views/auth/login_screen.dart';
import 'package:pharma_clients_app/resources/constant_strings.dart';
import 'package:pharma_clients_app/utils/text_style.dart';
import 'package:pharma_clients_app/view_model/user_viewModel.dart';
import 'package:pharma_clients_app/views/editProfile&Firm/editFirmScreen.dart';
import 'package:pharma_clients_app/views/editProfile&Firm/editProfileScreen.dart';

class ProfileScreen extends StatefulWidget {
  ProfileScreen({
    this.value,
    this.isOwner,
    Key? key,
  }) : super(key: key);

  final dynamic value;
  final bool? isOwner;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  Widget? _currentOverlay;

  void _showOverlay(Widget widget) {
    setState(() {
      _currentOverlay = widget;
    });
  }

  void _hideOverlay() {
    setState(() {
      _currentOverlay = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final userPreference = Provider.of<UserViewModel>(context);
    final cart = Provider.of<Cart>(context);

    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        automaticallyImplyLeading: false,
        title: TextWithStyle.appBarTitle(context, ConstantStrings.profileheading),
        elevation: 0,
        toolbarHeight: 6.h,
      ),
      body: Row(
        children: [
          // Left side: Profile container list
          Visibility(
            visible: _currentOverlay == null,
            child: Expanded(
              flex: 1,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(height: 1.h),
                    ProfileContainer(
                      onPress: () => _showOverlay(EditProfileScreen()),
                      title: 'Edit Profile',
                      image: 'assets/images/svg/editProfile.svg',
                    ),
                    if (widget.isOwner == true || widget.isOwner == null) ...[
                      ProfileContainer(
                        onPress: () => _showOverlay(EditFirmScreen()),
                        title: 'Edit Firm',
                        image: 'assets/images/svg/bankdetails.svg',
                      ),
                      ProfileContainer(
                        onPress: () => _showOverlay(BankDetailsScreen()),
                        title: 'Bank Details',
                        image: 'assets/images/svg/bankdetails.svg',
                      ),
                    ],
                    ProfileContainer(
                      onPress: () => _showOverlay(ChangePasswordScreen()),
                      title: 'Change Password',
                      image: 'assets/images/svg/changePassword.svg',
                    ),
                    ProfileContainer(
                      onPress: () => _showOverlay(AboutCompnay(value: widget.value)),
                      title: 'About',
                      image: 'assets/images/svg/viewVisits.svg',
                    ),
                    ProfileContainer(
                      onPress: () => _showOverlay(FAQsScreen()),
                      title: 'FAQs',
                      image: 'assets/images/svg/faq.svg',
                    ),
                    SizedBox(height: 4.h),
                    Button(
                      title: 'Logout',
                      onPress: () async {
                        Utils.confirmationDialogue(
                          ConstantStrings.logoutMessage,
                          "Cancel",
                          "Ok",
                              () {
                            userPreference.remove();
                            cart.clear();
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) => LoginScreen(),
                              ),
                            );
                          },
                          context,
                        );
                      },
                      loading: false,
                    ),
                    SizedBox(height: 10.h),
                  ],
                ),
              ),
            ),
          ),
          // Right side: Detail view
          if (_currentOverlay != null)
            Expanded(
              flex: 2,
              child: Stack(
                children: [
                  _currentOverlay!,
                  Positioned(
                    top: 5,
                    left: 10,  // Moved the close icon to the left side
                    child: IconButton(
                      icon: Icon(Icons.arrow_back_ios),
                      onPressed: _hideOverlay,

                    ),

                  ),
                ],
              ),
            ),

        ],
      ),
    );
  }
}


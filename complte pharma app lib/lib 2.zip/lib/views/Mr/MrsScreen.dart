import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:pharma_clients_app/views/Mr/mrProfileScreen.dart';
import 'package:provider/provider.dart';
import '../../data/model/response_model/mrs/mrs_responseModel.dart';
import '../../data/response/status.dart';
import '../../resources/app_colors.dart';
import '../../resources/constant_imageString.dart';
import '../../resources/constant_strings.dart';
import '../../utils/Dialogue/error_dialogue.dart';
import '../../utils/text_style.dart';
import '../../view_model/afterLogin_viewModel/afterLogin_viewModels.dart';
import 'addMr_Screen.dart';

class MrsScreenProvider extends ChangeNotifier {
  Mrs? selectedMr;
  bool isMrProfileVisible = false;

  void selectMr(Mrs mr) {
    selectedMr = mr;
    isMrProfileVisible = true;
    notifyListeners();
  }

  void unselectMr() {
    selectedMr = null;
    isMrProfileVisible = false;
    notifyListeners();
  }
}

class MrsScreen extends StatelessWidget {
  const MrsScreen({Key? key}) : super(key: key);

  bool isTablet(BuildContext context) {
    return MediaQuery.of(context).size.shortestSide >= 600;
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final isTab = isTablet(context);

    return ChangeNotifierProvider(
      create: (context) => MrsScreenProvider(),
      child: Consumer<MrsScreenProvider>(
        builder: (context, screenProvider, _) {
          return Scaffold(
            appBar: AppBar(
              elevation: 0,
              title: Text(
                screenProvider.isMrProfileVisible ? "" : ConstantStrings.mrsheading,
              ),
              leading: screenProvider.isMrProfileVisible
                  ? IconButton(
                icon: Icon(Icons.arrow_back),
                onPressed: () => screenProvider.unselectMr(),
              )
                  : null,
            ),
            body: ChangeNotifierProvider<MrsViewModel>(
              create: (BuildContext context) => MrsViewModel()..fetchMrs(),
              child: Consumer<MrsViewModel>(
                builder: (context, value, _) {
                  switch (value.mrsList.status!) {
                    case Status.loading:
                      return Center(
                        child: LoadingAnimationWidget.discreteCircle(
                          color: AppColors.primaryColor,
                          size: isTab ? 30 : 40,
                        ),
                      );
                    case Status.error:
                      return ErrorDialogue(message: value.mrsList.message.toString());
                    case Status.completed:
                      if (screenProvider.isMrProfileVisible) {
                        return MrProfileScreen(profile: [screenProvider.selectedMr!]);
                      } else if (value.mrsList.data!.data!.isNotEmpty) {
                        return Stack(
                          children: [
                            buildMrList(value, context, isTab),
                            buildFloatingActionButton(context, isTab),
                          ],
                        );
                      } else {
                        return Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Image.asset(
                                ConstantImage.empty,
                                width: screenSize.width * (isTab ? 0.5 : 0.7),
                                fit: BoxFit.fill,
                              ),
                              SizedBox(height: isTab ? 12 : 16),
                              TextWithStyle.appBarTitle(context, ConstantStrings.emptyScreen),
                            ],
                          ),
                        );
                      }
                  }
                },
              ),
            ),
          );
        },
      ),
    );
  }

  Widget buildMrList(MrsViewModel value, BuildContext context, bool isTab) {
    return ListView.builder(
      itemCount: value.mrsList.data!.data!.length,
      scrollDirection: Axis.vertical,
      itemBuilder: (BuildContext context, int index) {
        return GestureDetector(
          onTap: () {
            Provider.of<MrsScreenProvider>(context, listen: false)
                .selectMr(value.mrsList.data!.data![index]);
          },
          child: Container(
            margin: EdgeInsets.symmetric(
              horizontal: isTab ? 6 : 8,
              vertical: isTab ? 6 : 8,
            ),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.all(Radius.circular(isTab ? 15 : 20)),
              boxShadow: [
                BoxShadow(
                  color: AppColors.primaryColor.withOpacity(0.1),
                  spreadRadius: 1,
                  blurRadius: 4,
                  offset: Offset(0, 0),
                ),
              ],
            ),
            child: Padding(
              padding: EdgeInsets.all(isTab ? 12 : 16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Stack(
                    alignment: Alignment.topLeft,
                    children: [
                      CircleAvatar(
                        radius: isTab ? 30 : 40,
                        backgroundColor: AppColors.primaryColor,
                        foregroundColor: Colors.brown.withOpacity(0.5),
                        child: Text(
                          value.mrsList.data!.data![index].name!
                              .substring(0, 1)
                              .toUpperCase(),
                          style: TextStyle(
                            fontSize: isTab ? 24 : 32,
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(left: isTab ? 2 : 3),
                        width: isTab ? 8 : 12,
                        height: isTab ? 8 : 12,
                        decoration: BoxDecoration(
                          color: value.mrsList.data!.data![index].active!
                              ? Colors.green
                              : Colors.red,
                          borderRadius: BorderRadius.circular(isTab ? 4 : 6),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(width: isTab ? 12 : 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          value.mrsList.data!.data![index].name!,
                          style: TextStyle(
                            fontSize: isTab ? 16 : 20,
                            fontWeight: FontWeight.w600,
                          ),
                          softWrap: true,
                          overflow: TextOverflow.visible,
                        ),
                        SizedBox(height: isTab ? 3 : 4),
                        Text(
                          value.mrsList.data!.data![index].email!,
                          style: TextStyle(
                            color: Colors.black54,
                            fontSize: isTab ? 14 : 17,
                          ),
                          softWrap: true,
                          overflow: TextOverflow.visible,
                        ),
                        SizedBox(height: isTab ? 6 : 8),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget buildFloatingActionButton(BuildContext context, bool isTab) {
    return Positioned(
      bottom: isTab ? 20 : 16,
      right: isTab ? 20 : 16,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(isTab ? 75.0 : 100.0),
        child: FloatingActionButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => AddMrScreen()),
            );
          },
          backgroundColor: AppColors.primaryColor,
          child: Icon(
            CupertinoIcons.person_add,
            color: Colors.white,
            size: isTab ? 24 : 32,
          ),
        ),
      ),
    );
  }
}
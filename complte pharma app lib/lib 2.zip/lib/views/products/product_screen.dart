import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:pharma_clients_app/data/model/response_model/division_responseModel.dart';
import 'package:pharma_clients_app/resources/app_colors.dart';
import 'package:pharma_clients_app/resources/constant_imageString.dart';
import 'package:pharma_clients_app/utils/text_style.dart';
import 'package:pharma_clients_app/views/homescreen/home_screen.dart';
import 'package:provider/provider.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import '../../data/model/response_model/products/product_reponse_model.dart';
import '../../data/response/status.dart';
import '../../resources/app_colors.dart';
import '../../resources/app_colors.dart';
import '../../resources/constant_strings.dart';
import '../../utils/Dialogue/error_dialogue.dart';
import 'product_list_widget.dart';
import '../../view_model/afterLogin_viewModel/afterLogin_viewModels.dart';
import '../../view_model/beforeLogin_viewModels/beforeLogin_viewModel.dart';

// ignore: must_be_immutable
class ProductScreen extends StatefulWidget {


  ProductScreen({required this.token, required this.isOwner, Key? key})
      : super(key: key);
  String? token;
  bool? isOwner;

  @override
  State<ProductScreen> createState() => _ProductScreenState();
}

class _ProductScreenState extends State<ProductScreen> {
  ProductViewModel products = ProductViewModel();
  GuestProductViewModel model = GuestProductViewModel();
  DivisionsViewModel division = DivisionsViewModel();
  TextEditingController controller = TextEditingController();
  FocusNode searchFocusNode = FocusNode();
  List<Products> value1 = [];
  List<String> product = [];



  final List<CheckBoxItems> items = [];

  @override
  void initState() {
    if (widget.token != null && widget.token!.isNotEmpty) {
      products.fetchProductsApi();
    } else {
      model.fetchProducts();
    }
    division.fetchDivisions();
    value1.clear();
    product.clear();
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    value1.clear();
    product.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;


    // Desktop: screenWidth > 1200, Tablet: 600 < screenWidth <= 1200, Mobile: screenWidth <= 600
    bool isDesktop = screenWidth > 1200;
    bool isTablet = screenWidth <= 1200 && screenWidth > 600;
    bool isMobile = screenWidth <= 600;
    return Scaffold(
      appBar: AppBar(
        title:
            TextWithStyle.appBarTitle(context, ConstantStrings.productScreen),
        automaticallyImplyLeading: true,
        actions: [
          IconButton(
              onPressed: () {
                showModalBottomSheet(
                  context: context,
                  shape: const RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(16.0)),
                  ),
                  backgroundColor: Colors.white,
                  isScrollControlled: true,
                  builder: (BuildContext context) {
                    return widget.token != null && widget.token!.isNotEmpty
                        ?
                    ChangeNotifierProvider.value(
                            value: products,
                            child: Consumer<ProductViewModel>(
                              builder: (context, value, _) {

                                return
                                  Container(
                                    height: screenHeight * 0.8,
                                    width: screenWidth,
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          padding: EdgeInsets.only(
                                            left: screenWidth * (isMobile ? 0.02 : isTablet ? 0.08 : 0.04),
                                            top: screenHeight * (isMobile ? 0.02 : isTablet ? 0.03 : 0.04),
                                          ),
                                          child: Text(
                                            'Filters',
                                            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                              fontSize: isMobile
                                                  ? 18
                                                  : isTablet
                                                  ? 20
                                                  : 22, // Adjust font size for mobile, tablet, and desktop
                                            ),
                                          ),
                                        ),
                                        Divider(color: Colors.black.withOpacity(0.1)),
                                        Expanded(
                                          child: Row(
                                            children: [
                                              // Adjust width logic for tablet to take full width
                                              Container(
                                                width: screenWidth * (isTablet ? 0.4 : isDesktop ? 0.3 : 0.4),
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.only(
                                                    topLeft: Radius.circular(
                                                      screenHeight * (isMobile ? 0.02 : 0.025),
                                                    ),
                                                  ),
                                                ),
                                                child: ListView(
                                                  children: value.filterOptions.keys.map((category) {
                                                    final bool isSelected = category == value.selectedCategory;
                                                    final selectedCount = value.getSelectedCount(category);
                                                    return GestureDetector(
                                                      onTap: () {
                                                        value.selectCategory(category);
                                                      },
                                                      child: Container(
                                                        color: isSelected
                                                            ? AppColors.primaryColor
                                                            : Colors.transparent,
                                                        child: ListTile(
                                                          title: Text(
                                                            '$category ${selectedCount == 0 ? '' : '($selectedCount)'}',
                                                            style: TextStyle(
                                                              fontSize: isMobile
                                                                  ? 16
                                                                  : isTablet
                                                                  ? 18
                                                                  : 20, // Adjust font size
                                                              color: isSelected ? Colors.white : Colors.black,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    );
                                                  }).toList(),
                                                ),
                                              ),
                                              VerticalDivider(
                                                color: Colors.black.withOpacity(0.1),
                                                width: 1,
                                              ),
                                              Expanded(
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Padding(
                                                      padding: EdgeInsets.symmetric(
                                                        horizontal: screenWidth * (isMobile ? 0.02 : 0.03),
                                                        vertical: screenHeight * (isMobile ? 0.01 : 0.02),
                                                      ),
                                                      child: TextField(
                                                        decoration: InputDecoration(
                                                          filled: true,
                                                          fillColor: Colors.blue.withOpacity(0.05),
                                                          enabledBorder: OutlineInputBorder(
                                                            borderRadius: BorderRadius.all(
                                                              Radius.circular(screenHeight *
                                                                  (isMobile ? 0.015 : 0.02)),
                                                            ),
                                                            borderSide: BorderSide(
                                                              color: Colors.grey[200]!,
                                                            ),
                                                          ),
                                                          focusedBorder: OutlineInputBorder(
                                                            borderRadius: BorderRadius.all(
                                                              Radius.circular(screenHeight *
                                                                  (isMobile ? 0.015 : 0.02)),
                                                            ),
                                                            borderSide: BorderSide(
                                                              color: Colors.grey[200]!,
                                                            ),
                                                          ),
                                                          contentPadding: EdgeInsets.all(screenHeight *
                                                              (isMobile ? 0.01 : 0.015)),
                                                          prefixIcon: Padding(
                                                            padding: EdgeInsets.symmetric(
                                                              horizontal:
                                                              screenWidth * (isMobile ? 0.02 : 0.03),
                                                            ),
                                                            child: Image.asset(
                                                              "assets/images/png/search.png",
                                                              width: screenHeight * (isMobile ? 0.02 : 0.025),
                                                            ),
                                                          ),
                                                          border: InputBorder.none,
                                                          hintText: "Search",
                                                          hintStyle: TextStyle(color: Colors.black38),
                                                        ),
                                                        onChanged: value.updateSearchText,
                                                      ),
                                                    ),
                                                    Expanded(
                                                      child: ListView(
                                                        padding: EdgeInsets.only(
                                                          left: screenWidth * (isMobile ? 0.02 : 0.03),
                                                        ),
                                                        children: value.getFilteredOptions().map((option) {
                                                          final isSelected = value.selectedFilters[
                                                          value.selectedCategory]
                                                              ?.contains(option) ==
                                                              true;
                                                          return Column(
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              FilterChip(
                                                                label: Text(option),
                                                                backgroundColor: Colors.white,
                                                                selectedColor: Colors.blue.withOpacity(0.05),
                                                                selected: isSelected,
                                                                onSelected: (_) => value.toggleFilterOption(
                                                                    value.selectedCategory, option),
                                                              ),
                                                            ],
                                                          );
                                                        }).toList(),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Divider(color: Colors.black.withOpacity(0.1)),
                                        Container(
                                          padding: EdgeInsets.only(
                                            bottom: screenHeight * (isMobile ? 0.03 : 0.04),
                                            right: screenWidth * (isMobile ? 0.02 : 0.03),
                                            left: screenWidth * (isMobile ? 0.02 : 0.03),
                                            top: screenHeight * (isMobile ? 0.005 : 0.01),
                                          ),
                                          color: Colors.white,
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              OutlinedButton(
                                                onPressed: value.clearFilters,
                                                style: OutlinedButton.styleFrom(
                                                  backgroundColor: Colors.white,
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius: BorderRadius.all(
                                                      Radius.circular(screenHeight *
                                                          (isMobile ? 0.04 : 0.05)),
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  padding: EdgeInsets.all(screenHeight *
                                                      (isMobile ? 0.015 : 0.02)),
                                                  child: Text(
                                                    'Clear',
                                                    style: TextStyle(
                                                      color: Colors.black,
                                                      fontSize: isMobile ? 16 : isTablet ? 18 : 20, // Font size
                                                      fontWeight: FontWeight.w400,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              ElevatedButton(
                                                onPressed: () {
                                                  products.applyFilters();
                                                  print('Selected Filters: ${value.selectedFilters}');
                                                  Navigator.of(context).pop();
                                                },
                                                style: ElevatedButton.styleFrom(
                                                  backgroundColor: AppColors.primaryColor,
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius: BorderRadius.all(
                                                      Radius.circular(screenHeight *
                                                          (isMobile ? 0.04 : 0.05)),
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  padding: EdgeInsets.all(screenHeight *
                                                      (isMobile ? 0.015 : 0.02)),
                                                  child: Text(
                                                    'Apply',
                                                    style: TextStyle(
                                                      color: Colors.white,
                                                      fontSize: isMobile ? 16 : isTablet ? 18 : 20, // Font size
                                                      fontWeight: FontWeight.w400,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  );

                              }
                            )   )
                        :
                    ChangeNotifierProvider.value(
                      value: model,
                      child: Consumer<GuestProductViewModel>(
                        builder: (context, value, _) {
                          // Get screen dimensions
                          double screenWidth = MediaQuery.of(context).size.width;
                          double screenHeight = MediaQuery.of(context).size.height;
                          bool isMobile = screenWidth <= 600; // Assuming mobile is <= 600px width
                          bool isTablet = screenWidth > 600 && screenWidth <= 1200; // Assuming tablet is between 601px and 1200px width
                          bool isDesktop = screenWidth > 1200; // Assuming desktop is > 1200px width

                          return Container(
                            height: screenHeight * 0.8,
                            width: screenWidth, // Take full width on both mobile and tablet
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  padding: EdgeInsets.only(
                                    left: screenWidth * (isMobile ? 0.02 : isTablet ? 0.08 : 0.04),
                                    top: screenHeight * (isMobile ? 0.02 : isTablet ? 0.03 : 0.04),
                                  ),
                                  child: Text(
                                    'Filters',
                                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                      fontSize: isMobile
                                          ? 18
                                          : isTablet
                                          ? 20
                                          : 22, // Adjust font size for mobile, tablet, and desktop
                                    ),
                                  ),
                                ),
                                Divider(color: Colors.black.withOpacity(0.1)),
                                Expanded(
                                  child: Row(
                                    children: [
                                      Container(
                                        width: screenWidth * (isMobile ? 1 : isTablet ? 0.4 : 0.3),
                                        // Full width on mobile, 40% on tablet, 30% on desktop
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(
                                              screenHeight * (isMobile ? 0.02 : isTablet ? 0.025 : 0.03),
                                            ),
                                          ),
                                        ),
                                        child: ListView(
                                          children: value.filterOptions.keys.map((category) {
                                            final bool isSelected = category == value.selectedCategory;
                                            final selectedCount = value.getSelectedCount(category);
                                            return GestureDetector(
                                              onTap: () {
                                                value.selectCategory(category);
                                              },
                                              child: Container(
                                                color: isSelected
                                                    ? AppColors.primaryColor
                                                    : Colors.transparent,
                                                child: ListTile(
                                                  title: Text(
                                                    '${category} ${selectedCount == 0 ? '' : '(${selectedCount})'}',
                                                    style: TextStyle(
                                                      fontSize: isMobile
                                                          ? 16
                                                          : isTablet
                                                          ? 18
                                                          : 20, // Adjust font size
                                                      color: isSelected ? Colors.white : Colors.black,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            );
                                          }).toList(),
                                        ),
                                      ),
                                      isMobile
                                          ? SizedBox() // Skip vertical divider on mobile
                                          : VerticalDivider(
                                        color: Colors.black.withOpacity(0.1),
                                        width: 1,
                                      ),
                                      Expanded(
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Padding(
                                              padding: EdgeInsets.symmetric(
                                                horizontal: screenWidth * (isMobile ? 0.02 : 0.03),
                                                vertical: screenHeight * (isMobile ? 0.01 : 0.02),
                                              ),
                                              child: TextField(
                                                decoration: InputDecoration(
                                                  filled: true,
                                                  fillColor: Colors.blue.withOpacity(0.05),
                                                  enabledBorder: OutlineInputBorder(
                                                    borderRadius: BorderRadius.all(
                                                      Radius.circular(screenHeight * (isMobile ? 0.015 : 0.02)),
                                                    ),
                                                    borderSide: BorderSide(
                                                      color: Colors.grey[200]!,
                                                    ),
                                                  ),
                                                  focusedBorder: OutlineInputBorder(
                                                    borderRadius: BorderRadius.all(
                                                      Radius.circular(screenHeight * (isMobile ? 0.015 : 0.02)),
                                                    ),
                                                    borderSide: BorderSide(
                                                      color: Colors.grey[200]!,
                                                    ),
                                                  ),
                                                  contentPadding: EdgeInsets.all(screenHeight * (isMobile ? 0.01 : 0.015)),
                                                  prefixIcon: Padding(
                                                    padding: EdgeInsets.symmetric(
                                                      horizontal: screenWidth * (isMobile ? 0.02 : 0.03),
                                                    ),
                                                    child: Image.asset(
                                                      "assets/images/png/search.png",
                                                      width: screenHeight * (isMobile ? 0.02 : 0.025),
                                                    ),
                                                  ),
                                                  border: InputBorder.none,
                                                  hintText: "Search",
                                                  hintStyle: TextStyle(color: Colors.black38),
                                                ),
                                                onChanged: value.updateSearchText,
                                              ),
                                            ),
                                            Expanded(
                                              child: ListView(
                                                padding: EdgeInsets.only(
                                                  left: screenWidth * (isMobile ? 0.02 : 0.03),
                                                ),
                                                children: value.getFilteredOptions().map((option) {
                                                  final isSelected = value.selectedFilters[value.selectedCategory]?.contains(option) == true;
                                                  return Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      FilterChip(
                                                        label: Text(option),
                                                        backgroundColor: Colors.white,
                                                        selectedColor: Colors.blue.withOpacity(0.05),
                                                        selected: isSelected,
                                                        onSelected: (_) => value.toggleFilterOption(value.selectedCategory, option),
                                                      ),
                                                    ],
                                                  );
                                                }).toList(),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Divider(color: Colors.black.withOpacity(0.1)),
                                Container(
                                  padding: EdgeInsets.only(
                                    bottom: screenHeight * (isMobile ? 0.03 : 0.04),
                                    right: screenWidth * (isMobile ? 0.02 : 0.03),
                                    left: screenWidth * (isMobile ? 0.02 : 0.03),
                                    top: screenHeight * (isMobile ? 0.005 : 0.01),
                                  ),
                                  color: Colors.white,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      OutlinedButton(
                                        onPressed: value.clearFilters,
                                        style: OutlinedButton.styleFrom(
                                          backgroundColor: Colors.white,
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.all(
                                              Radius.circular(screenHeight * (isMobile ? 0.04 : 0.05)),
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          padding: EdgeInsets.all(screenHeight * (isMobile ? 0.015 : 0.02)),
                                          child: Text(
                                            'Clear',
                                            style: TextStyle(
                                              color: Colors.black,
                                              fontSize: isMobile ? 16 : isTablet ? 18 : 20, // Font size
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                        ),
                                      ),
                                      ElevatedButton(
                                        onPressed: () {
                                          value.applyFilters();
                                          Navigator.of(context).pop();
                                        },
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: AppColors.primaryColor,
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.all(
                                              Radius.circular(screenHeight * (isMobile ? 0.04 : 0.05)),
                                            ),
                                          ),
                                        ),
                                        child: Container(
                                          padding: EdgeInsets.all(screenHeight * (isMobile ? 0.015 : 0.02)),
                                          child: Text(
                                            'Apply',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: isMobile ? 16 : isTablet ? 18 : 20, // Font size
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    );


                  },
                );
              },
            icon: Icon(
              CupertinoIcons.slider_horizontal_3,
              size:
              MediaQuery.of(context).size.width >= 1024
                  ? MediaQuery.of(context).size.width * 0.05 // Desktop (5% of width)
                  : MediaQuery.of(context).size.width >= 600
                  ? MediaQuery.of(context).size.width * 0.04 // Tablet (6% of width)
                  : MediaQuery.of(context).size.width * 0.07, // Mobile (7% of width)
            ),



          ),
          SizedBox(
            width: 3.w,
          )
        ],
      ),


      body: widget.token != null && widget.token!.isNotEmpty
          ? ChangeNotifierProvider<ProductViewModel>(
              create: (BuildContext context) => products,
              child: Consumer<ProductViewModel>(builder: (context, value, _) {
                switch (value.productlist.status!) {
                  case Status.loading:
                    return Container(
                      height: MediaQuery.of(context).size.height,
                      width: MediaQuery.of(context).size.width,
                      color: AppColors.backgroundColor,
                      child: Center(
                          child: LoadingAnimationWidget.discreteCircle(
                              color: AppColors.primaryColor, size: 40)),
                    );
                  case Status.error:
                    return Center(
                      child: ErrorDialogue(
                          message: value.productlist.message.toString()),
                    );
                  case Status.completed:
                    return Column(

                      children: [
                        Container(
                            margin: EdgeInsets.only(
                              left: 3.w, right: 3.w, bottom: 2.w),
                          child: TextFormField(
                            style: TextStyle(fontSize: 16.sp),
                            controller: controller,
                            onChanged: (value) {
                              products.updateSearchText(value.toLowerCase());
                            },
                            decoration: InputDecoration(
                                filled: true,
                                fillColor:
                                    AppColors.primaryColor.withOpacity(0.05),
                                enabledBorder: OutlineInputBorder(
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(15)),
                                    borderSide: BorderSide(
                                        color: AppColors.backgroundColor)),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(15)),
                                    borderSide: BorderSide(
                                        color: AppColors.backgroundColor)),
                                contentPadding: EdgeInsets.all(2.h),
                                prefixIcon: Padding(
                                  padding: EdgeInsets.symmetric(
                                    horizontal: MediaQuery.of(context).size.width * 0.02, // 2% of screen width for left and right padding
                                  ),
                                  child: Image.asset(
                                    "assets/images/png/search.png",
                                    width: MediaQuery.of(context).size.height * (MediaQuery.of(context).size.width >= 600 ? 0.036 : 0.025), // Larger icon size for tablets
                                  ),
                                ),

                                border: InputBorder.none,
                                hintText: "Search",
                                hintStyle:
                                    const TextStyle(color: Colors.black38)),
                          ),
                        ),
                        Expanded(
                            child: ProductList(
                          product: value.products,
                          token: widget.token,
                        )),


                        Container(
                          padding: EdgeInsets.only(
                              left: 5.w, bottom: 3.w, top: 2.w, right: 5.w),
                          color: Colors.white,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Consumer<Cart>(
                                builder: (BuildContext context, value,
                                    Widget? child) {
                                  return TextWithStyle.appToCart(
                                      context, '${value.items.length} Items',);
                                },
                              ),
                              ElevatedButton(
                                onPressed: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => HomeScreen(
                                                token: widget.token,
                                                isOwner: widget.isOwner,
                                                initialTabIndex: 2,
                                              )));
                                },
                style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryColor,
                minimumSize: Size(
                MediaQuery.of(context).size.width >= 600
                ? MediaQuery.of(context).size.width / 6
                    : MediaQuery.of(context).size.width / 3,

                MediaQuery.of(context).size.height >= 600
                ? MediaQuery.of(context).size.height / 30
                    : MediaQuery.of(context).size.height / 18,
                ),
                shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                Radius.circular(4.h),
                ),
                ),
                ),

                child: Text('Next',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 15.sp,
                                        fontWeight: FontWeight.w400)),
                              )
                            ],
                          ),
                        )
                      ],
                    );
                }
              }),
            )








          : ChangeNotifierProvider<GuestProductViewModel>(
              create: (BuildContext context) => model,
              child: Consumer<GuestProductViewModel>(
                builder: (context, value, _) {
                  switch (value.productlist.status!) {
                    case Status.loading:
                      return Container(
                        height: MediaQuery.of(context).size.height,
                        width: MediaQuery.of(context).size.width,
                        color: AppColors.backgroundColor,
                        child: Center(
                            child: LoadingAnimationWidget.discreteCircle(
                                color: AppColors.primaryColor, size: 40)),
                      );
                    case Status.error:
                      return Center(
                        child: Text(value.productlist.message.toString()),
                      );
                    case Status.completed:
                      return
                        Column(
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    // Use responsive margin based on screen width
                                    margin: EdgeInsets.only(
                                      left: MediaQuery.of(context).size.width * 0.03,
                                      right: MediaQuery.of(context).size.width * 0.03,
                                      bottom: MediaQuery.of(context).size.width * 0.02,
                                    ),
                                    child: TextFormField(
                                      // Use responsive font size based on screen width
                                      style: TextStyle(
                                        fontSize: MediaQuery.of(context).size.width * 0.04, // Responsive font size
                                      ),
                                      controller: controller,
                                      onChanged: (value) {
                                        model.updateSearchText(value.toLowerCase());
                                      },
                                      decoration: InputDecoration(
                                        filled: true,
                                        fillColor: AppColors.primaryColor.withOpacity(0.05),
                                        enabledBorder: OutlineInputBorder(
                                          borderRadius: BorderRadius.all(Radius.circular(15)),
                                          borderSide: BorderSide(color: AppColors.backgroundColor),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          borderRadius: BorderRadius.all(Radius.circular(15)),
                                          borderSide: BorderSide(color: AppColors.backgroundColor),
                                        ),
                                        // Use responsive padding based on screen height
                                        contentPadding: EdgeInsets.all(
                                          MediaQuery.of(context).size.height * 0.02,
                                        ),
                                        prefixIcon: Padding(
                                          // Responsive padding for the prefix icon
                                          padding: EdgeInsets.symmetric(
                                            horizontal: MediaQuery.of(context).size.width * 0.02,
                                          ),
                                          child: Image.asset(
                                            ConstantImage.search,
                                            // Responsive width for the image
                                            width: MediaQuery.of(context).size.height * 0.03,
                                          ),
                                        ),
                                        border: InputBorder.none,
                                        hintText: "Search",
                                        hintStyle: TextStyle(color: Colors.black38),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            // Expanded widget for ProductList remains the same
                            Expanded(
                              child: ProductList(
                                product: value.products,
                                token: widget.token,
                              ),
                            ),
                          ],
                        );

                  }
                },
              ),
            ),
    );
  }
}





























class CheckBoxItems {
  bool selected;
  String name;

  CheckBoxItems({
    this.selected = false,
    required this.name,
  });
}

class ProductByDivision extends ChangeNotifier {
  final List<Data> _selectedDivisions = [];

  List<Data> get selectedDivisions => _selectedDivisions;

  void addDivision(Data division) {
    _selectedDivisions.add(division);
    notifyListeners();
  }

  void removeDivision(Data division) {
    _selectedDivisions.remove(division);
    notifyListeners();
  }

  bool isSelected(Data division) {
    return _selectedDivisions.contains(division);
  }
}

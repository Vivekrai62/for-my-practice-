// import 'package:flutter/material.dart';
// import 'package:pharma_clients_app/views/homescreen/home_screen.dart';
//
// import 'ResponsiveUtils.dart';
//
//
// class MainScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     // It provide us the width and height
//     Size _size = MediaQuery.of(context).size;
//     return Scaffold(
//         body:
//         Responsive(
//           mobile: HomeScreen(token: '',),
//           tablet: DashboardScreen(token: '', aboutCompany: [],),
//           desktop: DashboardScreen(token: '', aboutCompany: [],),
//         )
//     );
//   }
// }


import 'package:flutter/material.dart';
import 'package:pharma_clients_app/views/homescreen/home_screen.dart';

import 'ResponsiveUtils.dart'; // Adjust the import path if necessary

class MainScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Responsive(
        mobile: HomeScreen(token: ''),
        tablet: DashboardScreen(token: '', aboutCompany: []),
        desktop: DashboardScreen(token: '', aboutCompany: []),
      ),
    );
  }
}

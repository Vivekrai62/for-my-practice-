import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import '../resources/app_colors.dart';
import '../resources/constant_strings.dart';
import 'Responsive/ResponsiveUtils.dart';

class TextWithStyle{

  static appToCart(context, String message){
    return Text(message,
      style: TextStyle(
        fontSize: 15.sp,
        fontWeight: FontWeight.w500,
        color: AppColors.primaryColor,
      ),);
  }

  static appBarTitle(BuildContext context, String message) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize;
    FontWeight fontWeight;

    if (screenWidth >= 1024) {
      // Desktop
      fontSize = screenWidth * 0.022; // Scales font size based on screen width
      fontWeight = FontWeight.w600;   // Heavier font weight for desktop
    } else if (screenWidth >= 600) {
      // Tablet
      fontSize = screenWidth * 0.023; // Scales font size based on screen width
      fontWeight = FontWeight.w500;   // Medium weight for tablet
    } else {
      // Mobile
      fontSize = screenWidth * 0.045; // Scales font size based on screen width
      fontWeight = FontWeight.w600;   // Lighter weight for mobile
    }

    return Text(

      message,
      style: TextStyle(
        fontSize: fontSize,
        fontWeight: fontWeight,
        letterSpacing: -0.2,
        color: Colors.black,
      ),

    );

  }
  static app_bar_Icon(context, String message){
    return Text(message,
      style: TextStyle(
        fontSize: 17.sp,
        fontWeight: FontWeight.w500,
        color: AppColors.primaryColor,
      ),);
  }



  Widget app_bar_SizedBox(context, String message){
    return
      Row(children: [
        SizedBox(
          width: MediaQuery.of(context).size.width < 600
              ? MediaQuery.of(context).size.width * 0.3  // 30% width for mobile devices
              : MediaQuery.of(context).size.width * 0.05,
          // 15% width for tablets
        ),



      ],);

  }


  static containerTitle(BuildContext context, String message) {
    double screenWidth = MediaQuery.of(context).size.width;

    double responsiveFontSize;
    if (screenWidth >= 1200) {
      // Desktop screen
      responsiveFontSize = 22; // Larger font size for desktop
    } else if (screenWidth >= 600) {
      // Tablet screen
      // responsiveFontSize = 22; // Medium font size for tablet
      responsiveFontSize = 17; // Medium font size for tablet
    } else {
      // Mobile screen
      responsiveFontSize = 16; // Smaller font size for mobile
    }

    return Text(
      message,
      style: TextStyle(
        fontSize: responsiveFontSize,
        color: Colors.black,
        fontWeight: FontWeight.w400,
      ),
    );
  }


  static Widget  welcomeTitle(BuildContext context, String message) {
    return Text(
      message,
      style: GoogleFonts.workSans(
        color: Colors.white,
        textStyle: TextStyle(
          fontSize: Responsive.isDesktop(context)
              ? 24.0 // Font size for Desktop2
              : (Responsive.isTablet(context)
              ? 50.0 // Font size for Tablet
              : 30.0), // Font size for Mobile
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  static Widget Register_As_a_Distributors(BuildContext context, String message) {
    return Text(
      message,
      style: GoogleFonts.workSans(
        color: AppColors.primaryColor,
        textStyle: TextStyle(

          fontSize: Responsive.isDesktop(context)
              ? 24.0 // Desktop
              : (Responsive.isTablet(context)
              ? 38.0 // Tablet
              : 20.0), // Mobile


          fontWeight: Responsive.isDesktop(context)
              ? FontWeight.w600 // Font weight for Desktop
              : (Responsive.isTablet(context)
              ? FontWeight.w600 // Font weight for Tablet
              : FontWeight.w600), // Font weight for Mobile
        ),
      ),
    );
  }



  static mainIconTitle(context, String message,color){
    return Text(
        message,
      textAlign: TextAlign.center,
      style: TextStyle(
        fontSize: Responsive.isDesktop(context)
            ? 24.0 // Font size for Desktop
            : (Responsive.isTablet(context)
            ? 14.0 // Font size for Tablet
            : 14.0), // Font size for Mobile
        color: color,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  static pngIconTitle(context, String message){
    return Text(
        message,
      textAlign: TextAlign.center,
      style: TextStyle(
        fontSize: 14.2.sp,
        fontWeight: FontWeight.w500
      ),
    );
  }

  static promotionalTitle (context, String message){
    return Text(
      message,
      style: TextStyle(
          fontSize: 16.sp,
          letterSpacing: 0.5,
          wordSpacing: 1,
      ),
    );
  }

  static productTitle(context, String message){
    return Text(
      message,
      maxLines: 2,

    style: TextStyle(
        fontWeight: FontWeight.w600,
    fontSize: Responsive.isMobile(context)
    ? 17.sp // Font size for Desktop
        : (Responsive.isTablet(context)
    ? 15.0 // Font size for Tablet

        : 30.0), // Font size for Mobile

    ),
    );

  }

  static productTypeName(context, String message){
    return Text(
      message,
      style: TextStyle(
          fontSize: 13.5.sp,
        color: Colors.black54,
        fontWeight: FontWeight.w500
      ),
    );
  }
  //
  // static productDescription(context, String message){
  //   return Text(
  //     message,
  //     maxLines: 4,
  //     overflow: TextOverflow.ellipsis,
  //     style: TextStyle(fontSize: 12.sp,color: Colors.black.withOpacity(0.7),),
  //   );
  // }



  static Widget  productDescription(context, String message) {
    return Text(
      message,
      maxLines: 4,
      overflow: TextOverflow.ellipsis,
      style: GoogleFonts.workSans(
        color: Colors.black.withOpacity(0.7),
        textStyle:
        TextStyle(
          fontSize: Responsive.isMobile(context)
              ? 12 // Font size for Desktop
              : (Responsive.isTablet(context)
              ? 15.0 // Font size for Tablet

              : 30.0), // Font size for Mobile

        ),
      ),


    );
  }










  static productTextStyle( context ,String) {
    // Check screen width to determine if it's a tablet or mobile
    bool isTablet = MediaQuery.of(context).size.width > 600;

    // Return titleMedium for tablets, titleLarge for mobile
    return isTablet
        ? Theme.of(context).textTheme.titleMedium!
        : Theme.of(context).textTheme.titleLarge!;


  }

static iconfavcor(context,String){
  MediaQuery.of(context).size.width >= 600 ? 27.0 : 24.0; // Bigger icon size for tablets
}

  static productPriceStyle( context ,String) {
    // Check screen width to determine if it's a tablet or mobile
    bool isTablet = MediaQuery.of(context).size.width > 600;

    // Return titleMedium for tablets, titleLarge for mobile
    return isTablet
        ? Theme.of(context).textTheme.titleSmall!
        : Theme.of(context).textTheme.titleLarge!;


  }

  static productPrice(context, String? message){
    return Text(
      '₹$message',
      style: TextStyle(
          color: AppColors.primaryColor,
          fontSize: 17.sp,
          fontWeight: FontWeight.w500),
    );
  }

  static addToCartTitles(context, String message,color){

    double screenWidth = MediaQuery.of(context).size.width;

    // Define font size based on screen width
    double fontSize;
    if (screenWidth >= 1200) {
      // Desktop
      fontSize = 24.0;
    } else if (screenWidth >= 600) {
      // Tablet
      fontSize = 16.0;
    } else {
      // Mobile
      fontSize = 15.0;
    }

    return Text(message,
      maxLines: 1,
      style: TextStyle(
        fontSize: fontSize,
        fontWeight: FontWeight.w600,
        color: color,
      ),);
  }

  static contactUsTitle(BuildContext context, String message) {
    double screenWidth = MediaQuery.of(context).size.width;

    // Define font size based on screen width
    double fontSize;
    if (screenWidth >= 1200) {
      // Desktop
      fontSize = 24.0;
    } else if (screenWidth >= 600) {
      // Tablet
      fontSize = 20.0;
    } else {
      // Mobile
      fontSize = 16.0;
    }

    return Text(
      message,
      style: TextStyle(
        color: Colors.white,
        fontSize: fontSize,
        fontWeight: FontWeight.w500,
      ),
    );
  }

  static mrProfileHeading(context, String message){
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize;
    if (screenWidth >= 1200) {
      // Desktop
      fontSize = 24.0;
    } else if (screenWidth >= 600) {
      // Tablet
      fontSize = 17.0;
    } else {
      // Mobile
      fontSize = 17.0;
    }

    return Text(message,
      style: TextStyle(
        fontSize: fontSize,
        color: AppColors.mrcontaonerheading,
        fontWeight: FontWeight.w500
      ),);
  }

  static mrProfileTitles(context, String message){
    return Text(message,
      maxLines: 1,
      style: TextStyle(
          fontSize: 16.sp,
          color: Colors.black,
      ),);
  }

  static customerName(BuildContext context, String? message) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize;
    // Set the font size based on screen width

    if (screenWidth >= 1200) {
      // Desktop
      fontSize = 24.0;
    } else if (screenWidth >= 600) {
      // Tablet
      fontSize = 17.0;
    } else {
      // Mobile
      fontSize = 20.5.sp;
    }

    return Text(
      message ?? 'Na',
      style: TextStyle(
       fontSize: fontSize, // Use responsive font size
        fontWeight: FontWeight.w600,
      ),
    );
  }




  static customerDetails(context ,String? message){
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize;
    if (screenWidth >= 1200) {
      // Desktop
      fontSize = 24.0;
    } else if (screenWidth >= 600) {
      // Tablet
      fontSize = 17.0;
    } else {
      // Mobile
      fontSize = 16.5.sp;
    }

    return Text(
      message ?? 'Na',
      style: TextStyle(
          color: Colors.black54,
          fontSize: fontSize,

      ),);
  }

  static customerProductDetails(context ,String? message){
    return Text(
      message ?? 'Na',
      style: TextStyle(
        color: Colors.black,
        fontWeight: FontWeight.w500,
        fontSize: 16.5.sp,
      ),
    );
  }

  static customerTimeDetails(BuildContext context, String? message) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize;
    if (screenWidth >= 1200) {
      // Desktop
      fontSize = 24.0;
    } else if (screenWidth >= 600) {
      // Tablet
      fontSize = 17.0;
    } else {
      // Mobile
      fontSize = 16.5.sp;
    }

    return Text(
      message ?? 'Na',
      style: TextStyle(
        color: Colors.black54,
        fontSize: fontSize,

      ),);
  }


  static customerStatus(BuildContext context, String? message, Color color) {
    // Get the device width
    double width = MediaQuery.of(context).size.width;

    // Determine font size based on screen width
    double fontSize;
    if (width >= 1200) {
      // Desktop
      fontSize = 22; // Larger font size for desktop

    } else if (width >= 600) {
      // Tablet
      fontSize = 19; // Medium font size for tablets

    } else {
      // Mobile
      fontSize = 16; // Smaller font size for mobile
    }

    return Text(
      message ?? 'Na',
      style: TextStyle(
        color: color,
        fontSize: fontSize,
        fontWeight: FontWeight.w400,
        letterSpacing: 1,
      ),
    );
  }

}



class AppBarUtils {
  static Widget appBarTitle(BuildContext context, String message) {
    double fontSize;

    if (Responsive.isDesktop(context)) {
      fontSize = 25.0;
    } else if (Responsive.isTablet(context)) {
      fontSize = 39; // Adjusted for consistency
    } else {
      fontSize = 19.0;
    }

    return Text(
      message,
      style: TextStyle(
        fontSize: fontSize,
        fontWeight: FontWeight.w600,
        letterSpacing: -0.2,
        color: Colors.black,
      ),
    );
  }
}








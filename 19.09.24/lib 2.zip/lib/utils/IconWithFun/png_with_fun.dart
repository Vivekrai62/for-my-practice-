import 'package:flutter/material.dart';
import 'package:pharma_clients_app/utils/text_style.dart';

// ignore: must_be_immutable
class PngIconsWithFun extends StatelessWidget {
  PngIconsWithFun({
    Key? key,
    this.image,
    this.onPress,
    this.title,
  }) : super(key: key);

  dynamic onPress;
  dynamic image;
  dynamic title;

  @override
  Widget build(BuildContext context) {
    // Determine the icon size and spacing based on the screen size
    double iconSize;
    double spacing;

    if (MediaQuery.of(context).size.width >= 1200) {
      // Desktop
      iconSize = 65.0;
      spacing = 20.0;
    } else if (MediaQuery.of(context).size.width >= 600 && MediaQuery.of(context).size.width < 1200) {
      // Tablet
      iconSize = 22.0;
      spacing = 15.0;
    } else {
      // Mobile
      iconSize = 40.0;
      spacing = 10.0;
    }

    return InkWell(
      onTap: onPress,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.asset(
            image,
            height: iconSize, // Set the icon size based on device type
          ),
          SizedBox(
            height: spacing, // Adjust the space between the icon and text
          ),
          title != null
              ? TextWithStyle.pngIconTitle(context, title)
              : Container(),
        ],
      ),
    );
  }
}

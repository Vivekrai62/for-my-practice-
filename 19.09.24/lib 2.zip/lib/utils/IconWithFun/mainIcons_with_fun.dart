import 'package:flutter/material.dart';
import 'package:pharma_clients_app/utils/text_style.dart';

import '../Responsive/ResponsiveUtils.dart';

// ignore: must_be_immutable
class MainIconsWithFun extends StatelessWidget {
  MainIconsWithFun({
    Key? key,
    this.image,
    this.onPress,
    @required this.title,
  }) : super(key: key);

  dynamic onPress;
  dynamic image;
  dynamic title;

  @override
  Widget build(BuildContext context) {
    // Determine the icon size and spacing based on the screen size
    double iconSize;
    double spacing;

    if (Responsive.isDesktop(context)) {
      iconSize = 80.0; // Size for desktop
      spacing = 20.0; // Spacing for desktop
    } else if (Responsive.isTablet(context)) {
      iconSize = 22.0; // Size for tablet
      spacing = 15.0; // Spacing for tablet
    } else {
      iconSize = 40.0; // Size for mobile
      spacing = 10.0; // Spacing for mobile
    }

    return InkWell(
      onTap: onPress,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.asset(
            image,
            height: iconSize, // Set the icon size based on device type
          ),
          SizedBox(
            height: spacing, // Adjust the space between the icon and text
          ),
          title != null
              ? TextWithStyle.mainIconTitle(context, title, Colors.black)
              : Container(),
        ],
      ),
    );
  }
}

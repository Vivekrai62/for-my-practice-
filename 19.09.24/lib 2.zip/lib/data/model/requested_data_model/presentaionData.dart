import 'package:pharma_clients_app/data/model/response_model/visual_aids_response_model.dart';

class PresentationData {
  final String name;
  final List<dynamic> images;

  PresentationData({required this.name, required this.images});

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'images': images,
    };
  }

  static PresentationData fromMap(Map<String, dynamic> map) {
    return PresentationData(
      name: map['name'],
      images: List<dynamic>.from(map['images'] ?? []),
    );
  }
}
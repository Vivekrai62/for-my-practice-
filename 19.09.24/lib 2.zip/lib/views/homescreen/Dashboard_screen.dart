//
//
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:loading_animation_widget/loading_animation_widget.dart';
// import 'package:pharma_clients_app/views/homescreen/promotional.dart';
// import 'package:pharma_clients_app/views/homescreen/selfAnalysisScreen.dart';
// import 'package:pharma_clients_app/views/homescreen/visual_aids_screen.dart';
// import 'package:provider/provider.dart';
// import 'package:share_plus/share_plus.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// import '../../data/model/response_model/about_company/about_company_response_model.dart';
// import '../../resources/app_colors.dart';
// import '../../resources/constant_strings.dart';
// import '../../utils/Dialogue/error_dialogue.dart';
// import '../../utils/IconWithFun/mainIcons_with_fun.dart';
// import '../../utils/IconWithFun/png_with_fun.dart';
// import '../../utils/Responsive/ResponsiveUtils.dart';
// import '../../utils/scroll_state/scroll_state.dart';
// import '../../utils/slider/Slider.dart';
// import '../../utils/text_style.dart';
// import '../../view_model/afterLogin_viewModel/afterLogin_viewModels.dart';
// import '../../view_model/beforeLogin_viewModels/beforeLogin_viewModel.dart';
// import '../Mr/MrsScreen.dart';
// import '../Screens/calculator.dart';
// import '../addScreen/AddScreen.dart';
// import '../auth/login_screen.dart';
// import '../customer/customersOrderScreen.dart';
// import '../presentation/presentaionListScreen.dart';
// import '../products/favouriteScreen.dart';
// import '../products/new_launched.dart';
// import '../products/product_screen.dart';
// import '../products/upcoming_products.dart';
// import '../visits/visits_screen.dart';
// import 'NotificationScreen.dart';
// import 'divisons_screen.dart';
// import 'enquiry_screen.dart';
// import 'myOrderScreen.dart';
// import 'offer_screen.dart';
//
// class DashboardScreen extends StatefulWidget {
//   final String? token;
//   final bool? isOwner;
//   final List<AboutCompany> aboutCompany;
//
//   const DashboardScreen(
//       {Key? key, this.token, this.isOwner, required this.aboutCompany})
//       : super(key: key);
//
//   @override
//   _DashboardScreenState createState() => _DashboardScreenState();
// }
//
// class _DashboardScreenState extends State<DashboardScreen> {
//
//   Widget? _currentOverlay;
//   void _showOverlay(Widget widget) {
//     if (Responsive.isTablet(context)) {
//       if (_currentOverlay != widget) {
//         setState(() {
//           _currentOverlay = widget;
//         });
//       }
//     } else {
//       Navigator.push(
//         context,
//         MaterialPageRoute(builder: (context) => widget),
//       );
//     }
//   }
//
//   void _hideOverlay() {
//     setState(() {
//       _currentOverlay = null;
//     });
//   }
//
//
//
//   AboutCompanyViewModel model = AboutCompanyViewModel();
//   GuestDbCountViewModel dbcount = GuestDbCountViewModel();
//   DbCountViewModel count = DbCountViewModel();
//   String? userName;
//   final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
//
//   @override
//   void initState() {
//     super.initState();
//     getCount();
//     getUserInfo();
//   }
//
//   Future<void> getCount() async {
//     if (widget.token != null && widget.token!.isNotEmpty) {
//       await count.fetchCountApi(context);
//       getData();
//     } else {
//       await dbcount.fetchDbCountApi();
//     }
//   }
//
//   Future<void> getData() async {
//     await model.fetchAboutCompany();
//   }
//
//   Future<void> getUserInfo() async {
//     final SharedPreferences sp = await SharedPreferences.getInstance();
//     userName = sp.getString('name');
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return widget.token != null && widget.token!.isNotEmpty
//         ? ChangeNotifierProvider<DbCountViewModel>(
//       create: (BuildContext context) => count,
//       child: Consumer<DbCountViewModel>(
//         builder: (context, val, _) {
//           return val.loading == false
//               ? buildDashboard(val)
//               : buildLoadingScreen(context);
//         },
//       ),
//     )
//         : ChangeNotifierProvider<GuestDbCountViewModel>(
//       create: (BuildContext context) => dbcount,
//       child: Consumer<GuestDbCountViewModel>(
//         builder: (context, val, _) {
//           return val.loading == false
//               ? buildDashboard(val)
//               : buildLoadingScreen(context);
//         },
//       ),
//     );
//   }
//
//   Widget buildDashboard(val) {
//     return Scaffold(
//       key: _scaffoldKey,
//       appBar: buildAppBar(),
//       body:
//       RefreshIndicator(
//         onRefresh: getCount,
//         child:
//         Responsive(
//           mobile: buildMobileLayout(dynamic, val),
//           tablet: buildTabletLayout(val),
//           desktop: buildDesktopLayout(val),
//         ),
//       ),
//       floatingActionButton: buildFloatingActionButton(),
//     );
//   }
//
//   AppBar buildAppBar() {
//     return AppBar(
//       // toolbarHeight: Responsive.isTablet(context) ? 40 : 56,
//       toolbarHeight: Responsive.isMobile(context) ? 36 : 56,
//       automaticallyImplyLeading: false,
//       elevation: 0,
//       title:
//       Column(
//         children: [
//           widget.token == null
//               ? AppBarUtils.appBarTitle(
//               context, ConstantStrings.dashboardScreen)
//               : Column(
//             mainAxisAlignment: MainAxisAlignment.start,
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(
//                 'Hi,',
//                 style: TextStyle(
//                   color: Colors.black54,
//                   fontSize: Responsive.isDesktop(context)
//                       ? MediaQuery.of(context).size.width * 0.05 // Responsive for Desktop
//                       : (Responsive.isTablet(context)
//                       ? MediaQuery.of(context).size.width * 0.025 // Responsive for Tablet
//                       : MediaQuery.of(context).size.width * 0.035), // Responsive for Mobile
//                 ),
//               ),
//               const SizedBox(width: 8),
//               Text(
//                 "${userName}",
//                 style: TextStyle(
//                   color: Colors.black,
//                   fontSize: Responsive.isMobile(context)
//                       ? MediaQuery.of(context).size.width * 0.04 // Responsive for Mobile
//                       : (Responsive.isTablet(context)
//                       ? MediaQuery.of(context).size.width * 0.03 // Responsive for Tablet
//                       : MediaQuery.of(context).size.width * 0.06), // Responsive for Desktop
//                   fontWeight: FontWeight.w600,
//                 ),
//               ),
//             ],
//           ),
//         ],
//       ),
//
//       actions: [
//
//         IconButton(
//           onPressed: () {
//             Navigator.push(
//                 context,
//                 MaterialPageRoute(
//                     builder: (context) => const NotificationScreen()));
//           },
//           icon: Image.asset(
//             'assets/images/png/notification.png',
//             // Adjust the width based on the device type
//             width: Responsive.isDesktop(context)
//                 ? 60.0 // Width for Desktop
//                 : (Responsive.isTablet(context)
//                 ? 22 // Width for Tablet
//                 : 25.0), // Width for Mobile
//           ),
//         ),
//         SizedBox(
//           width: Responsive.isTablet(context)
//               ? 30
//               : (Responsive.isDesktop(context) ? 30 : 10),
//         ),
//         widget.token == null
//             ? IconButton(
//           onPressed: () {
//             Navigator.push(context,
//                 MaterialPageRoute(builder: (context) => LoginScreen()));
//           },
//           icon: Image.asset(
//             'assets/images/png/profile.png',
//             // Adjust the width based on the device type
//             width: Responsive.isDesktop(context)
//                 ? 60.0 // Width for Desktop
//                 : (Responsive.isTablet(context)
//                 ? 45.0 // Width for Tablet
//                 : 25.0), // Width for Mobile
//           ),
//         )
//             : Container(),
//         SizedBox(
//           width: Responsive.isDesktop(context)
//               ? 30
//               : (Responsive.isTablet(context) ? 30 : 10),
//         )
//       ],
//     );
//   }
//
//   Widget buildMobileLayout(dynamic value, val) {
//     return SingleChildScrollView(
//       child: Column(
//         children: [
//           buildSlider(),
//           buildCategories(val),
//           buildGridItems(val),
//           builderImage(value), // Correctly using the function
//         ],
//       ),
//     );
//   }
//
//
//
//   Widget buildSlider() {
//     return LayoutBuilder(
//       builder: (context, constraints) {
//         final maxHeight = constraints.maxHeight * 0.3;
//
//         return Container(
//           margin: EdgeInsets.symmetric(vertical: 13),
//           child: ConstrainedBox(
//             constraints: BoxConstraints(
//               maxHeight: maxHeight,
//             ),
//             child: slider(
//               images: widget.aboutCompany[0].aboutImgs!,
//               aspectRatio: 2 / 1,
//               viewPortFraction: 0.97,
//             ),
//           ),
//         );
//       },
//     );
//   }
//
//   Widget buildTabletLayout(dynamic value) {
//     return Scaffold(
//       body: Row(
//         children: [
//           // Left side: Categories list
//           Visibility(
//             visible: _currentOverlay == null,
//             child: Expanded(
//               flex: 1,
//               child: SingleChildScrollView(
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     buildSlider(),
//                     buildCategories(value),
//                     buildGridItems(value),
//                     builderImage(value), // Correctly using the function
//                   ],
//                 ),
//               ),
//             ),
//           ),
//           // Right side: Detail view
//           if (_currentOverlay != null)
//             Expanded(
//               flex: 2,
//               child: Stack(
//                 children: [
//                   _currentOverlay!,
//                   Positioned(
//                     top: 5,
//                     left: 10,  // Moved the close icon to the left side
//                     child: IconButton(
//                       icon: Icon(Icons.arrow_back_ios),
//                       onPressed: _hideOverlay,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//         ],
//       ),
//     );
//   }
//
//   Widget builderImage(dynamic value) {
//     return Builder(
//       builder: (BuildContext context) {
//         final screenWidth = MediaQuery.of(context).size.width;
//
//         // Define margin based on screen width
//         final double horizontalMargin;
//         if (screenWidth < 600) {
//           // Mobile
//           horizontalMargin = screenWidth * 0.01; // 3% of screen width
//         } else if (screenWidth < 1200) {
//           // Tablet
//           horizontalMargin = screenWidth * 0.009; // 2% of screen width
//         } else {
//           // Desktop
//           horizontalMargin = screenWidth * 0.04; // 1% of screen width
//         }
//         return InkWell(
//           onTap: () {
//             final iosLink = value.aboutCompany.data.data.iosAppLiveLink;
//             final androidLink = value.aboutCompany.data.data.appLiveLink;
//
//             if (iosLink.isEmpty && androidLink.isEmpty) {
//               showDialog(
//                 context: context,
//                 builder: (context) => ErrorDialogue(
//                   message: 'No link found',
//                 ),
//               );
//             } else {
//               _onShare(
//                 context,
//                 'iOS App Link: $iosLink\nAndroid App Link: $androidLink',
//                 ConstantStrings.appName,
//               );
//             }
//           },
//           child: Container(
//             margin: EdgeInsets.symmetric(horizontal: horizontalMargin),
//             child: Image.asset(
//               "assets/images/png/share-image.png",
//               fit: BoxFit.cover,
//             ),
//           ),
//         );
//       },
//     );
//   }
//
//   Widget buildDesktopLayout(val) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Expanded(flex: 1, child: buildCategories(val)),
//         Expanded(flex: 2, child: buildGridItems(val)),
//       ],
//     );
//   }
//
//   Widget buildCategories(val) {
//     return Container(
//       margin: EdgeInsets.only(
//           left: MediaQuery.of(context).size.width * 0.03,
//           right: MediaQuery.of(context).size.width * 0.03,
//           top: MediaQuery.of(context).size.width * 0.02,
//           bottom: 0.0),
//       child:
//       Column(
//         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           TextWithStyle.containerTitle(context, 'Categories'),
//           SizedBox(height: MediaQuery.of(context).size.height * 0.01),
//           Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Expanded(
//                 child: Container(
//                   padding: EdgeInsets.only(
//                     top: MediaQuery.of(context).size.height / 60,
//                     bottom: MediaQuery.of(context).size.height / 140,
//                   ),
//                   child: Column(
//                     children: [
//                       MainIconsWithFun(
//                           title: ConstantStrings.productScreen,
//                           image: 'assets/images/png/products.png',
//                           onPress: () =>
//                           //     Navigator.push(
//                           //   context,
//                           //   MaterialPageRoute(
//                           //     builder: (context) => ProductScreen(
//                           //       token: widget.token,
//                           //       isOwner: widget.isOwner,
//                           //     ),
//                           //   ),
//                           // ),
//
//                           _showOverlay(ProductScreen(token: widget.token, isOwner: widget.isOwner))
//
//                       ),
//                       Text(
//                         val.data?.productCount.toString() ?? '0',
//                         style: TextStyle(
//                           fontSize: MediaQuery.of(context).size.width *
//                               0.02, // Responsive font size
//                           color: Colors.black54,
//                           fontWeight: FontWeight.w500,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//               const SizedBox(width: 10),
//               Expanded(
//                 child:
//                 Container(
//                   padding: EdgeInsets.only(
//                     top: MediaQuery.of(context).size.height / 60,
//                     bottom: MediaQuery.of(context).size.height / 140,
//                   ),
//                   child:
//                   Column(
//                     children: [
//                       MainIconsWithFun(
//                         title: ConstantStrings.visualAidsScreen,
//                         image: 'assets/images/png/visualaids.png',
//                         onPress: () =>
//                         //     Navigator.push(
//                         //   context,
//                         //   MaterialPageRoute(
//                         //     builder: (context) => VisualAidsScreen(
//                         //       token: widget.token,
//                         //     ),
//                         //   ),
//                         // ),
//
//                         _showOverlay(VisualAidsScreen(token: widget.token)),
//
//                       ),
//                       Text(
//                         "",
//                         style: TextStyle(
//                           fontSize: MediaQuery.of(context).size.width *
//                               0.035, // Responsive font size
//                           fontWeight: FontWeight.w300,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//               const SizedBox(width: 10),
//               widget.isOwner == true || widget.isOwner == null
//                   ?
//               Expanded(
//                 child: Container(
//                   padding: EdgeInsets.only(
//                     top: MediaQuery.of(context).size.height / 60,
//                     bottom: MediaQuery.of(context).size.height / 140,
//                   ),
//                   child: Column(
//                     children: [
//                       MainIconsWithFun(
//                         title: ConstantStrings.mrs,
//                         image: 'assets/images/png/mrs.png',
//                         onPress: () async {
//                           if (widget.token != null) {
//                             _showOverlay(const MrsScreen());
//                           } else {
//                             _showOverlay(LoginScreen());
//                           }
//                         },
//                       ),
//                       Text(
//                         '',
//                         style: TextStyle(
//                           fontSize: Responsive.isMobile(context)
//                               ? MediaQuery.of(context).size.width * 0.04
//                               : (Responsive.isTablet(context)
//                               ? MediaQuery.of(context).size.width * 0.035
//                               : MediaQuery.of(context).size.width * 0.03),
//                           fontWeight: FontWeight.w500,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               )
//                   : Container(),
//               const SizedBox(width: 10),
//               Expanded(
//                 child: Container(
//                   padding: EdgeInsets.only(
//                     top: MediaQuery.of(context).size.height / 60,
//                     bottom: MediaQuery.of(context).size.height / 140,
//                   ),
//                   child:
//                   Column(
//                     children: [
//                       MainIconsWithFun(
//                           title: ConstantStrings.myOrders,
//                           image: 'assets/images/png/orders.png',
//                           onPress: () {
//                             if (_currentOverlay != null) {
//                               _hideOverlay();
//                             } else {
//                               widget.token != null && widget.token!.isNotEmpty
//                                   ? widget.isOwner == true
//                                   ? _showOverlay(const MyOrderScreen())
//                                   : _showOverlay(const CustomersOrderScreen())
//                                   : _showOverlay(const LoginScreen());
//                             }
//                           }
//                       ),
//                       Text(
//                         widget.token != null && widget.token!.isNotEmpty
//                             ? widget.isOwner == true
//                             ? val.dataa?.companyOrderCount.count
//                             .toString()
//                             .length ==
//                             1
//                             ? '0${val.dataa?.companyOrderCount.count.toString()}'
//                             : val.dataa?.companyOrderCount.count
//                             .toString() ??
//                             '0'
//                             : val.data?.orderCount.toString() ?? '0'
//                             : '0',
//                         style: TextStyle(
//                           fontSize: MediaQuery.of(context).size.width *
//                               0.02, // Responsive font size
//                           color: Colors.black54,
//                           fontWeight: FontWeight.w500,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ],
//           ),
//           const Divider(
//             color: Colors.black12,
//             height: 10,
//           ),
//         ],
//       ),
//
//     );
//   }
//
//
//   Widget buildGridItems(val) {
//     return GridView.count(
//       physics: const NeverScrollableScrollPhysics(),
//       primary: false,
//       shrinkWrap: true,
//       padding: EdgeInsets.all(MediaQuery.of(context).size.height / 100),
//       crossAxisCount: Responsive.isTablet(context) ? 4 : 4,
//       children: [
//         buildGridItem(
//           ConstantStrings.upcomingScreen,
//           'assets/images/png/upcoming_products.png',
//               () =>
//           //         Navigator.push(
//           //   context,
//           //   MaterialPageRoute(
//           //     builder: (context) => UpcomingProductScreen(token: widget.token),
//           //   ),
//           // ),
//
//           _showOverlay(UpcomingProductScreen(token: widget.token)),
//
//         ),
//         buildGridItem(
//           ConstantStrings.divisions,
//           'assets/images/png/divisons.png',
//               () =>
//           //         Navigator.push(
//           //   context,
//           //   MaterialPageRoute(
//           //     builder: (context) => DivisionScreen(
//           //         token: widget.token, value: widget.aboutCompany),
//           //   ),
//           // ),
//           _showOverlay( DivisionScreen(token: widget.token,value: widget.aboutCompany)),
//         ),
//         buildGridItem(
//           ConstantStrings.presentation,
//           'assets/images/png/slides.png',
//               () =>
//           //         Navigator.push(
//           //   context,
//           //   MaterialPageRoute(
//           //     builder: (context) => PresentationListScreen(),
//           //   ),
//           // ),
//
//           _showOverlay(PresentationListScreen()),
//         ),
//         buildGridItem(
//           ConstantStrings.visits,
//           'assets/images/png/visits.png',
//               () =>
//           //         Navigator.push(
//           //   context,
//           //   MaterialPageRoute(
//           //     builder: (context) => const VisitsScreen(),
//           //   ),
//           // ),
//
//           _showOverlay(const VisitsScreen()),
//         ),
//         buildGridItem(
//           ConstantStrings.selfAnalysis,
//           'assets/images/png/self_analysis.png',
//               () =>
//           //         Navigator.push(
//           //   context,
//           //   MaterialPageRoute(
//           //     builder: (context) => const SelfAnalysisScreen(),
//           //   ),
//           // ),
//           _showOverlay(const SelfAnalysisScreen()),
//
//
//         ),
//         buildGridItem(
//           ConstantStrings.newLaunches,
//           'assets/images/png/new_launches.png',
//               () =>
//           //         Navigator.push(
//           //   context,
//           //   MaterialPageRoute(
//           //     builder: (context) =>
//           //         NewLaunchedProductScreen(token: widget.token),
//           //   ),
//           // ),
//
//           _showOverlay(NewLaunchedProductScreen(token: widget.token)),
//         ),
//         buildGridItem(
//             ConstantStrings.ptrpts,
//             'assets/images/png/ptrpts.png',
//                 () =>
//             //         Navigator.push(
//             //   context,
//             //   MaterialPageRoute(
//             //     builder: (context) => const Calculator(),
//             //   ),
//             // ),
//             _showOverlay(const Calculator())
//
//         ),
//         buildGridItem(
//           ConstantStrings.enquiry,
//           'assets/images/png/connectwithus.png',
//               () =>
//           //         Navigator.push(
//           //   context,
//           //   MaterialPageRoute(
//           //     builder: (context) => EnquiryScreen(value: widget.aboutCompany),
//           //   ),
//           // ),
//
//           _showOverlay(EnquiryScreen(value: widget.aboutCompany)),
//         ),
//         buildGridItem(
//           ConstantStrings.customersOrders,
//           'assets/images/png/customersorders.png',
//               () =>
//           //         Navigator.push(
//           //   context,
//           //   MaterialPageRoute(
//           //     builder: (context) => const CustomersOrderScreen(),
//           //   ),
//           // ),
//
//           _showOverlay(const CustomersOrderScreen()),
//         ),
//
//         buildGridItem(
//           ConstantStrings.promotional,
//           'assets/images/png/promotional_items.png',
//               () =>
//           //         Navigator.push(
//           //   context,
//           //   MaterialPageRoute(
//           //     builder: (context) => const PromotionalScreen(),
//           //   ),
//           // ),
//
//           _showOverlay(const PromotionalScreen()),
//         ),
//         buildGridItem(
//           ConstantStrings.favouriteScreenHeading,
//           'assets/images/png/favorite.png',
//               () =>
//           //         Navigator.push(
//           //   context,
//           //   MaterialPageRoute(
//           //     builder: (context) => FavouriteScreen(token: widget.token),
//           //   ),
//           // ),
//
//           _showOverlay(FavouriteScreen(token: widget.token)),
//         ),
//
//         buildGridItem(
//           'Offers',
//           'assets/images/png/offers.png',
//               () =>
//           //         Navigator.push(
//           //   context,
//           //   MaterialPageRoute(
//           //     builder: (context) => const OfferScreen(),
//           //   ),
//           // ),
//
//           _showOverlay(const OfferScreen()),
//         ),
//       ],
//     );
//   }
//
//   Widget buildCategoryItem(String title, String count, VoidCallback onPress) {
//     return Expanded(
//       child: InkWell(
//         onTap: onPress,
//         child: Column(
//           children: [
//             MainIconsWithFun(
//               title: title,
//               image: 'assets/images/png/products.png',
//               onPress: onPress,
//             ),
//             Text(
//               count,
//               style: TextStyle(fontSize: 13.5),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget buildGridItem(String title, String image, VoidCallback onPress) {
//     return PngIconsWithFun(
//       title: title,
//       image: image,
//       onPress: onPress,
//     );
//   }
//
//   Widget buildLoadingScreen(BuildContext context) {
//     return Container(
//       height: MediaQuery.of(context).size.height,
//       width: MediaQuery.of(context).size.width,
//       color: AppColors.backgroundColor,
//       child: Center(
//         child: LoadingAnimationWidget.discreteCircle(
//           color: AppColors.primaryColor,
//           size: 40,
//         ),
//       ),
//     );
//   }
//
//   Widget buildFloatingActionButton() {
//     return Consumer<ScrollState>(
//       builder: (context, scrollState, _) {
//         return scrollState.isScrolling
//             ? ClipRRect(
//           borderRadius: BorderRadius.circular(30.0),
//           child: FloatingActionButton.extended(
//             onPressed: () {
//               Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                       builder: (context) => AddScreen(
//                         isOwner: widget.isOwner,
//                         token: widget.token,
//                       )));
//             },
//             backgroundColor: AppColors.primaryColor,
//             label: TextWithStyle.contactUsTitle(
//                 context, ConstantStrings.addScreen),
//           ),
//         )
//             : ClipRRect(
//           borderRadius: BorderRadius.circular(100.0),
//           child: FloatingActionButton(
//             onPressed: () {
//               // Navigator.push(
//               //     context,
//               //     MaterialPageRoute(
//               //         builder: (context) => AddScreen(
//               //           isOwner: widget.isOwner,
//               //           token: widget.token,
//               //         )));
//
//               _showOverlay(AddScreen(isOwner: widget.isOwner,token: widget,));
//             },
//             backgroundColor: AppColors.primaryColor,
//             child: const Icon(
//               Icons.add,
//               color: Colors.white,
//             ),
//           ),
//         );
//       },
//     );
//   }
// }
//
//
// _onShare(BuildContext context, text, subject) {
//   final box = context.findRenderObject() as RenderBox?;
//   return Share.share(
//     text,
//     subject: subject,
//     sharePositionOrigin: box!.localToGlobal(Offset.zero) & box.size,
//   );
// }
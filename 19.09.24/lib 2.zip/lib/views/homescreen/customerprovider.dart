import 'package:flutter/material.dart';
import '../../data/model/response_model/customers/customers_responseModel.dart';
import '../../resources/app_colors.dart';
import '../../resources/constant_imageString.dart';
import '../../resources/constant_strings.dart';
import '../../utils/Dialogue/error_dialogue.dart';
import '../../utils/Responsive/ResponsiveUtils.dart';
import '../../utils/text_style.dart';
import '../customer/add_customer.dart';
import '../customer/customers_profileScreen.dart';


class CustomersScreenState with ChangeNotifier {
  Widget? _currentOverlay;
  Customers? _selectedCustomer;
  bool _showFab = true; // Track FAB visibility

  Widget? get currentOverlay => _currentOverlay;
  Customers? get selectedCustomer => _selectedCustomer;
  bool get showFab => _showFab; // Expose FAB visibility

  void showOverlay(BuildContext context, Customers customer) {
    if (Responsive.isTablet(context)) {
      _selectedCustomer = customer;
      _currentOverlay = CustomersProfileScreen(profile: [customer]);
      _showFab = false; // Hide FAB
      notifyListeners();
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => CustomersProfileScreen(profile: [customer])),
      );
    }
  }

  void hideOverlay(BuildContext context) {
    _currentOverlay = null;
    _selectedCustomer = null;
    _showFab = true; // Show FAB
    notifyListeners();
  }

  void navigateToAddCustomer(BuildContext context) {
    if (Responsive.isTablet(context)) {
      _currentOverlay = AddCustomerScreen();
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => AddCustomerScreen()),
      );
    }
    notifyListeners();
  }
}

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:provider/provider.dart';

import '../../data/response/status.dart';
import '../../resources/app_colors.dart';
import '../../resources/constant_strings.dart';
import '../../utils/Dialogue/error_dialogue.dart';
import '../../utils/text_style.dart';
import '../../view_model/afterLogin_viewModel/afterLogin_viewModels.dart';

class BankDetailsScreen extends StatefulWidget {
  const BankDetailsScreen({Key? key}) : super(key: key);

  @override
  State<BankDetailsScreen> createState() => _BankDetailsScreenState();
}

class _BankDetailsScreenState extends State<BankDetailsScreen> {
  FirmViewModel model = FirmViewModel();

  @override
  void initState() {
    model.fetchFirm();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isTablet = screenWidth >= 600; // Determine if it's a tablet
    final double padding = isTablet ? 24.0 : 16.0; // Responsive padding
    final double margin = isTablet ? 24.0 : 16.0; // Responsive margin
    final double fontSizeLarge = isTablet ? 17.0 : 16.0; // Responsive font size
    final double fontSizeSmall = isTablet ? 17.0 : 14.0; // Responsive font size for labels
    final double logoWidth = screenWidth / (isTablet ? 4.0 : 3.5); // Responsive logo width

    return Scaffold(
        appBar: AppBar(
          // automaticallyImplyLeading: false,
          centerTitle: false,
          title: Row(
            children: [
              // SizedBox(
              //   width: isTablet
              //       ? screenWidth * 0.1 // Adjust width for tablets
              //       : screenWidth * 0.3, // Adjust width for mobile
              // ),
              TextWithStyle.appBarTitle(context, ConstantStrings.bankDetails),
            ],
          ),
          elevation: 0,
        ),
        body: ChangeNotifierProvider<FirmViewModel>(
            create: (BuildContext context) => model,
            child: Consumer<FirmViewModel>(
                builder: (BuildContext context, value, _) {
                  switch (value.firm.status!) {
                    case Status.loading:
                      return Container(
                        height: MediaQuery.of(context).size.height,
                        width: MediaQuery.of(context).size.width,
                        color: AppColors.backgroundColor,
                        child: Center(
                          child: LoadingAnimationWidget.discreteCircle(
                            color: AppColors.primaryColor,
                            size: isTablet ? 50.0 : 40.0, // Responsive loading animation size
                          ),
                        ),
                      );
                    case Status.error:
                      if (kDebugMode) {
                        print(value.firm.message.toString());
                      }
                      return ErrorDialogue(
                        message: value.firm.message.toString(),
                      );
                    case Status.completed:
                      var data = value.firm.data!.data;
                      return Column(
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width,
                            margin: EdgeInsets.symmetric(
                              horizontal: margin,
                              vertical: margin,
                            ),
                            padding: EdgeInsets.all(padding),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                  color: AppColors.primaryColor.withOpacity(0.1),
                                  spreadRadius: 1,
                                  blurRadius: 4,
                                  offset: const Offset(0, 0),
                                ),
                              ],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                _buildDetailText(
                                  label: 'Bank Name',
                                  value: '${data?.bankName ?? 'NA'}',
                                  fontSizeLarge: fontSizeLarge,
                                  fontSizeSmall: fontSizeSmall,
                                ),
                                _buildDetailText(
                                  label: 'Account Number',
                                  value: '${data?.bankAccNo ?? 'NA'}',
                                  fontSizeLarge: fontSizeLarge,
                                  fontSizeSmall: fontSizeSmall,
                                ),
                                _buildDetailText(
                                  label: 'IFSC Code',
                                  value: '${data?.bankIfsc ?? 'NA'}',
                                  fontSizeLarge: fontSizeLarge,
                                  fontSizeSmall: fontSizeSmall,
                                ),
                                _buildDetailText(
                                  label: 'Payee Name',
                                  value: '${data?.bankPayeeName ?? 'NA'}',
                                  fontSizeLarge: fontSizeLarge,
                                  fontSizeSmall: fontSizeSmall,
                                ),
                              ],
                            ),
                          ),
                          Expanded(
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: Padding(
                                padding: EdgeInsets.only(bottom: margin), // Responsive bottom padding
                                child: Image.asset(
                                  'assets/images/png/webhopers_logo2.png',
                                  width: logoWidth, // Responsive logo width
                                ),
                              ),
                            ),
                          ),
                        ],
                      );
                  }
                })));
  }

  Widget _buildDetailText({
    required String label,
    required String value,
    required double fontSizeLarge,
    required double fontSizeSmall,
  }) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8.0), // Padding between items
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: fontSizeSmall, // Responsive label font size
              color: Colors.black45,
            ),
          ),
          SizedBox(height: 4.0), // Spacing between label and value
          Text(
            value,
            style: TextStyle(
              fontSize: fontSizeLarge, // Responsive value font size
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

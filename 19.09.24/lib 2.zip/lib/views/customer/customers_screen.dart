import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pharma_clients_app/view_model/afterLogin_viewModel/afterLogin_viewModels.dart';
import 'package:provider/provider.dart';
import '../../data/response/status.dart';
import '../../resources/app_colors.dart';
import '../../resources/constant_imageString.dart';
import '../../resources/constant_strings.dart';
import '../../utils/Dialogue/error_dialogue.dart';
import '../../utils/Responsive/ResponsiveUtils.dart';
import '../../utils/text_style.dart';
import '../homescreen/customerprovider.dart';


class CustomersScreen extends StatelessWidget {
  const CustomersScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<CustomersScreenState>(
      create: (context) => CustomersScreenState(),
      child: Consumer<CustomersScreenState>(
        builder: (context, screenState, _) {
          return ChangeNotifierProvider<CustomersViewModel>(
            create: (context) => CustomersViewModel()..fetchCustomers(),
            child: Consumer<CustomersViewModel>(
              builder: (context, model, _) {
                double screenWidth = MediaQuery.of(context).size.width;
                double screenHeight = MediaQuery.of(context).size.height;

                double responsivePadding = screenWidth * 0.02; // 2% of screen width
                double responsiveMargin = screenWidth * 0.02; // 2% of screen width

                double iconSize = Responsive.isTablet(context)
                    ? screenWidth * 0.034
                    : screenWidth * 0.06;

                return Scaffold(
                  appBar: AppBar(
                    automaticallyImplyLeading: false,
                    centerTitle: false,
                    elevation: 0,
                    title: screenState.currentOverlay == null
                        ? TextWithStyle.appBarTitle(context, ConstantStrings.customerHeading)
                        : Text(''), // Empty title or any other title when overlay is displayed
                  ),
                  body: Responsive.isTablet(context)
                      ? Row(
                    children: [
                      // Left side: Customer list
                      if (screenState.currentOverlay == null)
                        Expanded(
                          flex: 1,
                          child: Stack(
                            children: [
                              if (model.customersList.status == Status.loading)
                                const Center(child: CircularProgressIndicator())
                              else if (model.customersList.status == Status.error)
                                ErrorDialogue(message: model.customersList.message.toString())
                              else if (model.customersList.data?.data?.isNotEmpty ?? false)
                                  ListView.builder(
                                    itemCount: model.customersList.data!.data!.length,
                                    itemBuilder: (BuildContext context, int index) {
                                      final customer = model.customersList.data!.data![index];
                                      return Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: responsiveMargin, vertical: responsiveMargin),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(responsivePadding),
                                          boxShadow: [
                                            BoxShadow(
                                              color: AppColors.primaryColor.withOpacity(0.1),
                                              spreadRadius: 1,
                                              blurRadius: 4,
                                            ),
                                          ],
                                        ),
                                        child: InkWell(
                                          onTap: () => screenState.showOverlay(context, customer),
                                          child: Padding(
                                            padding: EdgeInsets.all(responsivePadding),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  children: [
                                                    Expanded(
                                                      child: TextWithStyle.customerName(
                                                        context,
                                                        customer.name,
                                                      ),
                                                    ),
                                                    Container(
                                                      padding: EdgeInsets.symmetric(
                                                          horizontal: responsivePadding,
                                                          vertical: responsivePadding / 2),
                                                      decoration: BoxDecoration(
                                                        color: AppColors.primaryColor,
                                                        borderRadius: BorderRadius.circular(
                                                            responsivePadding),
                                                      ),
                                                      child: TextWithStyle.customerStatus(
                                                        context,
                                                        customer.profession,
                                                        Colors.white,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                SizedBox(height: responsiveMargin),
                                                rowWidget(
                                                  context,
                                                  '${customer.email}',
                                                  CupertinoIcons.mail_solid,
                                                ),
                                                SizedBox(height: responsiveMargin),
                                                rowWidget(
                                                  context,
                                                  '${customer.phone}',
                                                  CupertinoIcons.phone_fill,
                                                ),
                                                SizedBox(height: responsiveMargin),
                                                rowWidget(
                                                  context,
                                                  '${customer.address}',
                                                  CupertinoIcons.location_solid,
                                                ),
                                                Divider(thickness: 1, endIndent: responsiveMargin),
                                                TextWithStyle.customerTimeDetails(
                                                  context,
                                                  "${customer.createdOn}",
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  )
                                else
                                  Center(
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Image.asset(
                                          ConstantImage.empty,
                                          width: screenWidth * 0.7,
                                          fit: BoxFit.fill,
                                        ),
                                        SizedBox(height: responsiveMargin),
                                        TextWithStyle.appBarTitle(
                                            context, ConstantStrings.emptyScreen),
                                      ],
                                    ),
                                  ),
                            ],
                          ),
                        ),
                      // Right side: Detail view or AddCustomerScreen
                      if (screenState.currentOverlay != null)
                        Expanded(
                          flex: 2,
                          child: Stack(
                            children: [
                              screenState.currentOverlay!,
                              Positioned(
                                top: 5,
                                left: 10,
                                child: IconButton(
                                  icon: Icon(Icons.arrow_back_ios),
                                  onPressed: () => screenState.hideOverlay(context),
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  )
                      : screenState.currentOverlay == null
                      ? Stack(
                    children: [
                      if (model.customersList.status == Status.loading)
                        const Center(child: CircularProgressIndicator())
                      else if (model.customersList.status == Status.error)
                        ErrorDialogue(message: model.customersList.message.toString())
                      else if (model.customersList.data?.data?.isNotEmpty ?? false)
                          ListView.builder(
                            itemCount: model.customersList.data!.data!.length,
                            itemBuilder: (BuildContext context, int index) {
                              final customer = model.customersList.data!.data![index];
                              return Container(
                                margin: EdgeInsets.symmetric(
                                    horizontal: responsiveMargin, vertical: responsiveMargin),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(responsivePadding),
                                  boxShadow: [
                                    BoxShadow(
                                      color: AppColors.primaryColor.withOpacity(0.1),
                                      spreadRadius: 1,
                                      blurRadius: 4,
                                    ),
                                  ],
                                ),
                                child: InkWell(
                                  onTap: () => screenState.showOverlay(context, customer),
                                  child: Padding(
                                    padding: EdgeInsets.all(responsivePadding),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Expanded(
                                              child: TextWithStyle.customerName(
                                                context,
                                                customer.name,
                                              ),
                                            ),
                                            Container(
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: responsivePadding,
                                                  vertical: responsivePadding / 2),
                                              decoration: BoxDecoration(
                                                color: AppColors.primaryColor,
                                                borderRadius: BorderRadius.circular(
                                                    responsivePadding),
                                              ),
                                              child: TextWithStyle.customerStatus(
                                                context,
                                                customer.profession,
                                                Colors.white,
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: responsiveMargin),
                                        rowWidget(
                                          context,
                                          '${customer.email}',
                                          CupertinoIcons.mail_solid,
                                        ),
                                        SizedBox(height: responsiveMargin),
                                        rowWidget(
                                          context,
                                          '${customer.phone}',
                                          CupertinoIcons.phone_fill,
                                        ),
                                        SizedBox(height: responsiveMargin),
                                        rowWidget(
                                          context,
                                          '${customer.address}',
                                          CupertinoIcons.location_solid,
                                        ),
                                        Divider(thickness: 1, endIndent: responsiveMargin),
                                        TextWithStyle.customerTimeDetails(
                                          context,
                                          "${customer.createdOn}",
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            },
                          )
                        else
                          Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset(
                                  ConstantImage.empty,
                                  width: screenWidth * 0.7,
                                  fit: BoxFit.fill,
                                ),
                                SizedBox(height: responsiveMargin),
                                TextWithStyle.appBarTitle(
                                    context, ConstantStrings.emptyScreen),
                              ],
                            ),
                          ),
                    ],
                  )
                      : screenState.currentOverlay!,
                  floatingActionButton: screenState.showFab
                      ?
                  FloatingActionButton(
                    backgroundColor: AppColors.primaryColor,
                    onPressed: () => screenState.navigateToAddCustomer(context),
                    child: const
                    Icon(
                      CupertinoIcons.person_add,
                      color: Colors.white,

                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30), // This ensures the button remains round
                    ),
                    elevation: 6, // Adds shadow to make it stand out
                  )

                      : null,
                );
              },
            ),
          );
        },
      ),
    );
  }

  Widget rowWidget(BuildContext context, String text, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: AppColors.primaryColor),
        SizedBox(width: 10),
        Expanded(
          child: TextWithStyle.customerDetails(context, text),
        ),
      ],
    );
  }
}

import 'package:flutter/cupertino.dart';

class SelectedCustomerProvider extends ChangeNotifier {
  var _selectedCustomer;

  get selectedCustomer => _selectedCustomer;

  void setSelectedCustomer(newValue) {
    _selectedCustomer = newValue;
    notifyListeners();  // Notify listeners that the value has changed
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import '../resources/app_colors.dart';
import '../utils/text_style.dart';

class ProfileContainer extends StatelessWidget {
  final VoidCallback? onPress;
  final String? image;
  final String? title;

  ProfileContainer({
    this.onPress,
    this.image,
    this.title,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isTablet = screenWidth >= 600;

    // Define container height with smaller value for tablets
    final double containerHeight = isTablet ? 6.h : 10.h;

    return InkWell(
      onTap: onPress,
      child: Container(
        // Apply the dynamic height here
        height: containerHeight,
        margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(isTablet ? 15 : 10),
          boxShadow: [
            BoxShadow(
              color: AppColors.primaryColor.withOpacity(0.1),
              spreadRadius: 1,
              blurRadius: 4,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                SvgPicture.asset(
                  image ?? '',
                  width: isTablet ? 24 : 20,
                  height: isTablet ? 24 : 20,
                  colorFilter: ColorFilter.mode(AppColors.primaryColor, BlendMode.srcIn),
                ),
                SizedBox(width: 2.w),
                TextWithStyle.mrProfileHeading(context, title ?? ''),
              ],
            ),
            Icon(
              Icons.chevron_right,
              size: isTablet ? 24 : 20,
              color: AppColors.primaryColor,
            ),
          ],
        ),
      ),
    );
  }
}

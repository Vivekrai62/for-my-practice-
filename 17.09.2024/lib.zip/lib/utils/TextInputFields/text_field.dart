import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:responsive_sizer/responsive_sizer.dart'; // Ensure you import this if using for any size-related utility
import '../../resources/app_colors.dart';

class TextInputField extends StatelessWidget {
  final dynamic title;
  final dynamic node;
  final String? hintText;
  final String? labelText;
  final dynamic icon;
  final dynamic validator;

  TextInputField({
    this.title,
    this.node,
    this.hintText,
    this.labelText,
    this.icon,
    this.validator,
    Key? key
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    // Adjust the size and padding based on the device type
    double iconSize = (width < 600) ? 22.0 : (width < 1200) ? 21.0 : 40.0;
    double padding = (width < 600) ?15 : (width < 1200) ? 10.0 : 16.0;
    double fontSize = (width < 600) ? 19.0 : (width < 1200) ? 19.0 : 18.0; // Increased font size for hint and label

    return Container(
      margin: EdgeInsets.only(bottom: padding),
      child: TextFormField(
        style: TextStyle(fontSize: fontSize), // Adjusts the text size in the input field
        controller: title,
        focusNode: node,
        maxLines: null,
        textInputAction: TextInputAction.next,
        validator: validator,
        decoration: InputDecoration(
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(15)),
            borderSide: BorderSide(color: AppColors.primaryColor),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(23)),
            borderSide: BorderSide(color: AppColors.primaryColor),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(10)),
            borderSide: BorderSide(color: Colors.red.shade700),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(10)),
            borderSide: BorderSide(color: Colors.red.shade700),
          ),
          contentPadding: EdgeInsets.fromLTRB(0, padding, 1, padding),
          border: InputBorder.none,
          prefixIcon: Padding(
            padding: EdgeInsets.all(padding),
            child: Icon(icon, size: iconSize),
          ),
          hintText: hintText,
          labelText: labelText,
          hintStyle: TextStyle(
            fontSize: fontSize, // Font size for hint text
          ),
          labelStyle: TextStyle(
            fontSize: fontSize, // Font size for label text
          ),
        ),
      ),
    );
  }
}

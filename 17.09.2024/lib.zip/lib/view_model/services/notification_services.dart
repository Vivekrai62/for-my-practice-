import 'dart:io';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:intl/intl.dart';
import 'package:pharma_clients_app/views/SplashScreen/splash_screen.dart';
import 'package:pharma_clients_app/views/homescreen/NotificationScreen.dart';
import 'package:pharma_clients_app/views/homescreen/offer_screen.dart';
import 'package:pharma_clients_app/views/products/product_detail_screen.dart';
import 'package:pharma_clients_app/views/products/product_screen.dart';
import 'package:pharma_clients_app/views/products/upcoming_products.dart';
import 'package:provider/provider.dart';

import '../../data/model/requested_data_model/notificationData.dart';
import '../afterLogin_viewModel/afterLogin_viewModels.dart';
import '../user_viewModel.dart';

class NotificationServices {

  int? type;
  //initialising firebase message plugin
  FirebaseMessaging messaging = FirebaseMessaging.instance ;

  //initialising firebase message plugin
  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin  = FlutterLocalNotificationsPlugin();

  void requestNotificationPermission(isOwner, token) async {
    NotificationSettings settings = await messaging.requestPermission(
      alert: true,
      announcement: true,
      badge: true,
      carPlay: true,
      criticalAlert: true,
      provisional: true,
      sound: true ,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      if (kDebugMode) {
        print('user granted permission');
      }
    } else if (settings.authorizationStatus ==
        AuthorizationStatus.provisional) {
      if (kDebugMode) {
        print('user granted provisional permission');
      }
    } else {
      if (kDebugMode) {
        print('user denied permission');
      }
    }
    print(isOwner);
    if (isOwner == false) {
      type = 1;
      await FirebaseMessaging.instance.subscribeToTopic('MRs_notification');
    } else if (isOwner == true) {
      type = 0;
      await FirebaseMessaging.instance.subscribeToTopic('Distributors_notification');
    } else {
      type = 2;
    }
  }

  void firebaseInit(BuildContext context, isOwner, token){

    FirebaseMessaging.onMessage.listen((message) async {

      RemoteNotification? notification = message.notification;

      String date = DateFormat("dd-MM-yyyy h:mm a").format(DateTime.parse(
          message.sentTime != null
              ? message.sentTime.toString()
              : DateTime.now().toString()));

      if (notification != null) {

        NotificationData notificationData = NotificationData(
          title: notification.title ?? 'Na',
          message: notification.body?? 'Na',
          dateTime: date,
        );

      await Provider.of<NotificationList>(context,listen: false).addNotification(notificationData);

      if (kDebugMode) {
        print("notifications title:${notification!.title}");
        print("notifications body:${notification.body}");
        print('data: ${message.data['id'].toString()}');
      }

      if(Platform.isIOS){
        foregroundMessage();
      }

      if(Platform.isAndroid){
        initLocalNotifications(context, message, isOwner, token);
        showNotification(message);
      }

    }
    });
  }

  void initLocalNotifications(BuildContext context, RemoteMessage message, isOwner, token)async{
    var androidInitializationSettings = const AndroidInitializationSettings('@mipmap/ic_launcher');
    var iosInitializationSettings = const DarwinInitializationSettings();

    var initializationSetting = InitializationSettings(
        android: androidInitializationSettings ,
        iOS: iosInitializationSettings
    );

    await _flutterLocalNotificationsPlugin.initialize(
        initializationSetting,
        onDidReceiveNotificationResponse: (payload){
          // handle interaction when app is active for android
          handleMessage(context, message, isOwner, token);
        }
    );
  }

  // function to show visible notification when app is active
  Future<void> showNotification(RemoteMessage message)async{

    AndroidNotificationChannel channel = AndroidNotificationChannel(
        message.notification!.android!.channelId.toString(),
      message.notification!.android!.channelId.toString() ,
      importance: Importance.max,
      showBadge: true ,
      playSound: true,
    );

     AndroidNotificationDetails androidNotificationDetails = AndroidNotificationDetails(
      channel.id.toString(),
      channel.name.toString() ,
      channelDescription: 'your channel description',
      importance: Importance.high,
      priority: Priority.high ,
      playSound: true,
      //ticker: 'ticker' ,
         //sound: channel.sound
    //     sound: RawResourceAndroidNotificationSound('jetsons_doorbell')
    //  icon: largeIconPath
    );

    const DarwinNotificationDetails darwinNotificationDetails = DarwinNotificationDetails(
      presentAlert: true ,
      presentBadge: true ,
      presentSound: true
    ) ;

    NotificationDetails notificationDetails = NotificationDetails(
      android: androidNotificationDetails,
      iOS: darwinNotificationDetails
    );

    Future.delayed(Duration.zero , (){
      _flutterLocalNotificationsPlugin.show(
          0,
          message.notification!.title.toString(),
          message.notification!.body.toString(),
          notificationDetails ,
      );
    });

  }

  void isTokenRefresh()async{
    messaging.onTokenRefresh.listen((event) {
      event.toString();
      if (kDebugMode) {
        print('refresh');
      }
    });
  }

  //handle tap on notification when app is in background or terminated
  Future<void> setupInteractMessage(BuildContext context, isOwner, token)async{

    // when app is terminated
    RemoteMessage? initialMessage = await FirebaseMessaging.instance.getInitialMessage();

    if(initialMessage != null){
      handleMessage(context, initialMessage, isOwner, token);
    }
    //when app ins background
    FirebaseMessaging.onMessageOpenedApp.listen((event) {
      handleMessage(context, event, isOwner, token);
    });

  }

  void handleMessage(BuildContext context, RemoteMessage message, isOwner,token) {

    final route = message.data['route'];
    dynamic id = message.data['id'];
    if (kDebugMode) {
      print(route);
    }
    if (kDebugMode) {
      print(id);
    }
    switch (route){
      case ('/notification'):
        Navigator.push(context,
            MaterialPageRoute(builder: (context) =>const NotificationScreen()));
        break;
      case ('/upcoming'):
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => UpcomingProductScreen(token: token)));
        break;
      case ('/product'):
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => ProductDetailScreen([],id)));
        break;
      case ('/newlaunched'):
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => ProductDetailScreen([],id)));
        break;
      case ('/offer'):
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const OfferScreen()));
        break;
      case ('/order'):
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => ProductScreen(token: token, isOwner: isOwner)));
        break;
      default:
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const SplashScreen()));
        break;
    }

    // if(message.data['route'] =='/notification'){
    //   print(message.data['route']);
    //   Navigator.push(context,
    //       MaterialPageRoute(builder: (context) => const NotificationScreen()));
    // }

  }

  Future foregroundMessage() async {
    await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );
  }

}
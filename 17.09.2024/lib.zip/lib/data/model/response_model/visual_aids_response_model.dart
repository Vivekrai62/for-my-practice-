// class VisualAidsResponseModel {
//   bool? success;
//   String? message;
//   List<VisualAids>? data;
//
//   VisualAidsResponseModel({this.success, this.message, this.data});
//
//   VisualAidsResponseModel.fromJson(Map<String, dynamic> json) {
//     success = json['success'];
//     message = json['message'];
//     if (json['data'] != null) {
//       data = <VisualAids>[];
//       json['data'].forEach((v) {
//         data!.add(VisualAids.fromJson(v));
//       });
//     }
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = <String, dynamic>{};
//     data['success'] = success;
//     data['message'] = message;
//     if (this.data != null) {
//       data['data'] = this.data!.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }
//
// class VisualAids {
//   String? name;
//   String? url;
//   String? division;
//   String? category;
//   String? type;
//
//   VisualAids({this.name, this.url, this.division, this.category, this.type});
//
//   VisualAids.fromJson(Map<String, dynamic> json) {
//     name = json['name'];
//     url = json['url'];
//     division = json['division'];
//     category = json['category'];
//     type = json['product_type'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = <String, dynamic>{};
//     data['name'] = name;
//     data['url'] = url;
//     data['division'] = division;
//     data['category'] = category;
//     data['product_type'] = type;
//     return data;
//   }
// }

class VisualAidsResponseModel {
  bool? success;
  String? message;
  List<VisualAids>? data;

  VisualAidsResponseModel({this.success, this.message, this.data});

  VisualAidsResponseModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    message = json['message'];
    if (json['data'] != null) {
      data = (json['data'] as List<dynamic>).map((v) => VisualAids.fromJson(v as Map<String, dynamic>)).toList();
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    data['message'] = message;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class VisualAids {
  String? id;
  String? name;
  String? url;
  String? concern;
  List<String>? speciallity; // Changed to List<String>?
  List<String>? division; // Changed to List<String>?
  String? category;
  String? productType;

  VisualAids({
    this.id,
    this.name,
    this.url,
    this.concern,
    this.speciallity,
    this.division,
    this.category,
    this.productType,
  });

  VisualAids.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    url = json['url'];
    concern = json['concern'];
    speciallity = json['speciallity'] != null
        ? List<String>.from(json['speciallity'])
        : null; // Handling list conversion
    division = json['division'] != null
        ? List<String>.from(json['division'])
        : null; // Handling list conversion
    category = json['category'];
    productType = json['productType'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['url'] = url;
    data['concern'] = concern;
    data['speciallity'] = speciallity;
    data['division'] = division;
    data['category'] = category;
    data['productType'] = productType;
    return data;
  }
}

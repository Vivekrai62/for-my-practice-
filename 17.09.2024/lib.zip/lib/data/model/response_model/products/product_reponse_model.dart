class ProductResponseModel {
  bool? success;
  String? message;
  List<Products>? data;

  ProductResponseModel({this.success, this.message, this.data});

  ProductResponseModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    message = json['message'];
    if (json['data'] != null) {
      data = <Products>[];
      json['data'].forEach((v) {
        data!.add(Products.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = this.success;
    data['message'] = this.message;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Products {
  String? id;
  String? name;
  int? score;
  bool? isSpecial;
  int? price;
  String? description;
  String? details;
  List<Images>? images;
  String? technicalDetail;
  int? minOrderQty;
  List<DivisionId>? divisionId;
  String? typeId;
  String? typeName;
  String? categoryId;
  String? categoryName;
  List<SpecialityId>? specialityId;
  String? concernId;
  String? concernName;
  bool? active;
  String? slug;
  String? gst;
  bool? newLaunched;
  List<PackingVarient>? packingVarient;
  int? packingQty;
  String? packing;
  String? packingType;
  bool? upcoming;
  String? sku;
  String? hsnCode;
  String? createdOn;
  String? modifiedOn;
  bool? favourite;

  Products(
      {this.id,
        this.name,
        this.score,
        this.isSpecial,
        this.price,
        this.description,
        this.details,
        this.images,
        this.technicalDetail,
        this.minOrderQty,
        this.divisionId,
        this.typeId,
        this.typeName,
        this.categoryId,
        this.categoryName,
        this.specialityId,
        this.concernId,
        this.concernName,
        this.active,
        this.slug,
        this.gst,
        this.newLaunched,
        this.packingVarient,
        this.packingQty,
        this.packing,
        this.packingType,
        this.upcoming,
        this.sku,
        this.hsnCode,
        this.createdOn,
        this.modifiedOn,
        this.favourite});

  Products.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    score = json['score'];
    isSpecial = json['is_special'];
    price = json['price'];
    description = json['description'];
    details = json['details'];
    if (json['images'] != null) {
      images = <Images>[];
      json['images'].forEach((v) {
        images!.add(Images.fromJson(v));
      });
    }
    technicalDetail = json['technical_detail'];
    minOrderQty = json['min_order_qty'];
    if (json['division_id'] != null) {
      divisionId = <DivisionId>[];
      json['division_id'].forEach((v) {
        divisionId!.add(DivisionId.fromJson(v));
      });
    }
    typeId = json['type_id'];
    typeName = json['type_name'];
    categoryId = json['category_id'];
    categoryName = json['category_name'];
    if (json['speciality_id'] != null) {
      specialityId = <SpecialityId>[];
      json['speciality_id'].forEach((v) {
        specialityId!.add(SpecialityId.fromJson(v));
      });
    }
    concernId = json['concern_id'];
    concernName = json['concern_name'];
    active = json['active'];
    slug = json['slug'];
    gst = json['gst'];
    newLaunched = json['new_launched'];
    if (json['packingVarient'] != null) {
      packingVarient = <PackingVarient>[];
      json['packingVarient'].forEach((v) {
        packingVarient!.add(PackingVarient.fromJson(v));
      });
    }
    packingQty = json['packing_qty'];
    packing = json['packing'];
    packingType = json['packing_type'];
    upcoming = json['upcoming'];
    sku = json['sku'];
    hsnCode = json['hsn_code'];
    createdOn = json['created_on'];
    modifiedOn = json['modified_on'];
    favourite = json['favourite'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = this.id;
    data['name'] = this.name;
    data['score'] = this.score;
    data['is_special'] = this.isSpecial;
    data['price'] = this.price;
    data['description'] = this.description;
    data['details'] = this.details;
    if (this.images != null) {
      data['images'] = this.images!.map((v) => v.toJson()).toList();
    }
    data['technical_detail'] = this.technicalDetail;
    data['min_order_qty'] = this.minOrderQty;
    if (this.divisionId != null) {
      data['division_id'] = this.divisionId!.map((v) => v.toJson()).toList();
    }
    data['type_id'] = this.typeId;
    data['type_name'] = this.typeName;
    data['category_id'] = this.categoryId;
    data['category_name'] = this.categoryName;
    if (this.specialityId != null) {
      data['speciality_id'] = this.specialityId!.map((v) => v.toJson()).toList();
    }
    data['concern_id'] = this.concernId;
    data['concern_name'] = this.concernName;
    data['active'] = this.active;
    data['slug'] = this.slug;
    data['gst'] = this.gst;
    data['new_launched'] = this.newLaunched;
    if (this.packingVarient != null) {
      data['packingVarient'] =
          this.packingVarient!.map((v) => v.toJson()).toList();
    }
    data['packing_qty'] = this.packingQty;
    data['packing'] = this.packing;
    data['packing_type'] = this.packingType;
    data['upcoming'] = this.upcoming;
    data['sku'] = this.sku;
    data['hsn_code'] = this.hsnCode;
    data['created_on'] = this.createdOn;
    data['modified_on'] = this.modifiedOn;
    data['favourite'] = this.favourite;
    return data;
  }
}

class Images {
  String? type;
  String? url;

  Images({this.type, this.url});

  Images.fromJson(Map<String, dynamic> json) {
    type = json['type'];
    url = json['url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['type'] = this.type;
    data['url'] = this.url;
    return data;
  }
}

class DivisionId {
  String? id;
  String? name;

  DivisionId({this.id, this.name});

  DivisionId.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}

class PackingVarient {
  PackingType? packingType;
  String? packing;
  int? packingQty;
  double? price;
  double? baseprice;
  double? saleprice;
  double? gst;
  double? landingprice;

  PackingVarient(
      {this.packingType,
        this.packing,
        this.packingQty,
        this.price,
        this.baseprice,
        this.saleprice,
        this.gst,
        this.landingprice});

  PackingVarient.fromJson(Map<String, dynamic> json) {
    packingType = json['packing_type'] != null
        ? PackingType.fromJson(json['packing_type'])
        : null;
    packing = json['packing'];
    packingQty = json['packing_qty'];
    price = (json['price'] != null) ? json['price'].toDouble() : null;
    baseprice = (json['baseprice'] != null) ? json['baseprice'].toDouble() : null;
    saleprice = (json['saleprice'] != null) ? json['saleprice'].toDouble() : null;
    gst = (json['gst'] != null) ? json['gst'].toDouble() : null;
    landingprice = (json['landingprice'] != null) ? json['landingprice'].toDouble() : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (packingType != null) {
      data['packing_type'] = packingType!.toJson();
    }
    data['packing'] = this.packing;
    data['packing_qty'] = this.packingQty;
    data['price'] = this.price;
    data['baseprice'] = this.baseprice;
    data['saleprice'] = this.saleprice;
    data['gst'] = this.gst;
    data['landingprice'] = this.landingprice;
    return data;
  }
}

class SpecialityId {
  String? id;
  String? name;

  SpecialityId({this.id, this.name});

  SpecialityId.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}

class PackingType {
  String? id;
  String? name;
  String? label;  // Add this field if it is part of your data structure
  String? value;  // Add this field if it is part of your data structure

  PackingType({this.id, this.name, this.label, this.value});  // Update constructor

  PackingType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    label = json['label'];  // Add this line if it is present in your JSON
    value = json['value'];  // Add this line if it is present in your JSON
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = this.id;
    data['name'] = this.name;
    data['label'] = this.label;  // Add this line if you need it in JSON
    data['value'] = this.value;  // Add this line if you need it in JSON
    return data;
  }
}

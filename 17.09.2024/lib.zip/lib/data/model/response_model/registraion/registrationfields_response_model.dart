class RegistrationFieldResponseModel {
  bool? success;
  String? message;
  Data? data;

  RegistrationFieldResponseModel({this.success, this.message, this.data});

  RegistrationFieldResponseModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    message = json['message'];
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    data['message'] = message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  Firm? firm;
  Rep? rep;

  Data({this.firm, this.rep});

  Data.fromJson(Map<String, dynamic> json) {
    firm = json['firm'] != null ? Firm.fromJson(json['firm']) : null;
    rep = json['rep'] != null ? Rep.fromJson(json['rep']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (firm != null) {
      data['firm'] = firm!.toJson();
    }
    if (rep != null) {
      data['rep'] = rep!.toJson();
    }
    return data;
  }
}

class Firm {
  bool? GSTNUMBER;
  bool? DRUGLICENCE;
  bool? PHONE;
  bool? EMAIL;
  bool? ADDRESS;
  bool? DISTRICT;
  bool? STATE;
  bool? BANKACCNO;
  bool? BANKIFSC;
  bool? BANKNAME;
  bool? BANKPAYEENAME;

  Firm(
      {this.GSTNUMBER,
        this.DRUGLICENCE,
        this.PHONE,
        this.EMAIL,
        this.ADDRESS,
        this.DISTRICT,
        this.STATE,
        this.BANKACCNO,
        this.BANKIFSC,
        this.BANKNAME,
        this.BANKPAYEENAME});

  Firm.fromJson(Map<String, dynamic> json) {
    GSTNUMBER = json['GST_NUMBER'];
    DRUGLICENCE = json['DRUG_LICENCE'];
    PHONE = json['PHONE'];
    EMAIL = json['EMAIL'];
    ADDRESS = json['ADDRESS'];
    DISTRICT = json['DISTRICT'];
    STATE = json['STATE'];
    BANKACCNO = json['BANK_ACC_NO'];
    BANKIFSC = json['BANK_IFSC'];
    BANKNAME = json['BANK_NAME'];
    BANKPAYEENAME = json['BANK_PAYEE_NAME'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['GST_NUMBER'] = GSTNUMBER;
    data['DRUG_LICENCE'] = DRUGLICENCE;
    data['PHONE'] = PHONE;
    data['EMAIL'] = EMAIL;
    data['ADDRESS'] = ADDRESS;
    data['DISTRICT'] = DISTRICT;
    data['STATE'] = STATE;
    data['BANK_ACC_NO'] = BANKACCNO;
    data['BANK_IFSC'] = BANKIFSC;
    data['BANK_NAME'] = BANKNAME;
    data['BANK_PAYEE_NAME'] = BANKPAYEENAME;
    return data;
  }
}

class Rep {
  bool? CITY;
  bool? STATE;
  bool? ADDRESS;
  bool? DOB;
  bool? OPAREA;
  bool? JOINEDON;
  bool? AADHARNO;
  bool? PROFILEPIC;

  Rep(
      {this.CITY,
        this.STATE,
        this.ADDRESS,
        this.DOB,
        this.OPAREA,
        this.JOINEDON,
        this.AADHARNO,
        this.PROFILEPIC});

  Rep.fromJson(Map<String, dynamic> json) {
    CITY = json['CITY'];
    STATE = json['STATE'];
    ADDRESS = json['ADDRESS'];
    DOB = json['DOB'];
    OPAREA = json['OP_AREA'];
    JOINEDON = json['JOINED_ON'];
    AADHARNO = json['AADHAR_NO'];
    PROFILEPIC = json['PROFILE_PIC'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['CITY'] = CITY;
    data['STATE'] = STATE;
    data['ADDRESS'] = ADDRESS;
    data['DOB'] = DOB;
    data['OP_AREA'] = OPAREA;
    data['JOINED_ON'] = JOINEDON;
    data['AADHAR_NO'] = AADHARNO;
    data['PROFILE_PIC'] = PROFILEPIC;
    return data;
  }
}
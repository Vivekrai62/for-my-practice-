import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:pharma_clients_app/data/model/response_model/visual_aids_response_model.dart';
import 'package:pharma_clients_app/resources/constant_strings.dart';
import 'package:pharma_clients_app/utils/TextInputFields/text_field.dart';
import 'package:pharma_clients_app/utils/text_style.dart';
import 'package:pharma_clients_app/utils/utils.dart';
import 'package:provider/provider.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../data/response/status.dart';
import '../../resources/app_colors.dart';
import '../../resources/constant_imageString.dart';
import '../../utils/Dialogue/error_dialogue.dart';
import '../../view_model/afterLogin_viewModel/afterLogin_viewModels.dart';

class AddPresentationScreen extends StatefulWidget {
  final PresentationData? presentation; // Make presentation parameter nullable

  const AddPresentationScreen({Key? key, this.presentation}) : super(key: key);

  @override
  State<AddPresentationScreen> createState() => _AddPresentationScreenState();
}

class _AddPresentationScreenState extends State<AddPresentationScreen> {
  VisualAidsViewModel model = VisualAidsViewModel();
  Presentation prefs = Presentation();
  TextEditingController controller = TextEditingController();
  TextEditingController title = TextEditingController();
  FocusNode titleFocusNode = FocusNode();
  bool _hasRunPostFrameCallback = false;

  @override
  void initState() {
    model.fetchVisualAids();
    if (widget.presentation != null) {
      title.text = widget.presentation!.name!;
    }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {


    return Scaffold(
        appBar: AppBar(
          title: TextWithStyle.appBarTitle(context, ConstantStrings.addPresentationHeading),
          elevation: 0,
          toolbarHeight: 6.h,
          centerTitle: false,
          actions: [
            Container(
              margin: const EdgeInsets.only(right: 20, top: 5, bottom: 5),
              child:
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryColor,
                  fixedSize:
                  Size(
                    MediaQuery.of(context).size.width < 600
                        ? MediaQuery.of(context).size.width * 0.23 // Mobile size
                        : MediaQuery.of(context).size.width > 1024

                        ? MediaQuery.of(context).size.width * 0.1
                        : MediaQuery.of(context).size.width * 0.15,  // Tablet size

                    MediaQuery.of(context).size.height < 600
                        ? MediaQuery.of(context).size.height * 0.1 // Mobile height
                        : MediaQuery.of(context).size.height < 1024
                        ? MediaQuery.of(context).size.height * 0.05 // Tablet height
                        : MediaQuery.of(context).size.height * 0.05, // Desktop height
                  ),

                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(34)),
                  ),
                ),
                onPressed: () async {
                  if (model.selectedVisualAids.isNotEmpty && title.text.isNotEmpty) {
                    final presentation = PresentationData(
                      name: title.text,
                      images: model.selectedVisualAids.map((e) =>
                          VisualAids(id: e.id!, name: e.name!, url: e.url!)).toList(),
                    );

                    if (widget.presentation != null) {
                      await prefs.updatePresentation(widget.presentation!.name!, presentation);
                    } else {
                      // Add new presentation
                      await prefs.savePresentation(presentation);
                    }

                    Utils.flushBarSuccessMessage('Presentation Added', context);
                    model.clearSelection();
                    title.clear();
                  } else {
                    if (title.text.isEmpty) {
                      Utils.flushBarErrorMessage("Please Add Title!", context);
                    } else {
                      Utils.flushBarErrorMessage("Please Add VisualAids!", context);
                    }
                  }
                },
                child:
                Text(
                  'Save',
                  style: TextStyle(
                    fontSize: _getResponsiveFontSize(context),
                    color: Colors.white,
                    letterSpacing: MediaQuery.of(context).size.width * 0.001, // Adjust letter spacing
                  ),
                ),

              )

            )
          ],
        ),
        body:
        Container(
          margin: EdgeInsets.only(left: 1.5.h, right: 1.5.h),
          child: Column(
            children: [
              Container(
                alignment: Alignment.topLeft,
                margin: EdgeInsets.only(top: 0.5.h,bottom: 1.2.h),
                child: TextWithStyle.containerTitle(context, 'Title of Presentation:'),
              ),

              TextInputField(
                title: title,
                node: titleFocusNode,
                hintText: 'Enter Title',
                labelText: 'Title',
                icon: Icons.edit_note,
              ),


              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextWithStyle.containerTitle(context,'Select Images:'),
                  InkWell(
                    onTap: (){
                      model.clearSelection();
                    },
                    child: TextWithStyle.containerTitle(context,'Clear'),
                  )
                ],
              ),
              Row(
                children: [
                  Expanded(
                      child: Container(
                        margin: EdgeInsets.only(top: 2.w,bottom: 2.w),
                        child: TextFormField(
                          style: TextStyle(fontSize: 16.sp),
                          controller: controller,
                          onChanged: (value){
                            model.filteredVisuals(value.toLowerCase(),[],[],[],[],[]);
                          },
                          decoration: InputDecoration(
                              filled: true,
                              fillColor: AppColors.primaryColor.withOpacity(0.05),
                              enabledBorder: OutlineInputBorder(
                                  borderRadius:
                                  const BorderRadius.all(Radius.circular(15)),
                                  borderSide: BorderSide(color: AppColors.backgroundColor)),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius:
                                  const BorderRadius.all(Radius.circular(15)),
                                  borderSide: BorderSide(color: AppColors.backgroundColor)),
                              contentPadding: EdgeInsets.all(2.h),
                              prefixIcon: Padding(
                                padding: EdgeInsets.symmetric(
                                  horizontal: MediaQuery.of(context).size.width * 0.03, // Responsive horizontal padding
                                ),
                                child: Image.asset(
                                  ConstantImage.search,
                                  width: MediaQuery.of(context).size.width * 0.05, // Responsive icon width
                                ),
                              ),

                              border: InputBorder.none,
                              hintText: "Search..",
                              hintStyle: const TextStyle(color: Colors.black38)
                          ),
                        ),
                      )),
                  IconButton(
                      onPressed: (){
                        showModalBottomSheet(
                          context: context,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(top: Radius.circular(16.0)),
                          ),
                          backgroundColor: Colors.white,
                          isScrollControlled: true,
                          builder: (BuildContext context) {
                            return ChangeNotifierProvider.value(
                              value: model,
                              child: Consumer<VisualAidsViewModel>(
                                builder: (context, value, _) {
                                  return Container(
                                    height: MediaQuery.of(context).size.height * 0.8,
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          padding: EdgeInsets.only(left: 2.h,top: 2.h,),
                                          child: TextWithStyle.productTitle(context, 'Filters'),
                                        ),
                                        Divider(
                                          color: Colors.black.withOpacity(0.1),
                                        ),
                                        Expanded(
                                          child: Row(
                                            children: [
                                              Container(
                                                width: MediaQuery.of(context).size.width / 3,
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.only(topLeft: Radius.circular(2.h)),
                                                ),
                                                child: ListView(
                                                  children: value.filterOptions.keys.map((category) {
                                                    final bool isSelected = category == value.selectedCategory;
                                                    final selectedCount = value.getSelectedCount(category);
                                                    return GestureDetector(
                                                      onTap: () {
                                                        value.selectCategory(category);
                                                      },
                                                      child: Container(
                                                        color: isSelected ? AppColors.primaryColor : Colors.transparent,
                                                        child: ListTile(
                                                          title: Text(
                                                            '${category} ${selectedCount == 0 ? '' : '(${selectedCount})'}',
                                                            style: TextStyle(
                                                              color: isSelected ? Colors.white : Colors.black,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    );
                                                  }).toList(),
                                                ),
                                              ),
                                              VerticalDivider(
                                                color: Colors.black.withOpacity(0.1),
                                                width: 1,
                                              ),
                                              Expanded(
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Padding(
                                                      padding: const EdgeInsets.only(left: 8.0,right: 8.0,bottom: 8.0),
                                                      child: TextField(
                                                        decoration: InputDecoration(
                                                            filled: true,
                                                            fillColor: AppColors.primaryColor
                                                                .withOpacity(0.05),
                                                            enabledBorder: OutlineInputBorder(
                                                                borderRadius:
                                                                const BorderRadius.all(
                                                                    Radius.circular(15)),
                                                                borderSide: BorderSide(
                                                                    color: AppColors
                                                                        .backgroundColor)),
                                                            focusedBorder: OutlineInputBorder(
                                                                borderRadius: const BorderRadius
                                                                    .all(Radius.circular(15)),
                                                                borderSide: BorderSide(
                                                                    color: AppColors
                                                                        .backgroundColor)),
                                                            contentPadding: EdgeInsets.all(2.h),
                                                            prefixIcon: Padding(
                                                              padding: EdgeInsets.only(
                                                                  left: 1.4.h, right: 1.4.h),
                                                              child: Image.asset(
                                                                  "assets/images/png/search.png",
                                                                  width: 2.h),
                                                            ),
                                                            border: InputBorder.none,
                                                            hintText: "Search",
                                                            hintStyle: const TextStyle(
                                                                color: Colors.black38)
                                                        ),
                                                        onChanged: value.updateSearchText,
                                                      ),
                                                    ),
                                                    Expanded(
                                                      child: ListView(
                                                        padding: EdgeInsets.only(left: 10),
                                                        children: value.getFilteredOptions().map((option) {
                                                          final isSelected = value.selectedFilters[value.selectedCategory]?.contains(option) == true;
                                                          return Column(
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              FilterChip(
                                                                label: Text(option),
                                                                backgroundColor: Colors.white,
                                                                selectedColor: AppColors.primaryColor.withOpacity(0.05),
                                                                selected: isSelected,
                                                                onSelected: (_) => value.toggleFilterOption(value.selectedCategory, option),
                                                              ),
                                                            ],
                                                          );
                                                        }).toList(),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Divider(
                                          color: Colors.black.withOpacity(0.1),
                                        ),
                                        Container(
                                          padding: EdgeInsets.only(bottom: 3.h,right: 2.h,left: 2.h,top: 0.5.h),
                                          color: Colors.white,
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              OutlinedButton(
                                                  onPressed: value.clearFilters,
                                                  style: OutlinedButton.styleFrom(
                                                      backgroundColor: Colors.white,
                                                      minimumSize: Size(MediaQuery
                                                          .of(context)
                                                          .size
                                                          .width / 3,
                                                          MediaQuery
                                                              .of(context)
                                                              .size
                                                              .height / 17),
                                                      shape: RoundedRectangleBorder(
                                                          borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(4.h)))
                                                  ),
                                                  child: Text('Clear',
                                                      style: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 17.sp,
                                                          fontWeight: FontWeight.w400))
                                              ),
                                              ElevatedButton(
                                                onPressed: () {
                                                  value.applyFilters();
                                                  print('Selected Filters: ${value.selectedFilters}');
                                                  Navigator.of(context).pop();
                                                },
                                                style: ElevatedButton.styleFrom(
                                                    backgroundColor: AppColors.primaryColor,
                                                    minimumSize: Size(MediaQuery
                                                        .of(context)
                                                        .size
                                                        .width / 3,
                                                        MediaQuery
                                                            .of(context)
                                                            .size
                                                            .height / 17),
                                                    shape: RoundedRectangleBorder(
                                                        borderRadius:
                                                        BorderRadius.all(
                                                            Radius.circular(4.h)))
                                                ),
                                                child: Text('Apply',
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 17.sp,
                                                        fontWeight: FontWeight.w400)),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                        );
                      },
                      icon: Icon(CupertinoIcons.slider_horizontal_3,
                        size:
                        MediaQuery.of(context).size.width >= 1024
                            ? MediaQuery.of(context).size.width * 0.05 // Desktop (5% of width)
                            : MediaQuery.of(context).size.width >= 600
                            ? MediaQuery.of(context).size.width * 0.03 // Tablet (6% of width)
                            : MediaQuery.of(context).size.width * 0.07, // Mobile (7% of width)


                      ))
                ],
              ),
              Expanded(
              child: ChangeNotifierProvider<VisualAidsViewModel>(
                create: (BuildContext context) => model,
                child: Consumer<VisualAidsViewModel>(
                  builder: (context,value,_){
                    switch(value.visualaidsList.status!){
                      case Status.loading:
                        return Container(
                          height: MediaQuery.of(context).size.height,
                          width: MediaQuery.of(context).size.width,
                          color: AppColors.backgroundColor,
                          child: Center(
                              child: LoadingAnimationWidget.discreteCircle(
                                  color: AppColors.primaryColor,
                                  size: 40)
                          ),
                        );
                      case Status.error:
                        return ErrorDialogue(message: value.visualaidsList.message);
                      case Status.completed:
                        if (widget.presentation != null && !_hasRunPostFrameCallback) {
                          _hasRunPostFrameCallback = true;
                          WidgetsBinding.instance.addPostFrameCallback((_) {
                            for (var image in widget.presentation!.images!) {
                              final visualAid = value.visualAids.firstWhere(
                                    (aid) => aid.id == image.id,
                                orElse: () => VisualAids(id: '', name: '', url: ''),
                              );
                              if (visualAid.id!.isNotEmpty) {
                                print(visualAid.id);
                                value.toggleSelection(visualAid);
                              }
                            }
                          });
                        }
                        return value.visualAids.isNotEmpty
                            ?
                        GridView.builder(
                          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: MediaQuery.of(context).size.width >= 600 ? 3 : 2, // 3 items per row on tablets, 2 items per row on mobile
                            crossAxisSpacing: 8.0, // Adjust spacing between items as needed
                            mainAxisSpacing: 8.0, // Adjust spacing between items as needed
                          ),
                          itemCount: value.visualAids.length,
                          itemBuilder: (context, index) {
                            final visualAid = value.visualAids[index];
                            final isSelected = value.isSelected(value.visualAids[index]);
                            return InkWell(
                              onTap: () => value.toggleSelection(visualAid),
                              child: Card(
                                margin: EdgeInsets.only(left: 8.0, right: 8.0, top: 16.0), // Adjust margins as needed
                                elevation: 4.0, // Adjust elevation as needed
                                shadowColor: Colors.black54,
                                surfaceTintColor: Colors.white,
                                color: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.all(Radius.circular(8.0)), // Adjust border radius as needed
                                ),
                                child: Stack(
                                  alignment: Alignment.topRight,
                                  children: [
                                    Center(
                                      child: FadeInImage.assetNetwork(
                                        placeholder: 'assets/images/png/loading.gif',
                                        image: '${visualAid.url}',
                                        fit: BoxFit.cover, // Ensure image covers the card
                                      ),
                                    ),
                                    if (isSelected)
                                      Container(
                                        margin: EdgeInsets.only(
                                          right: MediaQuery.of(context).size.width >= 800 ? 16.0 : 8.0, // Adjust margin for tablets and mobiles
                                        ),
                                        child: Icon(
                                          CupertinoIcons.check_mark_circled_solid,
                                          color: AppColors.primaryColor,
                                          size: MediaQuery.of(context).size.width >= 800 ? 45.0 : 24.0, // Bigger icon size for tablets
                                        ),
                                      )

                                  ],
                                ),
                              ),
                            );
                          },
                        )

                            : Center(
                              child: SingleChildScrollView(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Image.asset(ConstantImage.empty,
                                      width: 70.w,
                                      //height: 30.h,
                                      fit: BoxFit.fill,),
                                    SizedBox(height: 2.h),
                                    TextWithStyle.appBarTitle(context, ConstantStrings.emptyScreen)
                                  ],
                                ),
                              ),
                            );}
                  },
                ),
              ),
            ),
          ],
        ),
      )
    );
  }
}
double _getResponsiveFontSize(BuildContext context) {
  double screenWidth = MediaQuery.of(context).size.width;

  if (screenWidth < 600) {
    // Mobile screen
    return screenWidth * 0.04; // Smaller font size

  } else if (screenWidth >= 600 && screenWidth < 1024) {
    // Tablet screens
    return screenWidth * 0.02; // Medium font size

  } else {
    // Desktop screens
    return screenWidth * 0.03; // Larger font size it also support for table
  }
}


// class Presentation extends ChangeNotifier {
//
//   int _count = 0;
//   int get count => _count;
//
//   Future<void> savePresentation(PresentationData presentation) async {
//     final prefs = await SharedPreferences.getInstance();
//     final presentations = prefs.getStringList('presentations') ?? [];
//
//     final presentationMap = presentation.toMap();
//     final encodedPresentation = json.encode(presentationMap);
//
//     final index = presentations.indexWhere((element) {
//       final map = json.decode(element) as Map<String, dynamic>;
//       return map['name'] == presentationMap['name'];
//     });
//
//     if (index >= 0) {
//       presentations[index] = encodedPresentation;
//     } else {
//       presentations.add(encodedPresentation);
//     }
//
//     await prefs.setStringList('presentations', presentations);
//     notifyListeners();
//   }
//
//   Future<List<PresentationData>> loadPresentations() async {
//     final prefs = await SharedPreferences.getInstance();
//     final presentations = prefs.getStringList('presentations') ?? [];
//     return presentations
//         .map((e) => PresentationData.fromMap(json.decode(e) as Map<String, dynamic>))
//         .toList();
//   }
//
//   Future<void> removepresentation(String presentationName) async {
//     final prefs = await SharedPreferences.getInstance();
//     final presentations = prefs.getStringList('presentations') ?? [];
//
//     final index = presentations.indexWhere((element) {
//       final map = json.decode(element) as Map<String, dynamic>;
//       return map['name'] == presentationName;
//     });
//
//     if (index >= 0) {
//       presentations.removeAt(index);
//       await prefs.setStringList('presentations', presentations);
//     }
//     notifyListeners();
//   }
//
//   Future<void> updatePresentation(String oldName, PresentationData updatedPresentation) async {
//     final prefs = await SharedPreferences.getInstance();
//     final presentations = prefs.getStringList('presentations') ?? [];
//
//     final updatedPresentationMap = updatedPresentation.toMap();
//     final encodedUpdatedPresentation = json.encode(updatedPresentationMap);
//
//     final index = presentations.indexWhere((element) {
//       final map = json.decode(element) as Map<String, dynamic>;
//       return map['name'] == oldName;
//     });
//
//     if (index >= 0) {
//       final existingPresentationMap = json.decode(presentations[index]) as Map<String, dynamic>;
//
//       // Update name if changed
//       existingPresentationMap['name'] = updatedPresentationMap['name'];
//
//       // Convert existing images to List<VisualAids>
//       List<VisualAids> existingImages = (existingPresentationMap['images'] as List<dynamic>)
//           .map((image) => VisualAids.fromJson(image))
//           .toList();
//
//       // Get updated images
//       List<VisualAids> updatedImages = (updatedPresentation.images ?? []);
//
//       // Determine new images to add
//       final newImages = updatedImages.where((updatedImage) {
//         return !existingImages.any((existingImage) {
//           return existingImage.id == updatedImage.id;
//         });
//       }).toList();
//
//       // Determine images to remove
//       final imagesToRemove = existingImages.where((existingImage) {
//         return !updatedImages.any((updatedImage) {
//           return updatedImage.id == existingImage.id;
//         });
//       }).toList();
//
//       // Remove unselected images from the existing list
//       for (var image in imagesToRemove) {
//         existingImages.removeWhere((existingImage) => existingImage.id == image.id);
//       }
//
//       // Add new images to the existing list
//       existingImages.addAll(newImages);
//
//       // Update the existing presentation map with the new images list
//       existingPresentationMap['images'] = existingImages.map((image) => image.toJson()).toList();
//
//       // Save the updated presentation list
//       presentations[index] = json.encode(existingPresentationMap);
//       await prefs.setStringList('presentations', presentations);
//     }
//     getImageCount();
//     notifyListeners();
//   }
//
//   Future<bool> removePresentation() async {
//     final prefs = await SharedPreferences.getInstance();
//     prefs.remove('presentations');
//     notifyListeners();
//     return true;
//   }
//
//   Future<int> getImageCount() async {
//     final presentations = await loadPresentations();
//     for (var presentation in presentations) {
//       _count += presentation.images?.length ?? 0;
//     }
//     return _count;
//   }
// }

class Presentation extends ChangeNotifier {
  List<PresentationData> _presentations = [];
  List<PresentationData> get presentations => _presentations;

  int _count = 0;
  int get count => _count;

  Future<void> savePresentation(PresentationData presentation) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> presentations = prefs.getStringList('presentations') ?? [];

    final presentationMap = presentation.toMap();
    final encodedPresentation = json.encode(presentationMap);

    final index = presentations.indexWhere((element) {
      final map = json.decode(element) as Map<String, dynamic>;
      return map['name'] == presentationMap['name'];
    });

    if (index >= 0) {
      presentations[index] = encodedPresentation;
    } else {
      presentations.add(encodedPresentation);
    }

    await prefs.setStringList('presentations', presentations);
    await loadPresentations(); // Ensure _presentations is updated
  }

  Future<void> loadPresentations() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> presentations = prefs.getStringList('presentations') ?? [];

    _presentations = presentations
        .map((e) => PresentationData.fromMap(json.decode(e) as Map<String, dynamic>))
        .toList();

    _count = _presentations.fold(0, (sum, item) => sum + (item.images?.length ?? 0));
    notifyListeners();
  }

  Future<void> removePresentation(String presentationName) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> presentations = prefs.getStringList('presentations') ?? [];

    final index = presentations.indexWhere((element) {
      final map = json.decode(element) as Map<String, dynamic>;
      return map['name'] == presentationName;
    });

    if (index >= 0) {
      presentations.removeAt(index);
      await prefs.setStringList('presentations', presentations);
      await loadPresentations(); // Ensure _presentations is updated
    }
  }

  Future<void> updatePresentation(String oldName, PresentationData updatedPresentation) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> presentations = prefs.getStringList('presentations') ?? [];

    final updatedPresentationMap = updatedPresentation.toMap();
    final encodedUpdatedPresentation = json.encode(updatedPresentationMap);

    final index = presentations.indexWhere((element) {
      final map = json.decode(element) as Map<String, dynamic>;
      return map['name'] == oldName;
    });

    if (index >= 0) {
      final existingPresentationMap = json.decode(presentations[index]) as Map<String, dynamic>;

      // Update name if changed
      existingPresentationMap['name'] = updatedPresentationMap['name'];

      // Convert existing images to List<dynamic>
      List<dynamic> existingImages = existingPresentationMap['images'] ?? [];
      List<dynamic> updatedImages = updatedPresentation.images?.map((image) => image.toJson()).toList() ?? [];

      // Determine new images to add
      final newImages = updatedImages.where((updatedImage) {
        return !existingImages.any((existingImage) {
          return existingImage['id'] == updatedImage['id'];
        });
      }).toList();

      // Determine images to remove
      final imagesToRemove = existingImages.where((existingImage) {
        return !updatedImages.any((updatedImage) {
          return updatedImage['id'] == existingImage['id'];
        });
      }).toList();

      // Remove unselected images from the existing list
      for (var image in imagesToRemove) {
        existingImages.removeWhere((existingImage) => existingImage['id'] == image['id']);
      }

      // Add new images to the existing list
      existingImages.addAll(newImages);

      // Update the existing presentation map with the new images list
      existingPresentationMap['images'] = existingImages;

      // Save the updated presentation list
      presentations[index] = json.encode(existingPresentationMap);
      await prefs.setStringList('presentations', presentations);
      await loadPresentations(); // Ensure _presentations is updated
    }
  }

  Future<void> clearPresentations() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('presentations');
    _presentations.clear();
    _count = 0;
    notifyListeners();
  }

}
class PresentationData {
  String? name;
  List<VisualAids>? images;

  PresentationData({this.name, this.images});

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'images': images?.map((image) => image.toJson()).toList(),
    };
  }

  PresentationData.fromMap(Map<String, dynamic> map) {
    name = map['name'];
    if (map['images'] != null) {
      images = List<VisualAids>.from(map['images'].map((image) => VisualAids.fromJson(image)));
    } else {
      images = [];
    }
  }
}

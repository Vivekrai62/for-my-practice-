import 'dart:async';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:photo_view/photo_view.dart';
import 'package:photo_view/photo_view_gallery.dart';
import 'package:provider/provider.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'addPresentationScreen.dart';
import '../../resources/app_colors.dart'; // Ensure correct path
import '../../resources/constant_strings.dart'; // Ensure correct path
import '../../utils/text_style.dart'; // Ensure correct path

class PresentationListScreen extends StatefulWidget {
  @override
  State<PresentationListScreen> createState() => _PresentationListScreenState();
}

class _PresentationListScreenState extends State<PresentationListScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        surfaceTintColor: AppColors.backgroundColor,
        backgroundColor: AppColors.backgroundColor,
        centerTitle: false,
        scrolledUnderElevation: 0,
        title: TextWithStyle.appBarTitle(context, ConstantStrings.presentationHeading),
        elevation: 10,
        toolbarHeight: 6.h,
      ),
      body: Consumer<Presentation>(
        builder: (BuildContext context, presentationProvider, Widget? child) {
          return FutureBuilder(
            future: presentationProvider.loadPresentations(),
            builder: (context, snapshot) {
              return presentationProvider.presentations.isEmpty
                  ? Center(
                child: Text('No presentations found.'),
              )
                  :
              ListView.builder(
                itemCount: presentationProvider.presentations.length,
                itemBuilder: (context, index) {
                  final presentation = presentationProvider.presentations[index];
                  return Container(
                    margin: EdgeInsets.only(left: 1.h, right: 1.h, top: 1.5.h),
                    padding: EdgeInsets.only(left: 2.h, bottom: 0.5.h),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(1.h)),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.primaryColor.withOpacity(0.3),
                          spreadRadius: 0.1,
                          blurRadius: 0.1,
                          offset: const Offset(0, 0),
                        ),
                      ],
                    ),
                    child: ListTile(
                      title: Text(presentation.name?.toString() ?? 'No Title'),
                      titleTextStyle: TextStyle(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w500,
                        letterSpacing: -0.3,
                        color: Colors.black,
                      ),
                      subtitle: TextWithStyle.productDescription(
                        context,
                        '${presentation.images?.length ?? 0} ${presentation.images?.length == 1 ? 'Slide' : 'Slides'}',
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PresentationScreen(
                              presentation: presentation,
                            ),
                          ),
                        );
                      },
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          GestureDetector(
                            child: FaIcon(FontAwesomeIcons.penToSquare, size: 5.w),
                            onTap: () async {
                              final updatedPresentation = await Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => AddPresentationScreen(
                                    presentation: presentation,
                                  ),
                                ),
                              );
                              if (updatedPresentation != null) {
                                presentationProvider.updatePresentation(presentation.name!, updatedPresentation);
                              }
                            },
                          ),
                          SizedBox(width: 5),
                          IconButton(
                            onPressed: () {
                              presentationProvider.removePresentation(presentation.name!);
                            },
                            icon: FaIcon(FontAwesomeIcons.trashCan, size: 5.w),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}



class PresentationScreen extends StatelessWidget {
  final PresentationData presentation;

  const PresentationScreen({Key? key, required this.presentation}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        title: TextWithStyle.appBarTitle(context, presentation.name!),
        elevation: 0,
      ),
      body: presentation.images != null && presentation.images!.isNotEmpty
          ? PhotoViewGallery.builder(
        itemCount: presentation.images!.length,
        builder: (context, index) {
          final imageUrl = presentation.images![index].url!;
          return PhotoViewGalleryPageOptions.customChild(
            child: FutureBuilder<Size>(
              future: _getImageDimensions(imageUrl),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.done) {
                  if (snapshot.hasError) {
                    return Center(child: Text('Error loading image'));
                  }
                  final size = snapshot.data!;
                  final isPortrait = size.height > size.width;
                  return Transform.rotate(
                    angle: isPortrait ? 0 : 3.14 / 2, // Rotate 90 degrees if landscape
                    child: PhotoView(
                      imageProvider: CachedNetworkImageProvider(imageUrl),
                      backgroundDecoration: const BoxDecoration(
                        color: Colors.white,
                      ),
                    ),
                  );
                } else {
                  return const Center(child: CircularProgressIndicator());
                }
              },
            ),
            heroAttributes: PhotoViewHeroAttributes(tag: imageUrl),
          );
        },
        backgroundDecoration: const BoxDecoration(
          color: Colors.white,
        ),
      )
          : const Center(
        child: Text('No images available'),
      ),
    );
  }

  Future<Size> _getImageDimensions(String url) async {
    final Completer<Size> completer = Completer();
    final Image image = Image.network(url);
    image.image.resolve(const ImageConfiguration()).addListener(
      ImageStreamListener((ImageInfo info, bool _) {
        final myImage = info.image;
        final size = Size(myImage.width.toDouble(), myImage.height.toDouble());
        completer.complete(size);
      }),
    );
    return completer.future;
  }

}
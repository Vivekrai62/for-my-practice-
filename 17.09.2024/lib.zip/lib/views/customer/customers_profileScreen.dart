import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:pharma_clients_app/data/model/response_model/customers/customers_responseModel.dart';
import 'package:provider/provider.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import '../../data/model/requested_data_model/customer/updateCustomerEntity.dart';
import '../../resources/app_colors.dart';
import '../../resources/constant_strings.dart';
import '../../utils/TextInputFields/password_inputField.dart';
import '../../utils/TextInputFields/text_field.dart';
import '../../utils/text_style.dart';
import '../../view_model/afterLogin_viewModel/afterLogin_viewModels.dart';

class CustomersProfileScreen extends StatefulWidget {
  final List<Customers> profile;

  const CustomersProfileScreen({Key? key, required this.profile}) : super(key: key);

  @override
  State<CustomersProfileScreen> createState() => _CustomersProfileScreenState();
}

class _CustomersProfileScreenState extends State<CustomersProfileScreen> {
  late TextEditingController name;
  late TextEditingController email;
  late TextEditingController phone;
  late TextEditingController address;
  late TextEditingController profession;
  late TextEditingController hospitalName;
  late TextEditingController dob;
  late TextEditingController weddingDate;

  late FocusNode nameFocusNode;
  late FocusNode emailFocusNode;
  late FocusNode phoneFocusNode;
  late FocusNode addressFocusNode;
  late FocusNode professionFocusNode;
  late FocusNode stateFocusNode;
  late FocusNode cityFocusNode;
  late FocusNode hospitalNameFocusNode;
  late FocusNode dobFocusNode;
  late FocusNode weddingDateFocusNode;

  final StatesViewModel stateModel = StatesViewModel();
  final CitiesViewModel citiesModel = CitiesViewModel();

  final _formKey = GlobalKey<FormState>();
  late DateTime selectedTime;
  late String currentTime;

  String? newState;
  String? newCity;
  var state;
  var city;
  int _selectedCityIndex = 0;

  @override
  void initState() {
    super.initState();

    stateModel.states(context);
    selectedTime = DateTime.now();
    currentTime = '${DateTime.now().hour + DateTime.now().second}';

    name = TextEditingController(text: widget.profile[0].name ?? 'NA');
    email = TextEditingController(text: widget.profile[0].email ?? 'NA');
    phone = TextEditingController();
    address = TextEditingController(text: widget.profile[0].address ?? 'NA');
    profession = TextEditingController(text: widget.profile[0].profession ?? 'NA');
    hospitalName = TextEditingController(text: widget.profile[0].workingPlace ?? 'NA');
    newState = widget.profile[0].state?? 'NA';
    newCity = widget.profile[0].city?? 'NA';
    dob = TextEditingController(text: widget.profile[0].dob ?? 'NA');
    weddingDate = TextEditingController(text: widget.profile[0].weddingAnniversary ?? 'NA');

    nameFocusNode = FocusNode();
    emailFocusNode = FocusNode();
    phoneFocusNode = FocusNode();
    addressFocusNode = FocusNode();
    professionFocusNode = FocusNode();
    stateFocusNode = FocusNode();
    cityFocusNode = FocusNode();
    hospitalNameFocusNode = FocusNode();
    dobFocusNode = FocusNode();
    weddingDateFocusNode = FocusNode();

    _cleanPhoneNumber();
  }

  void _cleanPhoneNumber() {
    StringBuffer sb = StringBuffer();
    if (widget.profile[0].phone != null) {
      String cleanedPhoneNumber = widget.profile[0].phone!.toString().replaceAll(RegExp(r'\D'), '');
      if (cleanedPhoneNumber.length <= 10) {
        phone.text = cleanedPhoneNumber;
      } else {
        if (cleanedPhoneNumber.startsWith('91')) {
          cleanedPhoneNumber = cleanedPhoneNumber.substring(2);
        } else if (cleanedPhoneNumber.startsWith('+91')) {
          cleanedPhoneNumber = cleanedPhoneNumber.substring(3);
        }
        phone.text = cleanedPhoneNumber;
      }
    }
  }

  @override
  void dispose() {
    widget.profile.clear();

    name.dispose();
    email.dispose();
    phone.dispose();
    address.dispose();
    profession.dispose();
    hospitalName.dispose();
    dob.dispose();
    weddingDate.dispose();

    nameFocusNode.dispose();
    emailFocusNode.dispose();
    phoneFocusNode.dispose();
    addressFocusNode.dispose();
    professionFocusNode.dispose();
    stateFocusNode.dispose();
    cityFocusNode.dispose();
    hospitalNameFocusNode.dispose();
    dobFocusNode.dispose();
    weddingDateFocusNode.dispose();

    super.dispose();
  }

  Future<void> _selectDate(BuildContext context, TextEditingController controller) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selectedTime,
        firstDate: DateTime(1900, 1),
        lastDate: DateTime(2101));
    if (picked != null && picked != selectedTime) {
      setState(() {
        selectedTime = picked;
        controller.text = DateFormat.yMMMd().format(selectedTime);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double iconSize = screenWidth < 600
        ? screenWidth * 0.07  // For mobile devices
        : screenWidth * 0.03; // For tablets

    double fontSize = screenWidth < 600
        ? screenWidth * 0.05  // For mobile devices
        : screenWidth * 0.027; // For tablets

    print('run');
    final update = Provider.of<AddCustomerViewModel>(context, listen: false);

    return Scaffold(
      appBar: AppBar(
        // automaticallyImplyLeading: false,

        centerTitle: false,
        elevation: 0,
        title: TextWithStyle.appBarTitle(context, ConstantStrings.customerProfileHeading),
      ),
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              SizedBox(height: 1.h),
              ProfileFormContainer(
                children: [
                  TextInputField(
                    title: name,
                    node: nameFocusNode,
                    hintText: 'Enter your name',
                    labelText: 'Name',
                    icon: CupertinoIcons.person,
                    validator: (value) => value!.isEmpty ? 'Please enter your Name' : null,
                  ),
                  TextInputField(
                    title: email,
                    node: emailFocusNode,
                    icon: CupertinoIcons.mail,
                    hintText: 'Enter your email',
                    labelText: 'Email',
                    validator: (value) => value!.isEmpty ? 'Please enter your Email' : null,
                  ),
                  PhoneNumberField(
                    controller: phone,
                    focusNode: phoneFocusNode,
                    hintText: 'Enter your phone number',
                    labelText: 'Phone',
                  ),
                  SizedBox(height: 1.h),
                  TextInputField(
                    title: address,
                    node: addressFocusNode,
                    icon: CupertinoIcons.placemark,
                    hintText: 'Enter your Address',
                    labelText: 'Address',
                    validator: (value) => value!.isEmpty ? 'Please enter your Address' : null,
                  ),
                  TextInputField(
                    title: profession,
                    node: professionFocusNode,
                    icon: CupertinoIcons.briefcase,
                    hintText: 'Enter your profession',
                    labelText: 'Profession',
                    validator: (value) => value!.isEmpty ? 'Please enter your Profession' : null,
                  ),

                  ChangeNotifierProvider<StatesViewModel>(
                    create: (BuildContext context) => stateModel,
                    child: Consumer<StatesViewModel>(
                      builder: (BuildContext context, value, Widget? child) {
                        return DropdownButtonFormField(
                          value: state,
                          elevation: 8,
                          borderRadius: BorderRadius.all(Radius.circular(2.h)),
                          menuMaxHeight: 40.h,
                          style: TextStyle(
                            fontSize: 16.sp,
                            color: Colors.black,
                          ),
                          decoration: InputDecoration(
                            enabledBorder: OutlineInputBorder(
                              borderRadius: const BorderRadius.all(Radius.circular(10)),
                              borderSide: BorderSide(color: AppColors.primaryColor),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: const BorderRadius.all(Radius.circular(10)),
                              borderSide: BorderSide(color: AppColors.primaryColor),
                            ),
                            errorBorder: OutlineInputBorder(
                              borderRadius: const BorderRadius.all(Radius.circular(10)),
                              borderSide: BorderSide(color: Colors.red.shade700),
                            ),
                            focusedErrorBorder: OutlineInputBorder(
                              borderRadius: const BorderRadius.all(Radius.circular(10)),
                              borderSide: BorderSide(color: Colors.red.shade700),
                            ),
                            contentPadding: const EdgeInsets.fromLTRB(0, 15, 10, 15),
                            prefixIcon: Padding(
                              padding: EdgeInsets.all(MediaQuery.of(context).size.width > 600 ? 10 : 8),
                              child: Icon(
                                Icons.add_home_work_sharp,
                                size: iconSize,
                              ),
                            ),
                            hintText: 'Enter your State',
                            labelText: 'State',
                            labelStyle: TextStyle(
                              color: Colors.black,
                              fontSize: MediaQuery.of(context).size.width > 600 ? 19 : 16,
                            ),
                          ),
                          items: value.state.map<DropdownMenuItem>((value) {
                            return DropdownMenuItem(
                              value: value,
                              child: Text(
                                value.name!,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: MediaQuery.of(context).size.width > 600 ? 20 : 16,
                                ),
                              ),
                            );
                          }).toList(),
                          onChanged: (newValue) {
                            state = newValue;
                            citiesModel.cities(state!.id, context);
                          },
                          validator: (value) {
                            if (state == null) {
                              return 'Please enter your State';
                            }
                            return null;
                          },
                          isExpanded: true,
                        );
                      },
                    ),
                  ),

                  SizedBox(
                      height: 2.h,
                    ),
                  ChangeNotifierProvider<CitiesViewModel>(
                    create: (BuildContext context) => citiesModel,
                    child: Consumer<CitiesViewModel>(
                      builder: (BuildContext context, value, Widget? child) {
                        return Container(
                          width: MediaQuery.of(context).size.width * 0.9, // Ensure the width is within bounds
                          child: DropdownButtonFormField(
                            hint: Text(
                              'Enter your Cities',
                              style: const TextStyle(color: Colors.black),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 2,
                            ),
                            value: value.city.isEmpty ? 'NA' : value.city[_selectedCityIndex],
                            elevation: 8,
                            borderRadius: BorderRadius.circular(12),
                            menuMaxHeight: MediaQuery.of(context).size.height * 0.4, // Adjust the height if necessary
                            style: TextStyle(
                              fontSize: MediaQuery.of(context).textScaleFactor * 18,
                              color: Colors.black,
                            ),
                            decoration: InputDecoration(
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide(color: AppColors.primaryColor),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide(color: AppColors.primaryColor),
                              ),
                              errorBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide(color: Colors.red.shade700),
                              ),
                              focusedErrorBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide(color: Colors.red.shade700),
                              ),
                              border: InputBorder.none,
                              prefixIcon: Padding(
                                padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.02),
                                child: Icon(
                                  CupertinoIcons.house_alt_fill,
                                  size: MediaQuery.of(context).textScaleFactor * 24,
                                ),
                              ),
                              contentPadding: const EdgeInsets.fromLTRB(0, 15, 10, 15),
                              hintText: 'Enter your Cities',
                              labelText: 'Cities',
                              labelStyle: TextStyle(
                                fontSize: MediaQuery.of(context).textScaleFactor * 18,
                                color: Colors.black,
                              ),
                            ),
                            items: value.city.map<DropdownMenuItem>((val) {
                              return DropdownMenuItem(
                                value: val,
                                child: Text(
                                  val,
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 2,
                                ),
                              );
                            }).toList(),
                            onChanged: (val) {
                              city = val;
                            },
                            validator: (val) {
                              if (val == null) {
                                return 'Please enter your City';
                              }
                              return null;
                            },
                          ),
                        );
                      },
                    ),
                  ),


                  SizedBox(
                    height: 2.h,
                  ),
                  TextInputField(
                    title: hospitalName,
                    node: hospitalNameFocusNode,
                    icon: Icons.home_work_outlined,
                    hintText: 'Enter your Hospital Name',
                    labelText: 'Hospital Name',
                    validator: (value) => value!.isEmpty ? 'Please enter your Hospital' : null,
                  ),
                  PasswordInputField(
                    title: dob,
                    node: dobFocusNode,
                    validator: (value) => value!.isEmpty ? 'Please enter your Date of Birth' : null,
                    obSecure: false,
                    icon: Icons.person_pin_outlined,
                    hintText: 'Enter your Date of Birth',
                    labelText: 'D.O.B',
                    suffixIcon: InkWell(
                      onTap: () => _selectDate(context, dob),
                      child: const Icon(Icons.date_range),
                    ),
                  ),
                  PasswordInputField(
                    title: weddingDate,
                    node: weddingDateFocusNode,
                    validator: (value) => value!.isEmpty ? 'Please enter your Wedding Anniversary' : null,
                    obSecure: false,
                    icon: CupertinoIcons.heart_circle,
                    hintText: 'Enter your Wedding Anniversary',
                    labelText: 'Wedding Anniversary',
                    suffixIcon: InkWell(
                      onTap: () => _selectDate(context, weddingDate),
                      child: const Icon(Icons.date_range),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 3.h),

              Padding(
                padding: EdgeInsets.all(
                  MediaQuery.of(context).size.width > 600
                      ? MediaQuery.of(context).size.width * 0.009 // For tablets (3% of screen width)
                      : MediaQuery.of(context).size.width * 0.05, // For mobile devices (5% of screen width)
                ),
                child: ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      final updateCustomer = UpdateCustomerEntity(
                        id: widget.profile[0].id,
                        name: name.text,
                        email: email.text,
                        phone: phone.text,
                        address: address.text,
                        profession: profession.text,
                        dob: dob.text,
                        weddingAnniversary: weddingDate.text,
                        workingPlace: hospitalName.text,
                        state: (state != null && state.name != null && state.name.isNotEmpty)
                            ? state.name.toString()
                            : newState ?? '',
                        city: (city != null && city.toString() != null && city.toString().isNotEmpty)
                            ? city.toString()
                            : newCity ?? '',
                      );
                      update.updateCustomers(
                          updateCustomer,
                          context,
                          name,
                          email,
                          phone,
                          address,
                          profession,
                          hospitalName,
                          dob,
                          weddingDate
                      );
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryColor,
                    fixedSize: Size(
                      MediaQuery.of(context).size.width > 600
                          ? MediaQuery.of(context).size.width * 0.9 // For tablets (60% of screen width)
                          : MediaQuery.of(context).size.width * 0.9, // For mobile devices (90% of screen width)
                      double.infinity, // Adjust height as necessary
                    ),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(15), // Example padding inside the button
                    child: TextWithStyle.contactUsTitle(context, ConstantStrings.updateProfile),
                  ),
                ),
              ),

              SizedBox(height: 1.h),
            ],
          ),
        ),
      ),
    );
  }
}

class ProfileFormContainer extends StatelessWidget {
  final List<Widget> children;

  const ProfileFormContainer({Key? key, required this.children}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(15.px),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10.px),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: children,
      ),
    );
  }
}

class PhoneNumberField extends StatelessWidget {
  final TextEditingController controller;
  final FocusNode focusNode;
  final String hintText;
  final String labelText;

  const PhoneNumberField({
    Key? key,
    required this.controller,
    required this.focusNode,
    required this.hintText,
    required this.labelText,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      focusNode: focusNode,
      keyboardType: TextInputType.phone,
      inputFormatters: [
        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
        LengthLimitingTextInputFormatter(10),
      ],
      decoration: InputDecoration(
        hintText: hintText,
        labelText: labelText,
        prefixIcon: const Icon(Icons.phone_android),
        border: const OutlineInputBorder(),
      ),
      validator: (value) {
        if (value!.isEmpty) {
          return 'Please enter your Phone Number';
        } else if (value.length < 10) {
          return 'Please enter a valid Phone Number';
        }
        return null;
      },
    );
  }
}




import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:pharma_clients_app/utils/Responsive/ResponsiveUtils.dart';
import 'package:pharma_clients_app/view_model/services/notification_services.dart';
import 'package:pharma_clients_app/views/homescreen/NotificationScreen.dart';
import 'package:pharma_clients_app/views/Screens/calculator.dart';
import 'package:pharma_clients_app/views/addScreen/AddScreen.dart';
import 'package:pharma_clients_app/views/customer/customers_screen.dart';
import 'package:pharma_clients_app/views/homescreen/selfAnalysisScreen.dart';
import 'package:pharma_clients_app/views/presentation/presentaionListScreen.dart';
import 'package:pharma_clients_app/views/products/favouriteScreen.dart';
import 'package:pharma_clients_app/views/visits/visits_screen.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../data/model/response_model/about_company/about_company_response_model.dart';
import '../../data/response/status.dart';
import '../../resources/app_colors.dart';
import '../../resources/constant_strings.dart';
import '../../utils/IconWithFun/png_with_fun.dart';
import '../../utils/IconWithFun/mainIcons_with_fun.dart';
import '../../utils/Dialogue/error_dialogue.dart';
import '../../utils/scroll_state/scroll_state.dart';
import '../../utils/slider/Slider.dart';
import '../../utils/text_style.dart';
import '../../view_model/afterLogin_viewModel/afterLogin_viewModels.dart';
import '../../view_model/beforeLogin_viewModels/beforeLogin_viewModel.dart';
import '../../view_model/login_viewmodel.dart';
import '../Mr/MrsScreen.dart';
import 'cart_screen.dart';
import '../customer/customersOrderScreen.dart';
import 'myOrderScreen.dart';
import '../products/product_screen.dart';
import 'divisons_screen.dart';
import 'enquiry_screen.dart';
import '../products/new_launched.dart';
import 'offer_screen.dart';
import '../Screens/profile_screen.dart';
import 'promotional.dart';
import '../products/upcoming_products.dart';
import 'visual_aids_screen.dart';
import '../auth/login_screen.dart';
import 'package:flutter/material.dart';
class HomeScreen extends StatefulWidget {
  final String? token;
  final bool? isOwner;
  final int? initialTabIndex;

  HomeScreen({
    required this.token,
    this.isOwner,
    Key? key,
    this.initialTabIndex,
  }) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  AboutCompanyViewModel model = AboutCompanyViewModel();
  LoginViewModel loginModel = LoginViewModel();
  GuestDbCountViewModel dbCount = GuestDbCountViewModel();
  NotificationServices notificationServices = NotificationServices();
  DbCountViewModel count = DbCountViewModel();
  List<AboutCompany> about = [];
  int _selectedIndex = 0;

  final List<String> _labels = [
    'Home',
    'Customers',
    'Cart',
    'Profile',
    'Products',
    'Visual Aids',
    "M.R's",
    'My Orders',
    'Upcoming\nProducts',
    'Divisions',
    'Slides',
    'Visits',
    'Self Analysis',
    'Newly\nLaunched',
    'PTR/PTS',
    'Connect With Us',
    'Customer\nOrders',
    'Promotional Items',
    'Offers',
    'Favourite Products',
  ];

  @override
  void initState() {
    super.initState();
    _selectedIndex = widget.initialTabIndex ?? 0;
    notificationServices.requestNotificationPermission(
        widget.isOwner, widget.token);
    notificationServices.foregroundMessage();
    notificationServices.firebaseInit(context, widget.isOwner, widget.token);
    notificationServices.setupInteractMessage(
        context, widget.isOwner, widget.token);
    notificationServices.isTokenRefresh();
    getCount();
    getData();
  }

  Future<void> getCount() async {
    if (widget.token != null && widget.token!.isNotEmpty) {
      await count.fetchCountApi(context);
      getData();
    } else {
      await dbCount.fetchDbCountApi();
    }
  }

  Future<void> getData() async {
    await model.fetchAboutCompany();
  }

  Future<bool?> _onWillPop() async {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Are you sure?'),
        content: const Text('Do you want to exit the App?'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('No'),
          ),
          TextButton(
            onPressed: () => exit(0),
            child: const Text('Yes'),
          ),
        ],
      ),
    );
  }

  Widget _buildIcon(int index) {
    final cart = Provider.of<Cart>(context, listen: false);

    // Responsive icon sizes based on device
    double iconSize;
    if (Responsive.isDesktop(context)) {
      iconSize = MediaQuery.of(context).size.width * 0.04;
    } else if (Responsive.isTablet(context)) {
      iconSize = MediaQuery.of(context).size.width * 0.037;
    } else {
      iconSize = MediaQuery.of(context).size.width * 0.08;
    }

    switch (index) {
      case 0:
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/home.png'
              : 'assets/images/png/home_outlined.png',
          width: iconSize,
        );
      case 1:
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/customers.png'
              : 'assets/images/png/customers_outlined.png',
          width: iconSize,
        );
      case 2:
        return FutureBuilder(
          future: cart.loadCart(),
          builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
            return Consumer<Cart>(
              builder: (BuildContext context, value, Widget? child) {
                return Badge(
                  label: Text(
                    value.items.length.toString(),
                    style: TextStyle(
                      fontSize: isTablet(context) ? 14 : 12,
                    ),
                  ),
                  isLabelVisible: true,
                  backgroundColor: AppColors.badgeColor,
                  alignment: Alignment.topRight,
                  child: Image.asset(
                    _selectedIndex == index
                        ? 'assets/images/png/cart_filled.png'
                        : 'assets/images/png/cart_outlined.png',
                    width: iconSize,
                  ),
                );
              },
            );
          },
        );
      case 3:
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/profile.png'
              : 'assets/images/png/profile_outlined.png',
          width: iconSize,
        );

      case 4: // Products
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/products.png'
              : 'assets/images/png/products.png',
          width: iconSize,
        );


      case 5: // Products
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/visualaids.png'
              : 'assets/images/png/products.png',
          width: iconSize,
        );


      case 6: // Products
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/mrs.png'
              : 'assets/images/png/mrs.png',
          width: iconSize,
        );


      case 7: // Products
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/orders.png'
              : 'assets/images/png/orders.png',
          width: iconSize,
        );




      case 8: // Products
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/upcoming_products.png'
              : 'assets/images/png/upcoming_products.png',
          width: iconSize,
        );



      case 9: // Products
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/divisons.png'
              : 'assets/images/png/divisons.png',
          width: iconSize,
        );



      case 10: // Products
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/slides.png'
              : 'assets/images/png/slides.png',
          width: iconSize,
        );


      case 11: // Products
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/visits.png'
              : 'assets/images/png/visits.png',
          width: iconSize,
        );



      case 12: // Products
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/self_analysis.png'
              : 'assets/images/png/self_analysis.png',
          width: iconSize,
        );


      case 13: // Products
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/new_launches.png'
              : 'assets/images/png/new_launches.png',
          width: iconSize,
        );


        case 14: // Products
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/ptrpts.png'
              : 'assets/images/png/ptrpts.png',
          width: iconSize,
        );

      case 15: // Products
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/connectwithus.png'
              : 'assets/images/png/connectwithus.png',
          width: iconSize,
        );

      case 16: // Products
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/customersorders.png'
              : 'assets/images/png/customersorders.png',
          width: iconSize,
        );

      case 17: // Products
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/promotional_items.png'
              : 'assets/images/png/promotional_items.png',
          width: iconSize,
        );

      case 18: // Products
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/offers.png'
              : 'assets/images/png/offers.png',
          width: iconSize,
        );


      case 19: // Products
        return Image.asset(
          _selectedIndex == index
              ? 'assets/images/png/favorite.png'
              : 'assets/images/png/favorite.png',
          width: iconSize,
        );





      default:
        return const SizedBox();
    }
  }

  bool isTablet(BuildContext context) {
    return MediaQuery.of(context).size.width >= 600;
  }


  Widget _buildScreen(int index) {
    switch (index) {
      case 0:
        return DashboardScreen(
            isOwner: widget.isOwner,
            token: widget.token,
            aboutCompany: about
        );

      case 1:
        return widget.token != null && widget.token!.isNotEmpty
            ? const CustomersScreen()
            : LoginScreen();

      case 2:
        return widget.token != null && widget.token!.isNotEmpty
            ? CartScreen(owner: widget.token, isOwner: widget.isOwner)
            : LoginScreen();

      case 3:
        return widget.token != null && widget.token!.isNotEmpty
            ? ProfileScreen(value: about, isOwner: widget.isOwner)
            : LoginScreen();

      case 4:
        return ProductScreen(
          token: widget.token,
          isOwner: widget.isOwner,
        ); // Product Screen

      case 5:
        return VisualAidsScreen(token: widget.token ?? '');

      case 6:
        if (widget.token != null) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const MrsScreen(),
            ),
          );
        } else {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => LoginScreen(),
            ),
          );
        }
        return Container(); // Return a container or a loading indicator

      case 7:
        if (widget.token != null && widget.token!.isNotEmpty) {
          if (widget.isOwner == true) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const MyOrderScreen()),
            );
          } else {
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => const CustomersOrderScreen()),
            );
          }
        } else {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => LoginScreen()),
          );
        }
        return Container(); // Return a container or a loading indicator

      case 8:
        return UpcomingProductScreen(token: widget.token);

    // case 9:
    // return DivisionScreen(),

      case 10:
        return PresentationListScreen();

      case 11:
        return VisitsScreen();

      case 12:
        return const SelfAnalysisScreen();

      case 13:
        return NewLaunchedProductScreen(token: widget.token);

      case 14:
        return Calculator();

      case 15:
      // Uncomment this line to return EnquiryScreen
      // return EnquiryScreen(value: widget.aboutCompany);

      case 16:
        return CustomersOrderScreen();

      case 17:
        return const PromotionalScreen();

      case 18:
        return const OfferScreen();

      case 19:
        return FavouriteScreen(token: widget.token);

      default:
        return Container();
    }
  }


  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        bool? result = await _onWillPop();
        result ??= false;
        return result;
      },
      child: ChangeNotifierProvider<AboutCompanyViewModel>(
        create: (BuildContext context) => model,
        child: Consumer<AboutCompanyViewModel>(builder: (context, value, _) {
          switch (value.aboutCompany.status!) {
            case Status.loading:
              return Container(
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                color: AppColors.backgroundColor,
                child: Center(
                  child: LoadingAnimationWidget.discreteCircle(
                    color: AppColors.primaryColor,
                    size: 40,
                  ),
                ),
              );

            case Status.error:
              return ErrorDialogue(
                message: value.aboutCompany.message,
              );
            case Status.completed:
              about.add(value.aboutCompany.data!.data!);

              return Scaffold(
                key: _scaffoldKey,
                body: Row(
                  children: [
                    if (isTablet(context))
                      NavigationRail(
                        backgroundColor: AppColors.backgroundColor,
                        selectedIndex: _selectedIndex,
                        onDestinationSelected: (int index) {
                          setState(() {
                            _selectedIndex = index;
                          });
                        },
                        extended: true,
                        minExtendedWidth: 167,
                        labelType: NavigationRailLabelType.none,
                        selectedLabelTextStyle: TextStyle(
                          color: AppColors.primaryColor,
                          fontSize: 14.5,
                          fontWeight: FontWeight.w700,
                        ),
                        unselectedLabelTextStyle: TextStyle(
                          color: Colors.black.withOpacity(0.6),
                          fontSize: 14.5,
                          fontWeight: FontWeight.w500,
                        ),
                        destinations: [
                          for (int i = 0; i < _labels.length; i++)

                            NavigationRailDestination(
                              icon: _buildIcon(i),
                              label: SizedBox(
                                width: 100, // You can adjust this width according to your design
                                child: Text(
                                  _labels[i],
                                  textAlign: TextAlign.start, // Align the text to the start
                                  overflow: TextOverflow.visible, // Make the text wrap to the next line
                                ),
                              ),
                            ),

                        ],
                      ),
                    Expanded(
                      child: Column(
                        children: [
                          const SizedBox(height: 20),
                          Expanded(
                            child: Center(child: _buildScreen(_selectedIndex)),
                          ),
                          const SizedBox(height: 20),
                        ],
                      ),
                    ),
                  ],
                ),
                bottomNavigationBar: !isTablet(context) &&
                    widget.token != null &&
                    widget.token!.isNotEmpty
                    ? BottomNavigationBar(
                  backgroundColor: Colors.white,
                  type: BottomNavigationBarType.fixed,
                  selectedLabelStyle: TextStyle(fontSize: 14),
                  selectedItemColor: AppColors.primaryColor,
                  unselectedItemColor: Colors.grey,
                  currentIndex: _selectedIndex,
                  onTap: (index) {
                    setState(() {
                      _selectedIndex = index;
                    });
                  },
                  items: [
                    for (int index = 0; index < 4; index++)
                      BottomNavigationBarItem(
                        icon: _buildIcon(index),
                        label: _labels[index],
                      ),
                  ],
                )
                    : null,
              );
          }
        }),
      ),
    );
  }
}


class DashboardScreen extends StatefulWidget {
  final String? token;
  final bool? isOwner;
  final List<AboutCompany> aboutCompany;

  const DashboardScreen(
      {Key? key, this.token, this.isOwner, required this.aboutCompany})
      : super(key: key);

  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {

  Widget? _currentOverlay;

  void _showOverlay(Widget widget) {
    setState(() {
      _currentOverlay = widget;
    });
  }

  void _hideOverlay() {
    setState(() {
      _currentOverlay = null;
    });
  }



  AboutCompanyViewModel model = AboutCompanyViewModel();
  GuestDbCountViewModel dbcount = GuestDbCountViewModel();
  DbCountViewModel count = DbCountViewModel();
  String? userName;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    getCount();
    getUserInfo();
  }

  Future<void> getCount() async {
    if (widget.token != null && widget.token!.isNotEmpty) {
      await count.fetchCountApi(context);
      getData();
    } else {
      await dbcount.fetchDbCountApi();
    }
  }

  Future<void> getData() async {
    await model.fetchAboutCompany();
  }

  Future<void> getUserInfo() async {
    final SharedPreferences sp = await SharedPreferences.getInstance();
    userName = sp.getString('name');
  }

  @override
  Widget build(BuildContext context) {
    return widget.token != null && widget.token!.isNotEmpty
        ? ChangeNotifierProvider<DbCountViewModel>(
      create: (BuildContext context) => count,
      child: Consumer<DbCountViewModel>(
        builder: (context, val, _) {
          return val.loading == false
              ? buildDashboard(val)
              : buildLoadingScreen(context);
        },
      ),
    )
        : ChangeNotifierProvider<GuestDbCountViewModel>(
      create: (BuildContext context) => dbcount,
      child: Consumer<GuestDbCountViewModel>(
        builder: (context, val, _) {
          return val.loading == false
              ? buildDashboard(val)
              : buildLoadingScreen(context);
        },
      ),
    );
  }

  Widget buildDashboard(val) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: buildAppBar(),
      body:
      RefreshIndicator(
        onRefresh: getCount,
        child:
        Responsive(
          mobile: buildMobileLayout(dynamic, val),
          tablet: buildTabletLayout(val),
          desktop: buildDesktopLayout(val),
        ),
      ),
      floatingActionButton: buildFloatingActionButton(),
    );
  }

  AppBar buildAppBar() {
    return AppBar(
      // toolbarHeight: Responsive.isTablet(context) ? 40 : 56,
      toolbarHeight: Responsive.isMobile(context) ? 36 : 56,
      automaticallyImplyLeading: false,
      elevation: 0,
      title:
      Column(
        children: [
          widget.token == null
              ? AppBarUtils.appBarTitle(
              context, ConstantStrings.dashboardScreen)
              : Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Hi,',
                style: TextStyle(
                  color: Colors.black54,
                  fontSize: Responsive.isDesktop(context)
                      ? MediaQuery.of(context).size.width * 0.05 // Responsive for Desktop
                      : (Responsive.isTablet(context)
                      ? MediaQuery.of(context).size.width * 0.025 // Responsive for Tablet
                      : MediaQuery.of(context).size.width * 0.035), // Responsive for Mobile
                ),
              ),
              const SizedBox(width: 8),
              Text(
                "${userName}",
                style: TextStyle(
                  color: Colors.black,
                  fontSize: Responsive.isMobile(context)
                      ? MediaQuery.of(context).size.width * 0.04 // Responsive for Mobile
                      : (Responsive.isTablet(context)
                      ? MediaQuery.of(context).size.width * 0.03 // Responsive for Tablet
                      : MediaQuery.of(context).size.width * 0.06), // Responsive for Desktop
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ],
      ),

        actions: [

        IconButton(
          onPressed: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const NotificationScreen()));
          },
          icon: Image.asset(
            'assets/images/png/notification.png',
            // Adjust the width based on the device type
            width: Responsive.isDesktop(context)
                ? 60.0 // Width for Desktop
                : (Responsive.isTablet(context)
                ? 22 // Width for Tablet
                : 25.0), // Width for Mobile
          ),
        ),
        SizedBox(
          width: Responsive.isTablet(context)
              ? 30
              : (Responsive.isDesktop(context) ? 30 : 10),
        ),
        widget.token == null
            ? IconButton(
          onPressed: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => LoginScreen()));
          },
          icon: Image.asset(
            'assets/images/png/profile.png',
            // Adjust the width based on the device type
            width: Responsive.isDesktop(context)
                ? 60.0 // Width for Desktop
                : (Responsive.isTablet(context)
                ? 45.0 // Width for Tablet
                : 25.0), // Width for Mobile
          ),
        )
            : Container(),
        SizedBox(
          width: Responsive.isDesktop(context)
              ? 30
              : (Responsive.isTablet(context) ? 30 : 10),
        )
      ],
    );
  }

  Widget buildMobileLayout(dynamic value, val) {
    return SingleChildScrollView(
      child: Column(
        children: [
          buildSlider(),
          buildCategories(val),
          buildGridItems(val),
          builderImage(value), // Correctly using the function
        ],
      ),
    );
  }



  Widget buildSlider() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final maxHeight = constraints.maxHeight * 0.3;

        return Container(
          margin: EdgeInsets.symmetric(vertical: 13),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: maxHeight,
            ),
            child: slider(
              images: widget.aboutCompany[0].aboutImgs!,
              aspectRatio: 2 / 1,
              viewPortFraction: 0.97,
            ),
          ),
        );
      },
    );
  }

  Widget buildTabletLayout(dynamic value) {
    return Scaffold(
      body: Row(
        children: [
          // Left side: Categories list
          Visibility(
            visible: _currentOverlay == null,
            child: Expanded(
              flex: 1,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    buildSlider(),
                    buildCategories(value),
                    buildGridItems(value),
                    builderImage(value), // Correctly using the function
                  ],
                ),
              ),
            ),
          ),
          // Right side: Detail view
          if (_currentOverlay != null)
            Expanded(
              flex: 2,
              child: Stack(
                children: [
                  _currentOverlay!,
                  Positioned(
                    top: 5,
                    left: 10,  // Moved the close icon to the left side
                    child: IconButton(
                      icon: Icon(Icons.arrow_back_ios),
                      onPressed: _hideOverlay,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget builderImage(dynamic value) {
    return Builder(
      builder: (BuildContext context) {
        final screenWidth = MediaQuery.of(context).size.width;

        // Define margin based on screen width
        final double horizontalMargin;
        if (screenWidth < 600) {
          // Mobile
          horizontalMargin = screenWidth * 0.01; // 3% of screen width
        } else if (screenWidth < 1200) {
          // Tablet
          horizontalMargin = screenWidth * 0.009; // 2% of screen width
        } else {
          // Desktop
          horizontalMargin = screenWidth * 0.04; // 1% of screen width
        }
        return InkWell(
          onTap: () {
            final iosLink = value.aboutCompany.data.data.iosAppLiveLink;
            final androidLink = value.aboutCompany.data.data.appLiveLink;

            if (iosLink.isEmpty && androidLink.isEmpty) {
              showDialog(
                context: context,
                builder: (context) => ErrorDialogue(
                  message: 'No link found',
                ),
              );
            } else {
              _onShare(
                context,
                'iOS App Link: $iosLink\nAndroid App Link: $androidLink',
                ConstantStrings.appName,
              );
            }
          },
          child: Container(
            margin: EdgeInsets.symmetric(horizontal: horizontalMargin),
            child: Image.asset(
              "assets/images/png/share-image.png",
              fit: BoxFit.cover,
            ),
          ),
        );
      },
    );
  }

  Widget buildDesktopLayout(val) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(flex: 1, child: buildCategories(val)),
        Expanded(flex: 2, child: buildGridItems(val)),
      ],
    );
  }

  Widget buildCategories(val) {
    return Container(
      margin: EdgeInsets.only(
          left: MediaQuery.of(context).size.width * 0.03,
          right: MediaQuery.of(context).size.width * 0.03,
          top: MediaQuery.of(context).size.width * 0.02,
          bottom: 0.0),
      child:
      Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextWithStyle.containerTitle(context, 'Categories'),
          SizedBox(height: MediaQuery.of(context).size.height * 0.01),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Container(
                  padding: EdgeInsets.only(
                    top: MediaQuery.of(context).size.height / 60,
                    bottom: MediaQuery.of(context).size.height / 140,
                  ),
                  child: Column(
                    children: [
                      MainIconsWithFun(
                        title: ConstantStrings.productScreen,
                        image: 'assets/images/png/products.png',
                        onPress: () =>
                        //     Navigator.push(
                        //   context,
                        //   MaterialPageRoute(
                        //     builder: (context) => ProductScreen(
                        //       token: widget.token,
                        //       isOwner: widget.isOwner,
                        //     ),
                        //   ),
                        // ),

                        _showOverlay(ProductScreen(token: widget.token, isOwner: widget.isOwner))

                      ),
                      Text(
                        val.data?.productCount.toString() ?? '0',
                        style: TextStyle(
                          fontSize: MediaQuery.of(context).size.width *
                              0.02, // Responsive font size
                          color: Colors.black54,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child:
                Container(
                  padding: EdgeInsets.only(
                    top: MediaQuery.of(context).size.height / 60,
                    bottom: MediaQuery.of(context).size.height / 140,
                  ),
                  child:
                  Column(
                    children: [
                      MainIconsWithFun(
                        title: ConstantStrings.visualAidsScreen,
                        image: 'assets/images/png/visualaids.png',
                        onPress: () => 
                        //     Navigator.push(
                        //   context,
                        //   MaterialPageRoute(
                        //     builder: (context) => VisualAidsScreen(
                        //       token: widget.token,
                        //     ),
                        //   ),
                        // ),

                        _showOverlay(VisualAidsScreen(token: widget.token))
                      ),
                      Text(
                        "",
                        style: TextStyle(
                          fontSize: MediaQuery.of(context).size.width *
                              0.035, // Responsive font size
                          fontWeight: FontWeight.w300,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              widget.isOwner == true || widget.isOwner == null
                  ?
              Expanded(
                child: Container(
                  padding: EdgeInsets.only(
                    top: MediaQuery.of(context).size.height / 60,
                    bottom: MediaQuery.of(context).size.height / 140,
                  ),
                  child: Column(
                    children: [
                      MainIconsWithFun(
                        title: ConstantStrings.mrs,
                        image: 'assets/images/png/mrs.png',
                        onPress: () async {
                          if (widget.token != null) {
                            _showOverlay(const MrsScreen());
                          } else {
                            _showOverlay(LoginScreen());
                          }
                        },
                      ),
                      Text(
                        '',
                        style: TextStyle(
                          fontSize: Responsive.isMobile(context)
                              ? MediaQuery.of(context).size.width * 0.04
                              : (Responsive.isTablet(context)
                              ? MediaQuery.of(context).size.width * 0.035
                              : MediaQuery.of(context).size.width * 0.03),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              )
                  : Container(),
              const SizedBox(width: 10),
              Expanded(
                child: Container(
                  padding: EdgeInsets.only(
                    top: MediaQuery.of(context).size.height / 60,
                    bottom: MediaQuery.of(context).size.height / 140,
                  ),
                  child: Column(
                    children: [
                      MainIconsWithFun(
                        title: ConstantStrings.myOrders,
                        image: 'assets/images/png/orders.png',
                        onPress: () {
                          widget.token != null && widget.token!.isNotEmpty
                              ? widget.isOwner == true
                              ?
                          // Navigator.push(
                          //   context,
                          //   MaterialPageRoute(
                          //     builder: (context) =>
                          //     const MyOrderScreen(),
                          //   ),
                          // )

                          _showOverlay(const MyOrderScreen())
                              :
                          // Navigator.push(
                          //   context,
                          //   MaterialPageRoute(
                          //     builder: (context) =>
                          //     const CustomersOrderScreen(),
                          //   ),
                          // )
                          _showOverlay(const CustomersOrderScreen())
                              :
                          // Navigator.push(
                          //   context,
                          //   MaterialPageRoute(
                          //       builder: (context) => LoginScreen()),
                          // );
                          _showOverlay(const LoginScreen());  widget.token != null && widget.token!.isNotEmpty
                              ? widget.isOwner == true
                              ? Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                              const MyOrderScreen(),
                            ),
                          )
                              : Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                              const CustomersOrderScreen(),
                            ),
                          )
                              : Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => LoginScreen()),
                          );   widget.token != null && widget.token!.isNotEmpty
                              ? widget.isOwner == true
                              ? Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                              const MyOrderScreen(),
                            ),
                          )
                              : Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                              const CustomersOrderScreen(),
                            ),
                          )
                              : Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => LoginScreen()),
                          );
                        },
                      ),
                      Text(
                        widget.token != null && widget.token!.isNotEmpty
                            ? widget.isOwner == true
                            ? val.dataa?.companyOrderCount.count
                            .toString()
                            .length ==
                            1
                            ? '0${val.dataa?.companyOrderCount.count.toString()}'
                            : val.dataa?.companyOrderCount.count
                            .toString() ??
                            '0'
                            : val.data?.orderCount.toString() ?? '0'
                            : '0',
                        style: TextStyle(
                          fontSize: MediaQuery.of(context).size.width *
                              0.02, // Responsive font size
                          color: Colors.black54,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const Divider(
            color: Colors.black12,
            height: 10,
          ),
        ],
      ),

    );
  }


  Widget buildGridItems(val) {
    return GridView.count(
      physics: const NeverScrollableScrollPhysics(),
      primary: false,
      shrinkWrap: true,
      padding: EdgeInsets.all(MediaQuery.of(context).size.height / 100),
      crossAxisCount: Responsive.isTablet(context) ? 4 : 4,
      children: [
        buildGridItem(
          ConstantStrings.upcomingScreen,
          'assets/images/png/upcoming_products.png',
              () =>
          //         Navigator.push(
          //   context,
          //   MaterialPageRoute(
          //     builder: (context) => UpcomingProductScreen(token: widget.token),
          //   ),
          // ),

              _showOverlay(UpcomingProductScreen(token: widget.token)),

        ),
        buildGridItem(
          ConstantStrings.divisions,
          'assets/images/png/divisons.png',
              () =>
          //         Navigator.push(
          //   context,
          //   MaterialPageRoute(
          //     builder: (context) => DivisionScreen(
          //         token: widget.token, value: widget.aboutCompany),
          //   ),
          // ),
              _showOverlay( DivisionScreen(token: widget.token,value: widget.aboutCompany)),
        ),
        buildGridItem(
          ConstantStrings.presentation,
          'assets/images/png/slides.png',
              () =>
          //         Navigator.push(
          //   context,
          //   MaterialPageRoute(
          //     builder: (context) => PresentationListScreen(),
          //   ),
          // ),

              _showOverlay(PresentationListScreen()),
        ),
        buildGridItem(
          ConstantStrings.visits,
          'assets/images/png/visits.png',
              () =>
          //         Navigator.push(
          //   context,
          //   MaterialPageRoute(
          //     builder: (context) => const VisitsScreen(),
          //   ),
          // ),

              _showOverlay(const VisitsScreen()),
        ),
        buildGridItem(
          ConstantStrings.selfAnalysis,
          'assets/images/png/self_analysis.png',
              () =>
          //         Navigator.push(
          //   context,
          //   MaterialPageRoute(
          //     builder: (context) => const SelfAnalysisScreen(),
          //   ),
          // ),
              _showOverlay(const SelfAnalysisScreen()),


        ),
        buildGridItem(
          ConstantStrings.newLaunches,
          'assets/images/png/new_launches.png',
              () =>
          //         Navigator.push(
          //   context,
          //   MaterialPageRoute(
          //     builder: (context) =>
          //         NewLaunchedProductScreen(token: widget.token),
          //   ),
          // ),

              _showOverlay(NewLaunchedProductScreen(token: widget.token)),
        ),
        buildGridItem(
          ConstantStrings.ptrpts,
          'assets/images/png/ptrpts.png',
              () =>
          //         Navigator.push(
          //   context,
          //   MaterialPageRoute(
          //     builder: (context) => const Calculator(),
          //   ),
          // ),
              _showOverlay(const Calculator())

        ),
        buildGridItem(
          ConstantStrings.enquiry,
          'assets/images/png/connectwithus.png',
              () =>
          //         Navigator.push(
          //   context,
          //   MaterialPageRoute(
          //     builder: (context) => EnquiryScreen(value: widget.aboutCompany),
          //   ),
          // ),

              _showOverlay(EnquiryScreen(value: widget.aboutCompany)),
        ),
        buildGridItem(
          ConstantStrings.customersOrders,
          'assets/images/png/customersorders.png',
              () =>
          //         Navigator.push(
          //   context,
          //   MaterialPageRoute(
          //     builder: (context) => const CustomersOrderScreen(),
          //   ),
          // ),

              _showOverlay(const CustomersOrderScreen()),
        ),

        buildGridItem(
          ConstantStrings.promotional,
          'assets/images/png/promotional_items.png',
              () =>
          //         Navigator.push(
          //   context,
          //   MaterialPageRoute(
          //     builder: (context) => const PromotionalScreen(),
          //   ),
          // ),

              _showOverlay(const PromotionalScreen()),
        ),
        buildGridItem(
          ConstantStrings.favouriteScreenHeading,
          'assets/images/png/favorite.png',
              () =>
          //         Navigator.push(
          //   context,
          //   MaterialPageRoute(
          //     builder: (context) => FavouriteScreen(token: widget.token),
          //   ),
          // ),

              _showOverlay(FavouriteScreen(token: widget.token)),
        ),

        buildGridItem(
          'Offers',
          'assets/images/png/offers.png',
              () =>
          //         Navigator.push(
          //   context,
          //   MaterialPageRoute(
          //     builder: (context) => const OfferScreen(),
          //   ),
          // ),

              _showOverlay(const OfferScreen()),
        ),
      ],
    );
  }

  Widget buildCategoryItem(String title, String count, VoidCallback onPress) {
    return Expanded(
      child: InkWell(
        onTap: onPress,
        child: Column(
          children: [
            MainIconsWithFun(
              title: title,
              image: 'assets/images/png/products.png',
              onPress: onPress,
            ),
            Text(
              count,
              style: TextStyle(fontSize: 13.5),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildGridItem(String title, String image, VoidCallback onPress) {
    return PngIconsWithFun(
      title: title,
      image: image,
      onPress: onPress,
    );
  }

  Widget buildLoadingScreen(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      color: AppColors.backgroundColor,
      child: Center(
        child: LoadingAnimationWidget.discreteCircle(
          color: AppColors.primaryColor,
          size: 40,
        ),
      ),
    );
  }

  Widget buildFloatingActionButton() {
    return Consumer<ScrollState>(
      builder: (context, scrollState, _) {
        return scrollState.isScrolling
            ? ClipRRect(
          borderRadius: BorderRadius.circular(30.0),
          child: FloatingActionButton.extended(
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => AddScreen(
                        isOwner: widget.isOwner,
                        token: widget.token,
                      )));
            },
            backgroundColor: AppColors.primaryColor,
            label: TextWithStyle.contactUsTitle(
                context, ConstantStrings.addScreen),
          ),
        )
            : ClipRRect(
          borderRadius: BorderRadius.circular(100.0),
          child: FloatingActionButton(
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => AddScreen(
                        isOwner: widget.isOwner,
                        token: widget.token,
                      )));
            },
            backgroundColor: AppColors.primaryColor,
            child: const Icon(
              Icons.add,
              color: Colors.white,
            ),
          ),
        );
      },
    );
  }
}


_onShare(BuildContext context, text, subject) {
  final box = context.findRenderObject() as RenderBox?;
  return Share.share(
    text,
    subject: subject,
    sharePositionOrigin: box!.localToGlobal(Offset.zero) & box.size,
  );
}


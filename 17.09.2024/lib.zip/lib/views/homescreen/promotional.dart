import 'package:flutter/material.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:pharma_clients_app/data/response/status.dart';
import 'package:pharma_clients_app/resources/constant_strings.dart';
import 'package:pharma_clients_app/utils/text_style.dart';
import 'package:provider/provider.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import '../../resources/app_colors.dart';
import '../../resources/constant_imageString.dart';
import '../../utils/Dialogue/error_dialogue.dart';
import '../../view_model/beforeLogin_viewModels/beforeLogin_viewModel.dart';

class PromotionalScreen extends StatefulWidget {
  const PromotionalScreen({Key? key}) : super(key: key);

  @override
  State<PromotionalScreen> createState() => _PromotionalScreen();
}

class _PromotionalScreen extends State<PromotionalScreen> {

  AboutPromotionalViewModel model = AboutPromotionalViewModel();

  @override
  void initState() {
    model.fetchPromotional();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width >= 600; // Threshold for tablets
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        elevation: 0,
        title: TextWithStyle.appBarTitle(context, ConstantStrings.promotionalHeading),
      ),
      body: ChangeNotifierProvider<AboutPromotionalViewModel>(
        create: (BuildContext context) => model,
        child: Consumer<AboutPromotionalViewModel>(
          builder: (context, value, _) {
            switch (value.promotional.status!) {
              case Status.loading:
                return Container(
                  height: screenHeight,
                  width: screenWidth,
                  color: AppColors.backgroundColor,
                  child: Center(
                    child: LoadingAnimationWidget.discreteCircle(
                      color: AppColors.primaryColor,
                      size: 40,
                    ),
                  ),
                );
              case Status.error:
                return ErrorDialogue(message: value.promotional.message);
              case Status.completed:
                return value.promotional.data!.data!.isNotEmpty && value.promotional.data?.data != null
                    ? ListView.builder(
                  itemCount: value.promotional.data!.data?.length,
                  itemBuilder: (context, index) {
                    return Card(
                      margin: EdgeInsets.only(left: screenWidth * 0.04, right: screenWidth * 0.04, top: screenHeight * 0.03),
                      elevation: 2,
                      shadowColor: Colors.black38,
                      surfaceTintColor: Colors.white,
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(isTablet ? screenHeight * 0.03 : screenHeight * 0.02)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (value.promotional.data?.data?[index].image != null && value.promotional.data!.data![index].image!.isNotEmpty)
                            SizedBox(
                              width: double.infinity,
                              height: isTablet ? screenHeight * 0.5 : screenHeight * 0.25, // Adjusted height for tablet
                              child: FadeInImage.assetNetwork(
                                placeholder: 'assets/images/png/loading.gif',
                                // fit: BoxFit.fill,
                                image: value.promotional.data!.data![index].image!,
                              ),
                            ),
                          SizedBox(height: screenHeight * 0.02),
                          Container(
                            margin: EdgeInsets.only(left: screenWidth * 0.04, right: screenWidth * 0.04),
                            child: Text(
                              value.promotional.data!.data![index].title!,
                              style: TextStyle(
                                fontSize: isTablet ? screenWidth * 0.055 : screenWidth * 0.06,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          SizedBox(height: screenHeight * 0.02),
                          Container(
                            margin: EdgeInsets.only(left: screenWidth * 0.04, right: screenWidth * 0.04),
                            child: Text(
                              value.promotional.data!.data![index].description!,
                              style: TextStyle(
                                fontSize: isTablet ? screenWidth * 0.045 : screenWidth * 0.05,
                              ),
                            ),
                          ),
                          SizedBox(height: screenHeight * 0.02),
                        ],
                      ),
                    );
                  },
                )
                    : Center(
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          width: screenWidth * 0.7,
                          height: isTablet ? screenHeight * 0.3 : screenHeight * 0.25, // Adjusted height for tablet
                          child: Image.asset(
                            ConstantImage.empty,
                            fit: BoxFit.cover,
                          ),
                        ),
                        SizedBox(height: screenHeight * 0.02),
                        TextWithStyle.appBarTitle(context, ConstantStrings.emptyScreen),
                      ],
                    ),
                  ),
                );
            }
          },
        ),
      ),
    );
  }
}
